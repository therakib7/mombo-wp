<?php
/*
Plugin Name: Mombo Core
Plugin URI: https://demo.techcandle.net/mombo-wp
Description: This plugin is some component/shortcode and essential function for Mombo Creative Portfolio WordPress theme, To use Mombo theme properly you must install this plugin.
Author: TechCandle
Version: 1.0
Author URI: https://techcandle.net/
*/

if( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$theme = wp_get_theme(); // gets the current theme

if ( 'Mombo' == $theme->name || 'Mombo' == $theme->parent_theme ) : 
    
    require_once plugin_dir_path( __FILE__ ) . 'functions.php'; 
	require_once plugin_dir_path( __FILE__ ) . 'elementor/functions.php'; 
    require_once plugin_dir_path( __FILE__ ) . 'inc/custom-posts/custom-posts.php';
    require_once plugin_dir_path( __FILE__ ) . 'inc/wp-widgets/wp-widgets.php';
    require_once plugin_dir_path( __FILE__ ) . 'inc/ajax-functions.php';
    require_once plugin_dir_path( __FILE__ ) . 'inc/make-column-clickable-elementor/make-column-clickable-elementor.php';

    if ( is_admin() ) {
        // require_once plugin_dir_path( __FILE__ ) . 'welcome-page.php'; 
        //if ( $screen->post_type == 'job' ) {
            // require_once plugin_dir_path( __FILE__ ) . 'inc/meta-box/meta-box.php';
            // require_once plugin_dir_path( __FILE__ ) . 'inc/metabox.php';
        //}
        require_once plugin_dir_path( __FILE__ ) . 'inc/butterbean-metabox.php'; 
    } 

endif; 

<?php
/**
 *  Job Ajax Search
 *
 * @package Mombo
 * @since 1.0
 */ 

add_action('wp_ajax_mombo_job_search', 'mombo_job_search');
add_action('wp_ajax_nopriv_mombo_job_search', 'mombo_job_search');
function mombo_job_search() { 
    // do_action("init");

    $title = ( isset($_REQUEST['title']) ) ? sanitize_text_field( wp_unslash( $_REQUEST['title'] ) )  : '';
    $cat_id = ( isset($_REQUEST['cat_id']) ) ? sanitize_text_field( $_REQUEST['cat_id'] ) : '';
    $location_id = ( isset($_REQUEST['location_id']) ) ? sanitize_text_field( $_REQUEST['location_id'] ) : '';

    if ( !isset( $_REQUEST['job-search'] ) || !wp_verify_nonce( sanitize_text_field( wp_unslash( $_REQUEST['job-search'] ) ), 'mombo_job_search' ) ) { 
        die( esc_html__('Permission denied', 'mombo') );
    }
    ?>  
    <div class="m-40px-b">
        <div class="m-20px-b"> 
        </div>
        <?php  
        $args = array(
            'posts_per_page' => -1,   
            'post_type' => 'job',  
        ); 

        if ( $title ) {
            $args['s'] = $title;
        }

        if ( $cat_id ) {
            $args['tax_query'][] = array(
                'taxonomy' => 'job-category',   
                'field' => 'term_id',       
                'terms' => $cat_id,                  
            );
        }

        if ( $location_id ) {
            $args['tax_query'][] = array(
                'taxonomy' => 'job-location',   
                'field' => 'term_id',      
                'terms' => $location_id,                  
            );
        }

        $the_query = new WP_Query( $args ); 
        if ( $the_query->have_posts() ) :
        while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
        <a class="card box-shadow-hover transition m-15px-b" href="<?php the_permalink(); ?>">
            <div class="card-body p-15px-tb p-25px-lr">
                <span class="row justify-content-sm-between align-items-sm-center">
                    <span class="col-sm-6 m-5px-tb dark-color">
                        <?php the_title(); ?>
                    </span>
                    <span class="col-sm-6 m-5px-tb text-sm-right">
                        <span class="theme2nd-bg p-5px-tb p-10px-lr border-radius-15 white-color small">
                            <?php 
                                $job_location = get_the_terms( get_the_ID(), 'job-location' ); 
                                $director = $job_location[0];
                                if ( $job_location ) {
                                    echo esc_html( $job_location[0]->name );
                                } 
                            ?>
                            <i class="fas fa-arrow-right small m-5px-l"></i></span>
                    </span>
                </span>
            </div>
        </a> 
        <?php endwhile; else: esc_html_e( 'No job found by your criteria :(', 'mombo' ); endif; wp_reset_postdata(); ?>
    </div>  
    <?php    
    die(); 
}

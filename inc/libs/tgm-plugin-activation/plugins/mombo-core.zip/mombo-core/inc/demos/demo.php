<?php
/**
 * Custom conditional tags for this theme.
 *
 * @package Mombo
 */
 

/**
 * Demo Importer
 *
 * @package Mombo
 */

function mombo_theme_ocdi_import_files() { 
    return array(
        array(
            'import_file_name'             => esc_html__('Demo One','mombo'),
            'local_import_file'            => plugin_dir_path( __FILE__ ) . 'demo-one/content.xml',
            'local_import_widget_file'     => plugin_dir_path( __FILE__ ) . 'demo-one/widget.wie',
            'local_import_customizer_file'   => plugin_dir_path( __FILE__ ) . 'demo-one/customizer.dat',
            'import_notice'                => esc_html__( 'Before importing demo data you must have to install required plugins', 'mombo' ),
            // 'import_preview_image_url'   => trailingslashit( get_template_directory_uri() ) . 'inc/demos/demo-one/screenshot.jpg',
            'preview_url' => esc_url('https://mombo.techcandle.net'),
        ), 
    );
}
add_filter( 'pt-ocdi/import_files', 'mombo_theme_ocdi_import_files' );


function mombo_theme_ocdi_after_import_setup() {
    // Assign menus to their locations.
    $header_menu = get_term_by( 'name', 'Header Menu', 'nav_menu' ); 
    set_theme_mod( 'nav_menu_locations', array(
            'header-menu' => $header_menu->term_id,
        )
    );

    $menu_items_one = get_term_by( 'name', 'Menu Items One', 'nav_menu' ); 
    set_theme_mod( 'nav_menu_locations', array(
            'menu-items-one' => $menu_items_one->term_id,
        )
    );

    $menu_items_two = get_term_by( 'name', 'Menu Items Two', 'nav_menu' ); 
    set_theme_mod( 'nav_menu_locations', array(
            'menu-items-two' => $menu_items_two->term_id,
        )
    );

    $menu_items_three = get_term_by( 'name', 'Menu Items Three', 'nav_menu' ); 
    set_theme_mod( 'nav_menu_locations', array(
            'menu-items-three' => $menu_items_three->term_id,
        )
    );

    $menu_items_four = get_term_by( 'name', 'Menu Items Four', 'nav_menu' ); 
    set_theme_mod( 'nav_menu_locations', array(
            'menu-items-four' => $menu_items_four->term_id,
        )
    );

    $menu_items_five = get_term_by( 'name', 'Menu Items Five', 'nav_menu' ); 
    set_theme_mod( 'nav_menu_locations', array(
            'menu-items-five' => $menu_items_five->term_id,
        )
    );

    $menu_items_six = get_term_by( 'name', 'Menu Items Six', 'nav_menu' ); 
    set_theme_mod( 'nav_menu_locations', array(
            'menu-items-six' => $menu_items_six->term_id,
        )
    );

    // Assign front page and posts page (blog page).
    $front_page_id = get_page_by_title( 'Home' );
    $blog_page_id  = get_page_by_title( 'Blog' );

    update_option( 'show_on_front', 'page' );
    update_option( 'page_on_front', $front_page_id->ID );
    update_option( 'page_for_posts', $blog_page_id->ID );

}
add_action( 'pt-ocdi/after_import', 'mombo_theme_ocdi_after_import_setup' );


function mombo_theme_ocdi_plugin_page_setup( $default_settings ) {
    $default_settings['parent_slug'] = 'themes.php';
    $default_settings['page_title']  = esc_html__( 'Mombo Demo Import' , 'mombo' );
    $default_settings['menu_title']  = esc_html__( 'Demo Importer' , 'mombo' );
    $default_settings['capability']  = 'import';
    $default_settings['menu_slug']   = 'pt-one-click-demo-import';

    return $default_settings;
}
add_filter( 'pt-ocdi/plugin_page_setup', 'mombo_theme_ocdi_plugin_page_setup' );
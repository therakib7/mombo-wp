<?php
/**
 *  Mombo Register Custom Post Template
 *
 * @package Mombo
 * @since 1.0
 */
if ( ! function_exists( 'mombo_template_custom_posts' ) ) :
    function mombo_template_custom_posts() {

        $labels = array(
            'name'                  => esc_html_x( 'Mombo Template', 'Post Type General Name', 'mombo-core' ),
            'singular_name'         => esc_html_x( 'Mombo Template', 'Post Type Singular Name', 'mombo-core' ),
            'add_new_item'          => esc_html__( 'Add New Template', 'mombo-core' ),
            'add_new'               => esc_html__( 'Add New Template', 'mombo-core' ),
            'new_item'              => esc_html__( 'Add New Template', 'mombo-core' ),
            'all_items'             => esc_html__( 'All Templates', 'jupiterx-core' ),
            'edit_item'             => esc_html__( 'Edit Template', 'mombo-core' ),
            'view_item'             => esc_html__( 'View Template', 'mombo-core' ),
            'search_items'          => esc_html__( 'Search Template', 'mombo-core' ),
            'not_found'             => esc_html__( 'No Template Found', 'mombo-core' ),
            'not_found_in_trash'    => esc_html__( 'No Template Found in Trash', 'mombo-core' ),
        );
        $args = array(
            'label'                 => esc_html__( 'Mombo Template', 'mombo-core' ),
            'description'           => esc_html__( 'Add a Template', 'mombo-core' ),
            'labels'                => $labels,
            'supports'              => array( 'title' ),
            'hierarchical'          => false,
            'show_in_nav_menus'     => false,
            'public'                => true,
            'menu_position'         => 22,
            'menu_icon'             => 'dashicons-feedback',
            'can_export'            => true,
            'capability_type'       => 'page',
            'rewrite' => array( 'slug' => 'template' ),
        );
        register_post_type( 'template', $args );  

    }
endif;
add_action('init', 'mombo_template_custom_posts', 0);

add_filter('manage_edit-template_columns', 'mombo_post_data_columns' );
add_action('manage_template_posts_custom_column',  'mombo_template_show_columns' ); 

function mombo_post_data_columns($columns) {
    $columns['template_type'] = esc_html__( 'Template For', 'mombo-core' );
    return $columns;
}   

function mombo_template_show_columns($name) {
    global $post;
    switch ($name) {
        case 'template_type':
            switch ( get_post_meta($post->ID, 'mombo_template_type', true) ) {
                case 'header':
                    esc_html_e( 'Header', 'mombo-core' );
                    break;
                case 'footer':
                    esc_html_e( 'Footer', 'mombo-core' );
                    break;
                case 'preloader':
                    esc_html_e( 'Preloader', 'mombo-core' );
                    break; 
                case 'mega_menu':
                    esc_html_e( 'Mega Menu', 'mombo-core' );
                    break; 
            } 
    }
}    

function mombo_template_meta_boxes( $post_type, $post ) {
    add_meta_box( 
        'template-meta-box',
        esc_html__('Template Options', 'mombo-core'),
        'mombo_template_meta_box',
        'template',
        'normal',
        'default'
    );
}
add_action( 'add_meta_boxes', 'mombo_template_meta_boxes', 10, 2 );

function mombo_template_meta_box( $post ) {   
    $value = get_post_meta($post->ID, 'mombo_template_type', true); ?>
    <table>
        <tr>
            <td><label for="mombo_template_type"><?php esc_html_e( 'Select Template For:', 'mombo-core' ); ?></label></td>
            <td>
            <select name="mombo_template_type" id="mombo_template_type" class="widefat">
                <option value=""><?php esc_html_e( 'Select Option', 'mombo-core' ); ?></option>
                <option value="header" <?php selected($value, 'header'); ?>><?php esc_html_e( 'Header', 'mombo-core' ); ?></option>
                <option value="footer" <?php selected($value, 'footer'); ?>><?php esc_html_e( 'Footer', 'mombo-core' ); ?></option>
                <option value="preloader" <?php selected($value, 'preloader'); ?>><?php esc_html_e( 'Preloader', 'mombo-core' ); ?></option> 
                <option value="mega_menu" <?php selected($value, 'mega_menu'); ?>><?php esc_html_e( 'Mega Menu', 'mombo-core' ); ?></option>  
            </select> 
            </td>
        </tr>
        <tr>
            <td></td>
            <td>
                <span><?php esc_html_e( 'Choose where you want to add this template.', 'mombo-core' ); ?></span>
            </td>
        </tr>
    </table> 
<?php }

function mombo_save_template_postdata($post_id) {
    if ( array_key_exists('mombo_template_type', $_POST) ) {
        update_post_meta(
            $post_id,
            'mombo_template_type',
            $_POST['mombo_template_type']
        );
    }
}
add_action('save_post', 'mombo_save_template_postdata');
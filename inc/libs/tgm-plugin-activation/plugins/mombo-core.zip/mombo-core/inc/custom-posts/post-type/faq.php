<?php
/**
 *  Mombo Register Custom Post Faq
 *
 * @package Mombo
 * @since 1.0
 */
if ( ! function_exists( 'mombo_faq_custom_posts' ) ) :
function mombo_faq_custom_posts() {

    /* Faq Custom Post*/  
    $faq_label = array(
        'name' => esc_html_x('Faq', 'Post Type General Name', 'mombo-core'),
        'singular_name' => esc_html_x('Faq', 'Post Type Singular Name', 'mombo-core'),
        'menu_name' => esc_html__('Help Desk', 'mombo-core'),
        'parent_item_colon' => esc_html__('Parent Faq:', 'mombo-core'),
        'all_items' => esc_html__('All Faq', 'mombo-core'),
        'view_item' => esc_html__('View Faq', 'mombo-core'),
        'add_new_item' => esc_html__('Add New Faq', 'mombo-core'),
        'add_new' => esc_html__('New Faq', 'mombo-core'),
        'edit_item' => esc_html__('Edit Faq', 'mombo-core'),
        'update_item' => esc_html__('Update Faq', 'mombo-core'),
        'search_items' => esc_html__('Search Faq', 'mombo-core'),
        'not_found' => esc_html__('No faq found', 'mombo-core'),
        'not_found_in_trash' => esc_html__('No faq found in Trash', 'mombo-core'),
    );
    $faq_args = array(
        'label' => esc_html__('Faq', 'mombo-core'),
        'description' => esc_html__('Faq', 'mombo-core'),
        'labels' => $faq_label,
        'supports' => array('title', 'editor', 'thumbnail'),
        'taxonomies' => array('faq-category', 'faq-tag'),
        'hierarchical' => false,
        'public' => true,
        'show_in_rest' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => true,
        'show_in_admin_bar' => true,
        'menu_position' => 20,
        'menu_icon' => 'dashicons-phone',
        'can_export' => true,
        'has_archive' => true,
        'exclude_from_search' => true,
        'publicly_queryable' => true,
        'capability_type' => 'page',
    );
    register_post_type('faq', $faq_args);   

    $faq_topic_labels = array(
        'name'              => esc_html__( 'Help Topics','mombo-core' ),
        'singular_name'     => esc_html__( 'Help Topics','mombo-core' ),
        'search_items'      => esc_html__( 'Search Help Topic','mombo-core' ),
        'all_items'         => esc_html__( 'All Help Topic','mombo-core' ),
        'parent_item'       => esc_html__( 'Parent Help Topic','mombo-core' ),
        'parent_item_colon' => esc_html__( 'Parent Help Topic:','mombo-core' ),
        'edit_item'         => esc_html__( 'Edit Help Topic','mombo-core' ),
        'update_item'       => esc_html__( 'Update Help Topic','mombo-core' ),
        'add_new_item'      => esc_html__( 'Add New Help Topic','mombo-core' ),
        'new_item_name'     => esc_html__( 'New Help Topic Name','mombo-core' ),
        'menu_name'         => esc_html__( 'Help Topic','mombo-core' ),
    );    

    // register the faq-topic taxonomy
    register_taxonomy('faq-topic', array('faq'), array(
        'hierarchical' => true,
        'labels' => $faq_topic_labels,
        'query_var' => true,
        'show_in_rest' => true,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array( 'slug' => 'faq-topic' ),
    )); 
    
    $faq_category_labels = array(
        'name'              => esc_html__( 'Faq Categories','mombo-core' ),
        'singular_name'     => esc_html__( 'Faq Categories','mombo-core' ),
        'search_items'      => esc_html__( 'Search Faq Category','mombo-core' ),
        'all_items'         => esc_html__( 'All Faq Category','mombo-core' ),
        'parent_item'       => esc_html__( 'Parent Faq Category','mombo-core' ),
        'parent_item_colon' => esc_html__( 'Parent Faq Category:','mombo-core' ),
        'edit_item'         => esc_html__( 'Edit Faq Category','mombo-core' ),
        'update_item'       => esc_html__( 'Update Faq Category','mombo-core' ),
        'add_new_item'      => esc_html__( 'Add New Faq Category','mombo-core' ),
        'new_item_name'     => esc_html__( 'New Faq Category Name','mombo-core' ),
        'menu_name'         => esc_html__( 'Faq Category','mombo-core' ),
    );    

    // register the faq-category taxonomy
    register_taxonomy('faq-category', array('faq'), array(
        'hierarchical' => true,
        'labels' => $faq_category_labels,
        'query_var' => true,
        'show_in_rest' => true,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array( 'slug' => 'faq-category' ),
    ));   
    
    $faq_tag_labels = array(
        'name'              => esc_html__( 'Faq Tags','mombo-core' ),
        'singular_name'     => esc_html__( 'Faq Tags','mombo-core' ),
        'search_items'      => esc_html__( 'Search Faq Tag','mombo-core' ),
        'all_items'         => esc_html__( 'All Faq Tag','mombo-core' ),
        'parent_item'       => esc_html__( 'Parent Faq Tag','mombo-core' ),
        'parent_item_colon' => esc_html__( 'Parent Faq Tag:','mombo-core' ),
        'edit_item'         => esc_html__( 'Edit Faq Tag','mombo-core' ),
        'update_item'       => esc_html__( 'Update Faq Tag','mombo-core' ),
        'add_new_item'      => esc_html__( 'Add New Faq Tag','mombo-core' ),
        'new_item_name'     => esc_html__( 'New Faq Tag Name','mombo-core' ),
        'menu_name'         => esc_html__( 'Faq Tag','mombo-core' ),
    );    

    // register the faq-tag taxonomy
    register_taxonomy('faq-tag', array('faq'), array(
        'hierarchical' => false,
        'labels' => $faq_tag_labels,
        'query_var' => true,
        'show_in_rest' => true,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array( 'slug' => 'faq-tag' ),
    ));   

}
endif;
add_action('init', 'mombo_faq_custom_posts', 0); 
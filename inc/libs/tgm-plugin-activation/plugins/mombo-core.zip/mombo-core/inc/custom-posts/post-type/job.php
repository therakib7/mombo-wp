<?php
/**
 *  Mombo Register Custom Post Job
 *
 * @package Mombo
 * @since 1.0
 */
if ( ! function_exists( 'mombo_job_custom_posts' ) ) :
function mombo_job_custom_posts() {

    /* Job Custom Post*/  
    $job_label = array(
        'name' => esc_html_x('Job', 'Post Type General Name', 'mombo-core'),
        'singular_name' => esc_html_x('Job', 'Post Type Singular Name', 'mombo-core'),
        'menu_name' => esc_html__('Career', 'mombo-core'),
        'parent_item_colon' => esc_html__('Parent Job:', 'mombo-core'),
        'all_items' => esc_html__('All Job', 'mombo-core'),
        'view_item' => esc_html__('View Job', 'mombo-core'),
        'add_new_item' => esc_html__('Add New Job', 'mombo-core'),
        'add_new' => esc_html__('New Job', 'mombo-core'),
        'edit_item' => esc_html__('Edit Job', 'mombo-core'),
        'update_item' => esc_html__('Update Job', 'mombo-core'),
        'search_items' => esc_html__('Search Job', 'mombo-core'),
        'not_found' => esc_html__('No job found', 'mombo-core'),
        'not_found_in_trash' => esc_html__('No job found in Trash', 'mombo-core'),
    );
    $job_args = array(
        'label' => esc_html__('Job', 'mombo-core'),
        'description' => esc_html__('Job', 'mombo-core'),
        'labels' => $job_label,
        'supports' => array('title', 'editor'),
        'taxonomies' => array('job-category', 'job-tag'),
        'hierarchical' => false,
        'public' => true,
        'show_in_rest' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => true,
        'show_in_admin_bar' => true,
        'menu_position' => 20,
        'menu_icon' => 'dashicons-groups',
        'can_export' => true,
        'has_archive' => true,
        'exclude_from_search' => true,
        'publicly_queryable' => true,
        'capability_type' => 'page',
    );
    register_post_type('job', $job_args);   
   
    $job_category_labels = array(
        'name'              => esc_html__( 'Job Categories','mombo-core' ),
        'singular_name'     => esc_html__( 'Job Categories','mombo-core' ),
        'search_items'      => esc_html__( 'Search Job Category','mombo-core' ),
        'all_items'         => esc_html__( 'All Job Category','mombo-core' ),
        'parent_item'       => esc_html__( 'Parent Job Category','mombo-core' ),
        'parent_item_colon' => esc_html__( 'Parent Job Category:','mombo-core' ),
        'edit_item'         => esc_html__( 'Edit Job Category','mombo-core' ),
        'update_item'       => esc_html__( 'Update Job Category','mombo-core' ),
        'add_new_item'      => esc_html__( 'Add New Job Category','mombo-core' ),
        'new_item_name'     => esc_html__( 'New Job Category Name','mombo-core' ),
        'menu_name'         => esc_html__( 'Job Category','mombo-core' ),
    );    
 
    register_taxonomy('job-category', array('job'), array(
        'hierarchical' => true,
        'labels' => $job_category_labels,
        'query_var' => true,
        'show_in_rest' => true,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array( 'slug' => 'job-category' ),
    ));    

    $job_location_labels = array(
        'name'              => esc_html__( 'Job Locations','mombo-core' ),
        'singular_name'     => esc_html__( 'Job Locations','mombo-core' ),
        'search_items'      => esc_html__( 'Search Job Location','mombo-core' ),
        'all_items'         => esc_html__( 'All Job Location','mombo-core' ),
        'parent_item'       => esc_html__( 'Parent Job Location','mombo-core' ),
        'parent_item_colon' => esc_html__( 'Parent Job Location:','mombo-core' ),
        'edit_item'         => esc_html__( 'Edit Job Location','mombo-core' ),
        'update_item'       => esc_html__( 'Update Job Location','mombo-core' ),
        'add_new_item'      => esc_html__( 'Add New Job Location','mombo-core' ),
        'new_item_name'     => esc_html__( 'New Job Location Name','mombo-core' ),
        'menu_name'         => esc_html__( 'Job Location','mombo-core' ),
    );    
 
    register_taxonomy('job-location', array('job'), array(
        'hierarchical' => true,
        'labels' => $job_location_labels,
        'query_var' => true,
        'show_in_rest' => true,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array( 'slug' => 'job-location' ),
    )); 

    $job_tag_labels = array(
        'name'              => esc_html__( 'Job Tags','mombo-core' ),
        'singular_name'     => esc_html__( 'Job Tags','mombo-core' ),
        'search_items'      => esc_html__( 'Search Job Tag','mombo-core' ),
        'all_items'         => esc_html__( 'All Job Tag','mombo-core' ),
        'parent_item'       => esc_html__( 'Parent Job Tag','mombo-core' ),
        'parent_item_colon' => esc_html__( 'Parent Job Tag:','mombo-core' ),
        'edit_item'         => esc_html__( 'Edit Job Tag','mombo-core' ),
        'update_item'       => esc_html__( 'Update Job Tag','mombo-core' ),
        'add_new_item'      => esc_html__( 'Add New Job Tag','mombo-core' ),
        'new_item_name'     => esc_html__( 'New Job Tag Name','mombo-core' ),
        'menu_name'         => esc_html__( 'Job Tag','mombo-core' ),
    );    

    // register the job-tag taxonomy
    register_taxonomy('job-tag', array('job'), array(
        'hierarchical' => false,
        'labels' => $job_tag_labels,
        'query_var' => true,
        'show_in_rest' => true,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array( 'slug' => 'job-tag' ),
    ));   

}
endif;
add_action('init', 'mombo_job_custom_posts', 0);
<?php
/**
 *  Mombo Register Custom Post Type
 *
 * @package Mombo
 * @since 1.0
 */

 //Require all PHP files in the /elementor/widgets directory
foreach( glob( plugin_dir_path( __FILE__ ) . "post-type/*.php" ) as $file ) {
    require_once $file; 
} 

add_action( 'init', 'mombo_elementor_post_type_support' );
function mombo_elementor_post_type_support() {
    //if exists, assign to $cpt_support var
    $cpt_support = get_option( 'elementor_cpt_support' );
    
    //check if option DOESN'T exist in db
    if( ! $cpt_support ) {
        $cpt_support = [ 'page', 'post', 'portfolio', 'faq', 'job', 'template' ]; //create array of our default supported post types
        update_option( 'elementor_cpt_support', $cpt_support ); //write it to the database
    } else if( ! in_array( 'portfolio', $cpt_support ) || ! in_array( 'faq', $cpt_support ) || ! in_array( 'job', $cpt_support ) || ! in_array( 'template', $cpt_support ) ) {
        $cpt_support[] = 'portfolio'; //append to array
        $cpt_support[] = 'faq'; //append to array
        $cpt_support[] = 'job'; //append to array
        $cpt_support[] = 'template'; //append to array
        update_option( 'elementor_cpt_support', $cpt_support ); //update database
    } 
    //otherwise do nothing, portfolio already exists in elementor_cpt_support option
}

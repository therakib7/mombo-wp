<?php
/**
 *  Mombo Register Custom Post Portfolio
 *
 * @package Mombo
 * @since 1.0
 */
if ( ! function_exists( 'mombo_portfolio_custom_posts' ) ) :
function mombo_portfolio_custom_posts() {

    /* Portfolio Custom Post*/  
    $portfolio_label = array(
        'name' => esc_html_x('Portfolio', 'Post Type General Name', 'mombo-core'),
        'singular_name' => esc_html_x('Portfolio', 'Post Type Singular Name', 'mombo-core'),
        'menu_name' => esc_html__('Portfolio', 'mombo-core'),
        'parent_item_colon' => esc_html__('Parent Portfolio:', 'mombo-core'),
        'all_items' => esc_html__('All Portfolio', 'mombo-core'),
        'view_item' => esc_html__('View Portfolio', 'mombo-core'),
        'add_new_item' => esc_html__('Add New Portfolio', 'mombo-core'),
        'add_new' => esc_html__('New Portfolio', 'mombo-core'),
        'edit_item' => esc_html__('Edit Portfolio', 'mombo-core'),
        'update_item' => esc_html__('Update Portfolio', 'mombo-core'),
        'search_items' => esc_html__('Search Portfolio', 'mombo-core'),
        'not_found' => esc_html__('No portfolio found', 'mombo-core'),
        'not_found_in_trash' => esc_html__('No portfolio found in Trash', 'mombo-core'),
    );
    $portfolio_args = array(
        'label' => esc_html__('Portfolio', 'mombo-core'),
        'description' => esc_html__('Portfolio', 'mombo-core'),
        'labels' => $portfolio_label,
        'supports' => array('title', 'editor', 'thumbnail'),
        'taxonomies' => array('portfolio-category', 'portfolio-tag'),
        'hierarchical' => false,
        'public' => true,
        'show_in_rest' => true,
        'show_ui' => true,
        'show_in_menu' => true, 
        'show_in_nav_menus' => true,
        'show_in_admin_bar' => true,
        'menu_position' => 20,
        'menu_icon' => 'dashicons-screenoptions',
        'can_export' => true,
        'has_archive' => true,
        'exclude_from_search' => true,
        'publicly_queryable' => true,
        'capability_type' => 'page',
    );
    register_post_type('portfolio', $portfolio_args);   

    // Add new taxonomy, make it hierarchical (like categories) 
    $portfolio_category_labels = array(
        'name'              => esc_html__( 'Portfolio Categories','mombo-core' ),
        'singular_name'     => esc_html__( 'Portfolio Categories','mombo-core' ),
        'search_items'      => esc_html__( 'Search Portfolio Category','mombo-core' ),
        'all_items'         => esc_html__( 'All Portfolio Category','mombo-core' ),
        'parent_item'       => esc_html__( 'Parent Portfolio Category','mombo-core' ),
        'parent_item_colon' => esc_html__( 'Parent Portfolio Category:','mombo-core' ),
        'edit_item'         => esc_html__( 'Edit Portfolio Category','mombo-core' ),
        'update_item'       => esc_html__( 'Update Portfolio Category','mombo-core' ),
        'add_new_item'      => esc_html__( 'Add New Portfolio Category','mombo-core' ),
        'new_item_name'     => esc_html__( 'New Portfolio Category Name','mombo-core' ),
        'menu_name'         => esc_html__( 'Portfolio Category','mombo-core' ),
    );    

    // register the portfolio-category taxonomy
    register_taxonomy('portfolio-category', array('portfolio'), array(
        'hierarchical' => true,
        'labels' => $portfolio_category_labels,
        'query_var' => true,
        'show_in_rest' => true,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array( 'slug' => 'portfolio-category' ),
    ));   

    // Add new taxonomy, make it hierarchical (like categories) 
    $portfolio_tag_labels = array(
        'name'              => esc_html__( 'Portfolio Tags','mombo-core' ),
        'singular_name'     => esc_html__( 'Portfolio Tags','mombo-core' ),
        'search_items'      => esc_html__( 'Search Portfolio Tag','mombo-core' ),
        'all_items'         => esc_html__( 'All Portfolio Tag','mombo-core' ),
        'parent_item'       => esc_html__( 'Parent Portfolio Tag','mombo-core' ),
        'parent_item_colon' => esc_html__( 'Parent Portfolio Tag:','mombo-core' ),
        'edit_item'         => esc_html__( 'Edit Portfolio Tag','mombo-core' ),
        'update_item'       => esc_html__( 'Update Portfolio Tag','mombo-core' ),
        'add_new_item'      => esc_html__( 'Add New Portfolio Tag','mombo-core' ),
        'new_item_name'     => esc_html__( 'New Portfolio Tag Name','mombo-core' ),
        'menu_name'         => esc_html__( 'Portfolio Tag','mombo-core' ),
    );    

    // register the portfolio-tag taxonomy
    register_taxonomy('portfolio-tag', array('portfolio'), array(
        'hierarchical' => false,
        'labels' => $portfolio_tag_labels,
        'query_var' => true,
        'show_in_rest' => true,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array( 'slug' => 'portfolio-tag' ),
    ));   

}
endif;
add_action('init', 'mombo_portfolio_custom_posts', 0);


function mombo_portfolio_meta_boxes( $post_type, $post ) {
    add_meta_box( 
        'portfolio-meta-box',
        esc_html__('Portfolio Options', 'mombo-core'),
        'mombo_portfolio_meta_box',
        'portfolio',
        'normal',
        'default'
    );
}
add_action( 'add_meta_boxes', 'mombo_portfolio_meta_boxes', 10, 2 );

function mombo_portfolio_meta_box( $post ) {   
    $value = get_post_meta($post->ID, 'mombo_portfolio_style', true); 
    if ( !$value ) {
        $value = 'square';
    }
    ?>
    <table>
        <tr>
            <td><label for="mombo_portfolio_style"><?php esc_html_e( 'Portfolio Style:', 'mombo-core' ); ?></label></td>
            <td>
            <select name="mombo_portfolio_style" id="mombo_portfolio_style" class="widefat"> 
                <option value="square" <?php selected($value, 'square'); ?>><?php esc_html_e( 'Square', 'mombo-core' ); ?></option>
                <option value="vertical" <?php selected($value, 'vertical'); ?>><?php esc_html_e( 'Vertical', 'mombo-core' ); ?></option> 
            </select> 
            </td>
        </tr>
        <tr>
            <td></td>
            <td>
                <span><?php esc_html_e( 'Choose how look life portfolio style', 'mombo-core' ); ?></span>
            </td>
        </tr>
    </table> 
<?php }

function mombo_save_portfolio_postdata($post_id) {
    if ( array_key_exists('mombo_portfolio_style', $_POST) ) {
        update_post_meta(
            $post_id,
            'mombo_portfolio_style',
            $_POST['mombo_portfolio_style']
        );
    }
}
add_action('save_post', 'mombo_save_portfolio_postdata');
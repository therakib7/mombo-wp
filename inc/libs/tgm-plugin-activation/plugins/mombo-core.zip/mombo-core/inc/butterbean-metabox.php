<?php 
/**
 *  Mombo page meta box
 *
 * @package Mombo
 * @since 1.0
 */

class Mombo_Metabox {
 
	private static $instance = null;

	/**
	 * @since 1.0
	 */
	public static function get_instance() {
	    if ( ! self::$instance )
	       self::$instance = new self;
	    return self::$instance;
	}

	/**
	 * @since 1.0
	 */
	public function init(){
		add_action( 'plugins_loaded', array( $this, 'load_butterbean' ) );
        add_action( 'butterbean_register', array( $this, 'add_metabox' ), 10, 2 );
	}

	/**
	 * @since 1.0
	 */
	public function load_butterbean() {
        require_once plugin_dir_path( __FILE__ ) . 'butterbean/butterbean.php';
	}

	/**
	 * @since 1.0
	 */
	public function add_metabox( $butterbean, $post_type ) {
        // Post types to add the metabox to
        $post_type = array(
            'post',
            'page',
            'product',
            'elementor_library',
            'ae_global_templates',
        );
        
        $prefix = 'mombo_mb_';
        
        $butterbean->register_manager(
            $prefix . 'settings',
            array(
                'label'     => esc_html__( 'Custom Settings', 'mombo-core' ),
                'post_type' => $post_type,
                'context'   => 'normal',
                'priority'  => 'high'
            )
        ); 
        $manager = $butterbean->get_manager( $prefix . 'settings' );

        // layout
        $manager->register_section(
            $prefix . 'layout',
            array(
                'label' => esc_html__( 'Layout', 'mombo-core' ),
                'icon'  => 'dashicons-admin-generic'
            )
        );

        $manager->register_control(
            $prefix . 'header_part', 
            array(
                'section' => $prefix . 'layout',
                'type'          => 'radio',
                'label'         => esc_html__( 'Header Part', 'mombo-core' ), 
                'choices'       => array(
                    'show'      => esc_html__( 'Show', 'mombo-core' ),
                    'hide'   => esc_html__( 'Hide', 'mombo-core' ), 
                ),
            )
        ); 
        $manager->register_setting(
            $prefix . 'header_part', // Same as control name.
            array(
                'sanitize_callback' => 'wp_filter_nohtml_kses',
                'default'           => 'show',
            )
        ); 

        $manager->register_control(
            $prefix . 'footer_part', 
            array(
                'section' => $prefix . 'layout',
                'type'          => 'radio',
                'label'         => esc_html__( 'Footer Part', 'mombo-core' ), 
                'choices'       => array(
                    'show'      => esc_html__( 'Show', 'mombo-core' ),
                    'hide'   => esc_html__( 'Hide', 'mombo-core' ), 
                ),
            )
        ); 
        $manager->register_setting(
            $prefix . 'footer_part', // Same as control name.
            array(
                'sanitize_callback' => 'wp_filter_nohtml_kses',
                'default'           => 'show',
            )
        );

        $butterbean->register_manager(
            $prefix . 'job_settings',
            array(
                'label'     => esc_html__( 'Job Details', 'mombo-core' ),
                'post_type' => 'job', // no need to append
                'context'   => 'normal',
                'priority'  => 'high'
            )
        ); 
        $manager = $butterbean->get_manager( $prefix . 'job_settings' );

        // job_setting
        $manager->register_section(
            $prefix . 'job_setting',
            array(
                'label' => esc_html__( 'Settings', 'mombo-core' ),
                'icon'  => 'dashicons-admin-generic'
            )
        ); 

        $manager->register_setting(
            $prefix . 'gallery', // Same as control name.
            array(
                'sanitize_callback' => 'wp_filter_nohtml_kses',
                'default'           => '',
            )
        ); 

        $manager->register_control(
            $prefix . 'experiance', 
            array(
                'section' => $prefix . 'job_setting',
                'type'          => 'text',
                'label'         => esc_html__( 'Experiance', 'mombo-core' ),   
            )
        ); 
        $manager->register_setting(
            $prefix . 'experiance', // Same as control name.
            array(
                'sanitize_callback' => 'wp_filter_nohtml_kses',
                'default'           => '',
            )
        );

        $manager->register_control(
            $prefix . 'seniority_level', 
            array(
                'section' => $prefix . 'job_setting',
                'type'          => 'text',
                'label'         => esc_html__( 'Seniority level', 'mombo-core' ),   
            )
        ); 
        $manager->register_setting(
            $prefix . 'seniority_level', // Same as control name.
            array(
                'sanitize_callback' => 'wp_filter_nohtml_kses',
                'default'           => '',
            )
        );

        $manager->register_control(
            $prefix . 'employment_type', 
            array(
                'section' => $prefix . 'job_setting',
                'type'          => 'text',
                'label'         => esc_html__( 'Employment type', 'mombo-core' ),   
            )
        ); 
        $manager->register_setting(
            $prefix . 'employment_type', // Same as control name.
            array(
                'sanitize_callback' => 'wp_filter_nohtml_kses',
                'default'           => '',
            )
        );

        $manager->register_control(
            $prefix . 'job_type', 
            array(
                'section' => $prefix . 'job_setting',
                'type'          => 'text',
                'label'         => esc_html__( 'Job type', 'mombo-core' ),   
                'description' => esc_html__( 'Full Time/Part Time Job', 'mombo-core' ),
            )
        ); 
        $manager->register_setting(
            $prefix . 'job_type', // Same as control name.
            array(
                'sanitize_callback' => 'wp_filter_nohtml_kses',
                'default'           => 'ffff',
            )
        ); 

        $manager->register_control(
            $prefix . 'gallery', 
            array(
                'section' => $prefix . 'job_setting',
                'type'          => 'gallery',
                'label'         => esc_html__( 'Gallery', 'mombo-core' ),   
            )
        );  
		  
	}
}
 
Mombo_Metabox::get_instance()->init();


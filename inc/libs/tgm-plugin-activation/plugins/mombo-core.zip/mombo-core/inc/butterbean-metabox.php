<?php 
/**
 *  Mombo page meta box
 *
 * @package Mombo
 * @since 1.0
 */

class Mombo_Metabox {
 
	private static $instance = null;

	/**
	 * @since 1.0
	 */
	public static function get_instance() {
	    if ( ! self::$instance )
	       self::$instance = new self;
	    return self::$instance;
	}

	/**
	 * @since 1.0
	 */
	public function init(){
		add_action( 'plugins_loaded', array( $this, 'load_butterbean' ) );
        add_action( 'butterbean_register', array( $this, 'add_metabox' ), 10, 2 );
	}

	/**
	 * @since 1.0
	 */
	public function load_butterbean() {
        require_once plugin_dir_path( __FILE__ ) . 'butterbean/butterbean.php';
	}

	/**
	 * @since 1.0
	 */
	public function add_metabox( $butterbean, $post_type ) {
        // Post types to add the metabox to
        $post_type = array(
            'post',
            'page', 
            'product',
            'elementor_library',
            'ae_global_templates',
        );
        
        $prefix = 'mombo_mb_';
        
        $butterbean->register_manager(
            $prefix . 'settings',
            array(
                'label'     => esc_html__( 'Layout Settings', 'mombo-core' ),
                'post_type' => $post_type,
                'context'   => 'normal',
                'priority'  => 'high'
            )
        ); 
        $manager = $butterbean->get_manager( $prefix . 'settings' );

        // header
        $manager->register_section(
            $prefix . 'header',
            array(
                'label' => esc_html__( 'Header', 'mombo-core' ),
                'icon'  => ''
            )
        );

        $manager->register_control(
            $prefix . 'header_part', 
            array(
                'section' => $prefix . 'header',
                'type'          => 'select',
                'label'         => esc_html__( 'Header Part', 'mombo-core' ), 
                'choices'       => array(
                    'show'      => esc_html__( 'Show', 'mombo-core' ),
                    'hide'      => esc_html__( 'Hide', 'mombo-core' ), 
                    'custom'   => esc_html__( 'Custom Template', 'mombo-core' ), 
                ),
            )
        ); 
        $manager->register_setting(
            $prefix . 'header_part', 
            array(
                'sanitize_callback' => 'wp_filter_nohtml_kses',
                'default'           => 'show',
            )
        ); 

        $header_templates = [ 0 => esc_html__( 'Default', 'mombo' ) ];
        $args = array(
            'posts_per_page' => -1,  
            'post_type' => 'template',
            'meta_key' => 'mombo_template_type',
            'meta_value'  => 'header',
            'meta_compare' => '==', 
        );
        $the_query = new WP_Query( $args ); 
        while ( $the_query->have_posts() ) : $the_query->the_post();
            $header_templates[ get_the_ID() ] = get_the_title();
        endwhile; wp_reset_postdata();

        $manager->register_control(
            $prefix . 'header_custom_template', 
            array(
                'section' => $prefix . 'header',
                'type'          => 'select',
                'label'         => esc_html__( 'Header Custom Template', 'mombo-core' ), 
                'choices'       => $header_templates,
            )
        ); 
        $manager->register_setting(
            $prefix . 'header_custom_template', 
            array(
                'sanitize_callback' => 'wp_filter_nohtml_kses',
                'default'           => 0,
            )
        );         

        // footer
        $manager->register_section(
            $prefix . 'footer',
            array(
                'label' => esc_html__( 'Footer', 'mombo-core' ),
                'icon'  => ''
            )
        );

        $manager->register_control(
            $prefix . 'footer_part', 
            array(
                'section' => $prefix . 'footer',
                'type'          => 'select',
                'label'         => esc_html__( 'Footer Part', 'mombo-core' ), 
                'choices'       => array(
                    'show'      => esc_html__( 'Show', 'mombo-core' ),
                    'hide'   => esc_html__( 'Hide', 'mombo-core' ), 
                    'custom'   => esc_html__( 'Custom Template', 'mombo-core' ),
                ),
            )
        ); 
        $manager->register_setting(
            $prefix . 'footer_part', 
            array(
                'sanitize_callback' => 'wp_filter_nohtml_kses',
                'default'           => 'show',
            )
        );

        $footer_templates = [ 0 => esc_html__( 'Default', 'mombo' ) ];
        $args = array(
            'posts_per_page' => -1,  
            'post_type' => 'template',
            'meta_key' => 'mombo_template_type',
            'meta_value'  => 'footer',
            'meta_compare' => '==', 
        );
        $the_query = new WP_Query( $args ); 
        while ( $the_query->have_posts() ) : $the_query->the_post();
            $footer_templates[ get_the_ID() ] = get_the_title();
        endwhile; wp_reset_postdata();

        $manager->register_control(
            $prefix . 'footer_custom_template', 
            array(
                'section' => $prefix . 'footer',
                'type'          => 'select',
                'label'         => esc_html__( 'Footer Custom Template', 'mombo-core' ), 
                'choices'       => $footer_templates,
            )
        ); 
        $manager->register_setting(
            $prefix . 'footer_custom_template', 
            array(
                'sanitize_callback' => 'wp_filter_nohtml_kses',
                'default'           => 0,
            )
        );

        // job_setting
        $butterbean->register_manager(
            $prefix . 'job_settings',
            array(
                'label'     => esc_html__( 'Job Details', 'mombo-core' ),
                'post_type' => 'job', // no need to append
                'context'   => 'normal',
                'priority'  => 'high'
            )
        ); 
        $manager = $butterbean->get_manager( $prefix . 'job_settings' ); 
        
        $manager->register_section(
            $prefix . 'job_setting',
            array(
                'label' => esc_html__( 'Settings', 'mombo-core' ),
                'icon'  => 'dashicons-admin-generic'
            )
        ); 

        $manager->register_setting(
            $prefix . 'gallery', 
            array(
                'sanitize_callback' => 'wp_filter_nohtml_kses',
                'default'           => '',
            )
        ); 

        $manager->register_control(
            $prefix . 'experiance', 
            array(
                'section' => $prefix . 'job_setting',
                'type'          => 'text',
                'label'         => esc_html__( 'Experiance', 'mombo-core' ),   
            )
        ); 
        $manager->register_setting(
            $prefix . 'experiance', 
            array(
                'sanitize_callback' => 'wp_filter_nohtml_kses',
                'default'           => '',
            )
        );

        $manager->register_control(
            $prefix . 'seniority_level', 
            array(
                'section' => $prefix . 'job_setting',
                'type'          => 'text',
                'label'         => esc_html__( 'Seniority level', 'mombo-core' ),   
            )
        ); 
        $manager->register_setting(
            $prefix . 'seniority_level', 
            array(
                'sanitize_callback' => 'wp_filter_nohtml_kses',
                'default'           => '',
            )
        );

        $manager->register_control(
            $prefix . 'employment_type', 
            array(
                'section' => $prefix . 'job_setting',
                'type'          => 'text',
                'label'         => esc_html__( 'Employment type', 'mombo-core' ),   
            )
        ); 
        $manager->register_setting(
            $prefix . 'employment_type', 
            array(
                'sanitize_callback' => 'wp_filter_nohtml_kses',
                'default'           => '',
            )
        );

        $manager->register_control(
            $prefix . 'job_type', 
            array(
                'section' => $prefix . 'job_setting',
                'type'          => 'text',
                'label'         => esc_html__( 'Job type', 'mombo-core' ),   
                'description' => esc_html__( 'Full Time/Part Time Job', 'mombo-core' ),
            )
        ); 
        $manager->register_setting(
            $prefix . 'job_type', 
            array(
                'sanitize_callback' => 'wp_filter_nohtml_kses',
                'default'           => 'ffff',
            )
        ); 

        $manager->register_control(
            $prefix . 'gallery', 
            array(
                'section' => $prefix . 'job_setting',
                'type'          => 'gallery',
                'label'         => esc_html__( 'Gallery', 'mombo-core' ),   
            )
        );  
		  
	}
}
 
Mombo_Metabox::get_instance()->init();


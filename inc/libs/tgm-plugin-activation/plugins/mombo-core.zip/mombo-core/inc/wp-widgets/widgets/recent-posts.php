<?php
/**
 * Add recent posts widget.
 * @since    1.0
 * @package Mombo
 */
class Mombo_Recent_Posts extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {
		parent::__construct(
			'mombo_recent_posts', // Base ID
			esc_html__( 'Mombo: Recent Posts', 'mombo-core' ), // Name
			array( 'description' => esc_html__( 'Mombo: Recent Posts', 'mombo-core' ), ) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {
		echo $args['before_widget'];
		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
		} ?> 
        <div class="list-group list-group-flush">
			<?php 
				$recent_post = new WP_Query( 
					array( 
						'posts_per_page' => $instance['limit'],  
						'ignore_sticky_posts' => true  
					) 
				);
				while( $recent_post->have_posts() ) :
					$recent_post->the_post(); 
			?>
			<a href="<?php the_permalink(); ?>" class="list-group-item list-group-item-action d-flex p15px-tb"> 
				<?php if ( has_post_thumbnail() ) { ?>
				<div>
					<div class="avatar-50 border-radius-5">
						<?php mombo_post_featured_image(50, 50, true, false); ?> 
					</div> 
				</div>
				<?php } ?>
				<div class="p-15px-l">
					<p class="m-0px"><?php the_title(); ?></p>
				</div>
			</a>
			<?php endwhile; ?>
		</div>
		<?php echo $args['after_widget'];
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'Recent Posts', 'mombo-core' );
		$limit = ! empty( $instance['limit'] ) ? $instance['limit'] : 5;
		?>
		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'mombo-core' ); ?></label> 
            <input 
            class="widefat" 
            id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" 
            name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" 
            type="text" 
            value="<?php echo esc_attr( $title ); ?>" />
		</p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'limit' ) ); ?>"><?php esc_attr_e( 'Number of posts to show:', 'mombo-core' ); ?></label> 
            <input  
            id="<?php echo esc_attr( $this->get_field_id( 'limit' ) ); ?>" 
            name="<?php echo esc_attr( $this->get_field_name( 'limit' ) ); ?>" 
            type="text" 
            size="3"
            value="<?php echo esc_attr( $limit ); ?>" />
		</p>  
		<?php 
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
        $instance['title'] = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
        $instance['limit'] = ( ! empty( $new_instance['limit'] ) ) ? intval( $new_instance['limit'] ) : '';

		return $instance;
	}

} // class Mombo_Recent_Posts
<?php
/**
 * Load and register widgets
 *
 * @package Ramble
 */


//Require all PHP files in the /elementor/widgets directory
foreach( glob( plugin_dir_path( __FILE__ ) . "widgets/*.php" ) as $file ) {
    require_once $file; 
} 

/**
 * Register widgets
 */

add_action('widgets_init','mombo_core_register_widgets');
function mombo_core_register_widgets() {
    register_widget('Mombo_Recent_Posts'); 
    register_widget('Mombo_Categories');
}







<?php
/**
 * Plugin Name:          Make Column Clickable Elementor
 * @package Fernando_Acosta
 */

if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly.
}

if ( !class_exists('Make_Column_Clickable_Elementor') ) {
  class Make_Column_Clickable_Elementor {
    /**
     * Version.
     *
     * @var float
     */
    const VERSION = '1.3.1';
  
    /**
     * Instance of this class.
     *
     * @var object
     */
    protected static $instance = null;
    /**
     * Initialize the plugin public actions.
     */
    function __construct() {
      $this->includes();
    }
  
    public function includes() {
      // framework
      include_once 'includes/class-column-clickable.php';
    }
  
    /**
     * Return an instance of this class.
     *
     * @return object A single instance of this class.
     */
    public static function get_instance() {
      // If the single instance hasn't been set, set it now.
      if ( null == self::$instance ) {
        self::$instance = new self;
      }
      return self::$instance;
    }
  
    /**
     * Get main file.
     *
     * @return string
     */
    public static function get_main_file() {
      return __FILE__;
    }
  
    /**
     * Get plugin path.
     *
     * @return string
     */
  
    public static function get_plugin_path() {
      return plugin_dir_path( __FILE__ );
    }
  
    /**
     * Get the plugin url.
     * @return string
     */
    public static function plugin_url() {
      return untrailingslashit( plugins_url( '/', __FILE__ ) );
    }
  
    /**
     * Get the plugin dir url.
     * @return string
     */
    public static function plugin_dir_url() {
      return plugin_dir_url( __FILE__ );
    }
  } 
  add_action( 'plugins_loaded', array( 'Make_Column_Clickable_Elementor', 'get_instance' ) );
  
}

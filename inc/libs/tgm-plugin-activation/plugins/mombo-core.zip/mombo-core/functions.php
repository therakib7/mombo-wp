<?php 
/**
 * Some theme and plugin funcitons goes here
 */
/**
 *  Remove Unnecessary p and br tag from shortcode
 *
 * @package Mombo
 * @since 1.0
 */
if( !function_exists('mombo_fix_shortcodes') ) :
    function mombo_fix_shortcodes($content){
        $array = array (
            '<p>[' => '[',
            ']</p>' => ']',
            ']<br />' => ']'
        );
        $content = strtr($content, $array);
        return $content;   
    }
    add_filter('the_content', 'mombo_fix_shortcodes');
endif;

/**
 *  Mombo Social Post Share
 *
 * @package Mombo
 * @since 1.0
 */
if ( ! function_exists( 'mombo_social_share_link' ) ) :
function mombo_social_share_link( $before_text = "" ) { ?>
    <div class="p-25px-tb m-35px-tb border-top-1 border-bottom-1 border-color-gray">
        <div class="d-flex justify-content-between align-items-center">
            
            <?php if($before_text != ""): ?> 
            <div>
                <h5 class="m-0px"><?php echo esc_html($before_text); ?></h5>
            </div>   
            <?php endif; ?> 
            <div>
                <div class="nav justify-content-center justify-content-md-end social-icon si-30 gray">
                    <a class="social-btn-lg btn-gf bg-blue-violet color-white" target="_blank" rel="nofollow" title="<?php esc_html_e(  'Share on Facebook', 'litmus' ); ?>" href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>" onclick="mombo_PopupWindow(this.href, 'facebook-share', 580, 400); return false;">
                    <i class="fab fa-facebook"></i>
                    </a>
                    <a class="social-btn-lg btn-gf bg-blue-violet color-white" target="_blank" rel="nofollow" title="<?php esc_html_e(  'Share on Twitter', 'litmus' ); ?>" href="https://twitter.com/home?status=<?php the_permalink(); ?>"  onclick="mombo_PopupWindow(this.href, 'facebook-share', 580, 400); return false;">
                        <i class="fab fa-twitter"></i>
                    </a>

                    <a class="social-btn-lg btn-gf bg-blue-violet color-white" target="_blank" rel="nofollow" title="<?php esc_html_e(  'Share on GooglePlus', 'litmus' ); ?>" href="https://plus.google.com/share?url=<?php the_permalink(); ?>" onclick="mombo_PopupWindow(this.href, 'facebook-share', 580, 400); return false;">
                        <i class="fab fa-google-plus"></i>
                    </a>

                    <a class="social-btn-lg btn-gf bg-blue-violet color-white" target="_blank" rel="nofollow" title="<?php esc_html_e(  'Share on Linkedin', 'litmus' ); ?>" href="http://www.linkedin.com/shareArticle?mini=true&url=<?php the_permalink(); ?>" onclick="mombo_PopupWindow(this.href, 'facebook-share', 580, 400); return false;">
                        <i class="fab fa-linkedin"></i>
                    </a>
                    <a class="social-btn-lg btn-gf bg-blue-violet color-white" target="_blank" rel="nofollow" title="<?php esc_html_e(  'Share on Pinterest', 'litmus' ); ?>" href="javascript:void((function()%7Bvar%20e=document.createElement('script');e.setAttribute('type','text/javascript');e.setAttribute('charset','UTF-8');e.setAttribute('src','http://assets.pinterest.com/js/pinmarklet.js?r='+Math.random()*99999999);document.body.appendChild(e)%7D)());">
                        <i class="fab fa-pinterest-p"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <?php
}
endif;

/**
 *  Remove Query String
 *
 * @package Mombo
 * @since 1.0
 */
function mombo_remove_query_string_one( $src ){   
    $rqs = explode( '?ver', $src );
    return $rqs[0];
}
if ( !is_admin() ) { 
    add_filter( 'script_loader_src', 'mombo_remove_query_string_one', 15, 1 );
    add_filter( 'style_loader_src', 'mombo_remove_query_string_one', 15, 1 );
}

function mombo_remove_query_string_two( $src ){
    $rqs = explode( '&ver', $src );
    return $rqs[0];
}
if ( !is_admin() ) { 
    add_filter( 'script_loader_src', 'mombo_remove_query_string_two', 15, 1 );
    add_filter( 'style_loader_src', 'mombo_remove_query_string_two', 15, 1 );
}

add_action( 'template_redirect', 'mombo_coming_soon' );
function mombo_coming_soon() {
    if ( mombo_get_options( 'underconstruction' ) ) {
        if( !is_user_logged_in() && !is_page( mombo_get_options( 'underconstruction_page_id' ) ) ){
            wp_redirect( esc_url( get_page_link( mombo_get_options( 'underconstruction_page_id' ) ) ) );
            exit();
        }
    }
} 

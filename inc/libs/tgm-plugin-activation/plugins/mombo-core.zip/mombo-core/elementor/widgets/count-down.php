<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Mombo Count_Down Widget.
 *
 * Mombo widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0
 */

class Mombo_Count_Down_Widget extends Widget_Base {

	public function get_name() {
		return 'mombo-count-down';
	}

	public function get_title() {
		return esc_html__( 'Mombo: Count Down', 'mombo-core' );
	}

	public function get_icon() {
		return 'eicon-countdown';
	}

	public function get_categories() {
		return [ 'mombo-category' ];
	}

	/**
	 * Register Count_Down widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'mombo-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'heading',
			[
				'label' => esc_html__( 'Please choose time from customizer settings', 'mombo-core' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render Count_Down widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display(); 
		?> 
		<div class="text-center">
			<div class="count-down p-20px-t" id="clock_time"></div>
		</div>
		<?php  
	}

}

Plugin::instance()->widgets_manager->register_widget_type( new Mombo_Count_Down_Widget() );
<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Mombo Portfolio Widget.
 *
 * Mombo widget that inserts an embeddable content into the page, from any given URL.
 *
 * @since 1.0
 */

class Mombo_Portfolio_Widget extends Widget_Base {

	public function get_name() {
		return 'mombo-portfolio';
	}

	public function get_title() {
		return esc_html__( 'Mombo: Portfolio', 'mombo-core' );
	}

	public function get_icon() {
		return 'eicon-gallery-grid';
	}

	public function get_categories() {
		return [ 'mombo-category' ];
	}

	/**
	 * Register Portfolio widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'mombo-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'portfolio_style',
			[
				'label' => esc_html__( 'Portfolio Style', 'mombo-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'grid',
				'options' => [
					'grid' => esc_html__( 'Grid', 'mombo-core' ),
					'scroll' => esc_html__( 'Scroll', 'mombo-core' ),  
				],
			]
		); 

		$this->add_control(
			'number',
			[
				'label' => esc_html__( 'Total Post', 'mombo-core' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 12,
			]
		);	  
		$this->add_control(
			'show_tab',
			[
				'label' => esc_html__( 'Show Filter Tab?', 'mombo-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'mombo-core' ),
				'label_off' => esc_html__( 'No', 'mombo-core' ),
				'return_value' => 'yes',
				'default' => 'yes', 
			]
		);
		$this->add_control(
			'portfolio_post_style',
			[
				'label' => esc_html__( 'Portfolio Image Style Square?', 'mombo-core' ),
				'description' => esc_html__( 'If you choose no, it will show vertical and square style', 'mombo-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'mombo-core' ),
				'label_off' => esc_html__( 'No', 'mombo-core' ),
				'return_value' => 'yes',
				'default' => 'yes', 
			]
		);
		
		$this->end_controls_section(); 

	}

	/**
	 * Render Portfolio widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() { 
		$settings = $this->get_settings_for_display(); ?> 
		<!-- Section -->
		<style>
			#elementor-lightbox-slideshow-single-img {
				display: none !important;
			}
		</style> 
		<?php if ( $settings['portfolio_style'] == 'grid' ) { ?>
		<div class="portfolio-filter-01 m-30px-b" style="<?php if ( $settings['show_tab'] == '' ) { echo 'display: none;'; } ?>">
			<ul class="filter justify-content-center nav">
				<li class="active" data-filter="*"><?php esc_html_e('All', 'mombo-core'); ?></li> 
				<?php 
					$terms = get_terms( array(
						'taxonomy' => 'portfolio-category',
						'hide_empty' => false,
					) );
					$port_cat_slugs = [];
					foreach ($terms as $term) { 
					$port_cat_slugs[] = $term->slug;
				?>
				<li data-filter=".<?php echo esc_html($term->slug); ?>"><?php echo esc_html($term->name); ?></li> 
				<?php } ?>
			</ul>
		</div> <!-- Portfolio Filter --> 
		
		<div class="portfolio-content grid-gutter-md grid-col-3 lightbox-gallery">
			<?php 
			$portfolio_query = new \WP_Query(
				array(
					'post_type' => 'portfolio', 
					'posts_per_page' => $settings['number'],
					'tax_query' => array(
						array (
							'taxonomy' => 'portfolio-category',
							'field' => 'slug',
							'terms' => $port_cat_slugs,
						)
					),  
				)
			); 
			while ($portfolio_query->have_posts()) : $portfolio_query->the_post(); 

			$portfilio_cats = get_the_terms( get_the_ID(), 'portfolio-category' ); 
			$cats_name = "";
			foreach($portfilio_cats as $cat_name) {    
				$cats_name .= $cat_name->slug.' '; 
			}
			?> 
			<div class="grid-item product <?php echo esc_attr($cats_name); ?>">
				<div class="portfolio-box-02">
					<?php if ( has_post_thumbnail() ) { ?> 
					<div class="portfolio-img">
						<?php 
							if ( $settings['portfolio_post_style'] == '' && get_post_meta( get_the_ID(), 'mombo_portfolio_style', true) == 'vertical' ) {
								mombo_post_featured_image(359, 549, true); 
							} else {
								mombo_post_featured_image(359, 292, true); 
							} 
						?>
					</div>
					<?php } ?>
					<div class="portfolio-info">
						<div class="portfolio-desc">
							<h5><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
							<div class="pb-tag">
								<?php
								$portfilio_tags = get_the_terms( get_the_ID(), 'portfolio-tag' );  
								foreach($portfilio_tags as $tag) { 
									printf('<a href="%s">%s</a>', get_term_link( $tag->slug, 'portfolio-tag'), $tag->name);
								} ?> 
							</div>
						</div>
						<a href="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'full'); ?>" class="gallery-link">
							<i class="ti-plus"></i>
						</a>
					</div>
				</div>
			</div> <!-- grid item -->
			<?php endwhile; wp_reset_postdata(); ?> 
		</div> <!-- portfolio-content --> 
		<?php } else { ?>
		<div class="lightbox-gallery">
			<div class="owl-carousel" data-nav-dots="true" data-items="4" data-md-items="4" data-sm-items="3" data-xs-items="2" data-xx-items="1" data-space="0">
				<?php 
				$portfolio_query = new \WP_Query(
					array(
						'post_type' => 'portfolio', 
						'posts_per_page' => $settings['number'], 
					)
				); 
				while ($portfolio_query->have_posts()) : $portfolio_query->the_post();  
				?> 
				<div class="portfolio-box-02 p-10px box-shadow m-10px m-35px-b white-bg">
					<div class="portfolio-img">
						<?php mombo_post_featured_image(429, 348, false); ?>
					</div>
					<div class="portfolio-info">
						<div class="portfolio-desc">
							<h5><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
							<div class="pb-tag">
								<?php
								$portfilio_tags = get_the_terms( get_the_ID(), 'portfolio-tag' );  
								foreach($portfilio_tags as $tag) { 
									printf('<a href="%s">%s</a>', get_term_link( $tag->slug, 'portfolio-tag'), $tag->name);
								} ?> 
							</div>
						</div>
						<a href="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'full'); ?>" class="gallery-link">
							<i class="ti-plus"></i>
						</a>
					</div>
				</div>
				<?php endwhile; wp_reset_postdata(); ?> 
			</div>
		</div> 
		<?php }  ?>
	<?php } 
}

Plugin::instance()->widgets_manager->register_widget_type( new Mombo_Portfolio_Widget() );
<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Mombo PriceTable Widget.
 *
 * Mombo widget that inserts an embeddable content into the page, from any given URL.
 *
 * @since 1.0
 */

class Mombo_Price_Table_Widget extends Widget_Base {

	public function get_name() {
		return 'mombo-price-table';
	}

	public function get_title() {
		return esc_html__( 'Mombo: Price Table', 'mombo-core' );
	}

	public function get_icon() {
		return 'eicon-price-table';
	}

	public function get_categories() {
		return [ 'mombo-category' ];
	}

	/**
	 * Register PriceTable widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'mombo-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		); 

		$this->add_control(
			'table_style',
			[
				'label' => esc_html__( 'Table Style', 'mombo-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'one',
				'options' => [
					'one' => esc_html__( 'One', 'mombo-core' ),
					'two' => esc_html__( 'Two', 'mombo-core' ), 
					'three' => esc_html__( 'Three', 'mombo-core' ), 
					'four' => esc_html__( 'Four', 'mombo-core' ), 
					'five' => esc_html__( 'Five', 'mombo-core' ), 
					'six' => esc_html__( 'Six', 'mombo-core' ), 
					'seven' => esc_html__( 'Seven', 'mombo-core' ), 
				],
			]
		);   

		$this->add_control(
			'img',
			[
				'label'       => esc_html__( 'Image', 'mombo-core' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
                    'table_style' => ['five'],
                ],
			]
		); 

		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'Basic Package',
			]
		);
		$this->add_control(
			'subtitle',
			[
				'label' => esc_html__( 'Subtitle', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'Create your first course',
				'condition' => [
					'table_style' => ['three', 'five', 'seven'], 
                ],
			]
		);

		$this->add_control(
			'price',
			[
				'label' => esc_html__( 'Price', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => '<span>$</span>49',
			]
		);

		$this->add_control(
			'duration_text',
			[
				'label' => esc_html__( 'Duration Text', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'Mo',
			]
		); 

		$this->add_control(
			'list_items',
			[
				'label' => esc_html__( 'List Items', 'mombo-core' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,  
				'fields' => [ 
					[
						'name' => 'title',
						'label' => esc_html__( 'Title', 'mombo-core' ),
						'type' => Controls_Manager::TEXT,
						'default' => 'Basic Package',
					] 
				],
				'title_field' => ' {{ title }}',
			]
		);	  

		$this->add_control(
			'is_popular',
			[
				'label' => esc_html__( 'Is Popular?', 'mombo-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'mombo-core' ),
				'label_off' => esc_html__( 'No', 'mombo-core' ),
				'return_value' => 'yes',
				'default' => '',
				'conditions' => [
					'terms' => [
						[
							'name' => 'table_style',
							'operator' => '!in',
							'value' => [
								'three',
								'five',
							],
						],
					],
				],
			]
		);
		$this->add_control(
			'popular_text',
			[
				'label' => esc_html__( 'Popular Text', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'Popular Choice',
				'condition' => [
					'table_style' => ['one'],
                    'is_popular' => ['yes'],
                ],
			]
		);

		$this->add_control(
			'button_text',
			[
				'label' => esc_html__( 'Button Text', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'Purchase',
			]
		);
		$this->add_control(
			'button_link',
			[ 
				'label' => esc_html__( 'Button Link', 'mombo-core' ),
				'type' => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'mombo-core' ),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
			],
		);  				
		$this->end_controls_section();  

	}

	/**
	 * Render PriceTable widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() { 
		$settings = $this->get_settings_for_display();
		
		ob_start();
			$target = $settings['button_link']['is_external'] ? ' target="_blank"' : '';
			$nofollow = $settings['button_link']['nofollow'] ? ' rel="nofollow"' : ''; 
			$popular_class = ( $settings['is_popular'] == 'yes' ) ? 'theme2nd' : 'theme';
			echo '<a class="m-btn m-btn-'.$popular_class.' m-btn-radius" href="' . $settings['button_link']['url'] . '"' . $target . $nofollow . '>'.esc_html($settings['button_text']).'</a>';
		$buy_button = ob_get_clean();

		if ( $settings['table_style'] == 'one') { ?> 
		<div class="price-table <?php echo ( $settings['is_popular'] == 'yes' ) ? 'active' : ''; ?>">
			<div class="pt-head">
				<?php if ( $settings['popular_text'] ) { ?>
				<label class="msg"><?php echo esc_html( $settings['popular_text'] ); ?></label>
				<?php } ?>
				<h5><?php echo($settings['price']); ?></h5>
			</div>
			<div class="pt-body">
				<h6><?php echo esc_html($settings['title']); ?></h6>
				<ul class="list-type-02">
					<?php foreach ( $settings['list_items'] as $item ) : ?>
					<li><i class="fas fa-check"></i> <?php echo esc_html($item['title']); ?></li> 
					<?php endforeach; ?> 
				</ul>
			</div>
			<div class="pt-footer">
				<?php echo( $buy_button ); ?>
			</div>
		</div>
		<?php } elseif( $settings['table_style'] == 'two' ) { ?>

		<div class="price-table-01 <?php echo ( $settings['is_popular'] == 'yes' ) ? 'active' : ''; ?>">
			<div class="pt-head">
				<h4><?php echo esc_html($settings['title']); ?></h4>
				<h5><?php echo($settings['price']); ?></h5>
			</div>
			<div class="pt-body">
				<ul class="list-type-02">
					<?php foreach ( $settings['list_items'] as $item ) : ?>
						<li><i class="fas fa-check"></i> <?php echo esc_html($item['title']); ?></li> 
					<?php endforeach; ?> 
				</ul>
			</div>
			<div class="pt-footer">
				<?php echo( $buy_button ); ?>
			</div>
		</div> 
		<?php } elseif( $settings['table_style'] == 'three') { ?>

		<div class="price-table-02 hover-top box-shadow-hover border-all-1 border-color-gray <?php echo ( $settings['is_popular'] == 'yes' ) ? 'active' : ''; ?>">
			<div class="pt-head d-flex align-items-center justify-content-between">
				<div class="pth-left">
					<h4 class="dark-color"><?php echo esc_html($settings['title']); ?></h4>
					<label><?php echo esc_html($settings['subtitle']); ?></label>
				</div>
				<div class="pth-right">
					<h5 class="theme2nd-color"><?php echo($settings['price']); ?></h5>
					<label><?php echo esc_html($settings['duration_text']); ?></label>
				</div>
			</div>
			<div class="pt-body">
				<ul class="list-type-01">
					<?php foreach ( $settings['list_items'] as $item ) : ?>
						<li><i class="fas fa-check"></i> <?php echo esc_html($item['title']); ?></li> 
					<?php endforeach; ?> 
				</ul>
			</div>
			<div class="pt-footer">
				<?php echo( $buy_button ); ?>
			</div>
		</div>
		 
		<?php } elseif( $settings['table_style'] == 'four' ) { ?>

		<div class="box-shadow-lg <?php echo ( $settings['is_popular'] == 'yes' ) ? 'theme-bg active' : 'white-bg'; ?>">
			<div class="text-center p-25px-tb border-style bottom">
				<label class="<?php echo ( $settings['is_popular'] == 'yes' ) ? 'white-bg theme-color' : 'theme-bg white-color'; ?> p-15px-lr border-radius-3 font-w-500 m-20px-b"><?php echo esc_html($settings['title']); ?></label>
				<h4 class="h2 m-0px <?php echo ( $settings['is_popular'] == 'yes' ) ? 'white-color' : ''; ?>"><?php echo($settings['price']); ?></h4>
			</div>
			<div class="p-20px">
				<ul class="list-type-02 <?php echo ( $settings['is_popular'] == 'yes' ) ? 'white-color-light' : ''; ?>">
					<?php foreach ( $settings['list_items'] as $item ) : ?>
						<li><i class="fas fa-check"></i> <?php echo esc_html($item['title']); ?></li> 
					<?php endforeach; ?> 
				</ul>
			</div>
			<div class="p-20px p-30px-t border-style top text-center">
				<?php
					$target = $settings['button_link']['is_external'] ? ' target="_blank"' : '';
					$nofollow = $settings['button_link']['nofollow'] ? ' rel="nofollow"' : ''; 
					$popular_class = ( $settings['is_popular'] == 'yes' ) ? 't-white' : 'theme';
					echo '<a class="m-btn m-btn-'.$popular_class.' m-btn-radius" href="' . $settings['button_link']['url'] . '"' . $target . $nofollow . '>'.esc_html($settings['button_text']).'</a>';
				?> 
			</div>
		</div>
						
		<?php } elseif( $settings['table_style'] == 'five' ) { ?>
		
		<div class="price-table-03 transition box-shadow-hover hover-top">
			<div class="pt-head">
				<h3><?php echo esc_html($settings['title']); ?></h3>
				<p><?php echo esc_html($settings['subtitle']); ?></p>
				<div class="pt-icon">
					<?php echo wp_get_attachment_image( $settings['img']['id'], 'full' ); ?> 
				</div>
				<div class="price">
				<?php echo($settings['price']); ?><span><?php echo esc_html($settings['duration_text']); ?></span>
				</div>
			</div>
			<div class="pt-body">
				<ul>
					<?php foreach ( $settings['list_items'] as $item ) : ?>
						<li><?php echo esc_html($item['title']); ?></li> 
					<?php endforeach; ?> 
				</ul>
			</div>
			<div class="pt-action">
				<?php
					$target = $settings['button_link']['is_external'] ? ' target="_blank"' : '';
					$nofollow = $settings['button_link']['nofollow'] ? ' rel="nofollow"' : ''; 
					$popular_class = ( $settings['is_popular'] == 'yes' ) ? 't-white' : 'theme';
					echo '<a class="m-btn m-btn-theme m-btn-radius" href="' . $settings['button_link']['url'] . '"' . $target . $nofollow . '>'.esc_html($settings['button_text']).'</a>';
				?>  
			</div>
		</div>
						
		<?php } elseif( $settings['table_style'] == 'six' ) { ?>

		<div class="border-radius-10 box-shadow-hover hover-top <?php echo ( $settings['is_popular'] == 'yes' ) ? 'theme-bg active' : 'white-bg'; ?> text-center p-20px-tb">
			<div class="border-style bottom p-30px">
				<div class="h1 <?php echo ( $settings['is_popular'] == 'yes' ) ? 'white-color' : 'dark-color'; ?> font-w-600"><?php echo($settings['price']); ?></div>
				<div class="h6 font-w-600 <?php echo ( $settings['is_popular'] == 'yes' ) ? 'white-color-alt' : ''; ?>"><?php echo esc_html($settings['title']); ?></div>
			</div> 
			<div class="p-30px">
				<ul class="list-unstyled list-type-06 <?php echo ( $settings['is_popular'] == 'yes' ) ? 'white-color-light' : ''; ?>">
					<?php foreach ( $settings['list_items'] as $item ) : ?>
						<li><?php echo esc_html($item['title']); ?></li> 
					<?php endforeach; ?> 
				</ul>
				<div class="p-25px-t">  
					<?php
						$target = $settings['button_link']['is_external'] ? ' target="_blank"' : '';
						$nofollow = $settings['button_link']['nofollow'] ? ' rel="nofollow"' : ''; 
						$popular_class = ( $settings['is_popular'] == 'yes' ) ? 'white' : 'theme-light';
						echo '<a class="m-btn m-btn-round m-btn-'.$popular_class.'" href="' . $settings['button_link']['url'] . '"' . $target . $nofollow . '>'.esc_html($settings['button_text']).'</a>';
					?> 
				</div>
			</div>
		</div>

		<?php } elseif( $settings['table_style'] == 'seven' ) { ?> 

		<div class="box-shadow-hover <?php echo ( $settings['is_popular'] == 'yes' ) ? 'theme-bg active' : 'white-bg'; ?> border-radius-10 hover-top">
			<div class="p-25px-lr p-50px-t">
				<ul class="list-type-01 <?php echo ( $settings['is_popular'] == 'yes' ) ? 'white white-color' : 'theme'; ?>">
					<?php foreach ( $settings['list_items'] as $item ) : ?>
						<li><i class="fas fa-check"></i> <?php echo esc_html($item['title']); ?></li> 
					<?php endforeach; ?> 
				</ul>
				<div class="text-center p-25px-t">
					<h6 class="p-25px-lr p-5px-tb border-radius-5 <?php echo ( $settings['is_popular'] == 'yes' ) ? 'white-bg theme-color' : 'theme-bg white-color'; ?> d-inline-block font-w-400"><?php echo esc_html($settings['title']); ?></h6>
				</div>
			</div>
			<div class="text-center p-25px">
				<h5 class="display-2 font-w-200 dark-color d-flex align-items-center justify-content-center m-0px <?php echo ( $settings['is_popular'] == 'yes' ) ? 'white-color' : ''; ?>"><sup class="h2 m-0px-b font-w-300">$</sup>49<span class="h3 font-w-200 <?php echo ( $settings['is_popular'] == 'yes' ) ? '' : 'theme-color'; ?> mt-auto"><?php echo esc_html($settings['duration_text']); ?></span></h5>
				<p class="m-0px p-10px-t font-w-300 font-2 <?php echo ( $settings['is_popular'] == 'yes' ) ? 'white-color-light' : ''; ?>"><?php echo esc_html($settings['subtitle']); ?></p>
			</div>
			<div class="p-30px-lr p-50px-b"> 
				<?php
					$target = $settings['button_link']['is_external'] ? ' target="_blank"' : '';
					$nofollow = $settings['button_link']['nofollow'] ? ' rel="nofollow"' : ''; 
					$popular_class = ( $settings['is_popular'] == 'yes' ) ? 'white' : 'theme';
					echo '<a class="m-btn w-100 m-btn-t-'.$popular_class.' m-btn-radius" href="' . $settings['button_link']['url'] . '"' . $target . $nofollow . '>'.esc_html($settings['button_text']).'</a>';
				?> 
			</div>
		</div> 
		<?php }
	} 
}

Plugin::instance()->widgets_manager->register_widget_type( new Mombo_Price_Table_Widget() );
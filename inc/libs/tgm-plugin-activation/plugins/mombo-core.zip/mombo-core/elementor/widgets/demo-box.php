<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Mombo Demo_Box Widget.
 *
 * Mombo widget that inserts an embeddable content into the page, from any given URL.
 *
 * @since 1.0
 */

class Mombo_Demo_Box_Widget extends Widget_Base {

	public function get_name() {
		return 'mombo-demo-box';
	}

	public function get_title() {
		return esc_html__( 'Mombo: Demo Box', 'mombo-core' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return [ 'mombo-category' ];
	}

	/**
	 * Register Demo_Box widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'mombo-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		); 

		$this->add_control(
			'img',
			[
				'label'       => esc_html__( 'Image', 'mombo-core' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => '',
			]
		);
		$this->add_control(
			'link',
			[ 
				'label' => esc_html__( 'Link', 'mombo-core' ),
				'type' => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'mombo-core' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			],
		);

		$this->add_control(
			'is_new',
			[
				'label' => esc_html__( 'Is New?', 'mombo-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'mombo-core' ),
				'label_off' => esc_html__( 'No', 'mombo-core' ),
				'return_value' => 'yes',
				'default' => '', 
			]
		);
		$this->add_control(
			'new_text',
			[
				'label' => esc_html__( 'New Text', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'New',
				'condition' => [ 
                    'is_new' => ['yes'],
                ],
			]
		);

		$this->end_controls_section(); 

	}

	/**
	 * Render Demo_Box widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() { 
		$settings = $this->get_settings_for_display(); ?>   
		<div class="box-shadow-hover p-10px white-bg border-radius-10 hover-top <?php if ( $settings['new_text'] ) echo 'position-relative'; ?>">
			<?php
				$target = $settings['link']['is_external'] ? ' target="_blank"' : '';
				$nofollow = $settings['link']['nofollow'] ? ' rel="nofollow"' : '';  
				echo '<a href="' . $settings['link']['url'] . '"' . $target . $nofollow . '>'; 
				?>
				<?php if ( $settings['new_text'] ) { ?> 
					<div class="icon-70 pink-bg border-radius-50 box-shadow position-absolute mt-n4 ml-n4">
						<i class="font-normal font-2 white-color"><?php echo esc_html( $settings['new_text'] ); ?></i>
					</div>
				<?php } 
					if ( $settings['img']['id'] ) {
						echo wp_get_attachment_image( $settings['img']['id'], 'large' );
					}
				?> 
			</a>

			<?php if ( $settings['title'] ) { ?>
				<label class="dark-color w-100 p-15px-t h5 text-center font-w-600"><?php echo esc_html( $settings['title'] ); ?></label>
			<?php } ?>
		</div>  	
		
		 
	<?php } 
}

Plugin::instance()->widgets_manager->register_widget_type( new Mombo_Demo_Box_Widget() );
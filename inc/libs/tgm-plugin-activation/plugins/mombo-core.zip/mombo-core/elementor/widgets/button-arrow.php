<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Mombo Button_Arrow Widget.
 *
 * Mombo widget that inserts an embeddable content into the page, from any given URL.
 *
 * @since 1.0
 */

class Mombo_Button_Arrow_Widget extends Widget_Base {

	public function get_name() {
		return 'mombo-button-arrow';
	}

	public function get_title() {
		return esc_html__( 'Mombo: Button Arrow', 'mombo-core' );
	}

	public function get_icon() {
		return 'eicon-button';
	}

	public function get_categories() {
		return [ 'mombo-category' ];
	}

	/**
	 * Register Button_Arrow widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'mombo-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);  
		
		$this->add_control(
			'btn_text',
			[
				'label' => esc_html__( 'Button Text', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'Unique Design',
			]
		);
		$this->add_control(
			'btn_link',
			[ 
				'label' => esc_html__( 'Link', 'mombo-core' ),
				'type' => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'mombo-core' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			],
		); 

		$this->end_controls_section(); 

	}

	/**
	 * Render Button_Arrow widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() { 
		$settings = $this->get_settings_for_display(); ?>   
		<div class="p-20px p-50px-r border-all-1 border-color-white arrow-hover">
			<?php
				$target = $settings['btn_link']['is_external'] ? ' target="_blank"' : '';
				$nofollow = $settings['btn_link']['nofollow'] ? ' rel="nofollow"' : '';  
				echo '<a class="overlay-link" href="' . $settings['btn_link']['url'] . '"' . $target . $nofollow . '></a>'; 
			?> 
			<div class="arrow-icon white-color"></div>
			<h5 class="font-1 font-w-600 white-color m-0px"><?php echo esc_html( $settings['btn_text'] ); ?></h5>
		</div> 	 
	<?php } 
}

Plugin::instance()->widgets_manager->register_widget_type( new Mombo_Button_Arrow_Widget() );
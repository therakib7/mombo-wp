<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Mombo Support_Topic Widget.
 *
 * Mombo widget that inserts an embeddable content into the page, from any given URL.
 *
 * @since 1.0
 */

class Mombo_Support_Topic_Widget extends Widget_Base {

	public function get_name() {
		return 'mombo-support-topic';
	}

	public function get_title() {
		return esc_html__( 'Mombo: Support Topic', 'mombo-core' );
	}

	public function get_icon() {
		return 'eicon-help-o';
	}

	public function get_categories() {
		return [ 'mombo-category' ];
	}

	/**
	 * Register Support_Topic widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'mombo-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		); 
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'Buying and Item Support',
			]
		); 
		$this->add_control(
			'desc',
			[
				'label'       => esc_html__( 'Description', 'mombo-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [ 'active' => true ], 
				'default'     => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa.',
			]
		);

		$this->add_control(
			'icon',
			[ 
				'label' => esc_html__( 'Icon', 'mombo-core' ),
				'type' => Controls_Manager::ICONS, 
				'default' => [
					'value' => 'fas fa-question',
					'library' => 'brand',
				],
			], 
			
		); 
		$this->add_control(
			'bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'mombo-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> 'rgba(17, 226, 121, 0.1)',
				'selectors' => [
					'{{WRAPPER}} .green-bg-alt' => 'background-color: {{VALUE}};',
				],
			]
		); 
		$this->add_control(
			'icon_color',
			[
				'label'     => esc_html__( 'Icon Color', 'mombo-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '#11e279',
				'selectors' => [
					'{{WRAPPER}} .green-bg-alt i' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'topic_link',
			[ 
				'label' => esc_html__( 'Topic Link', 'mombo-core' ),
				'type' => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'mombo-core' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			],
		);  
		$this->end_controls_section(); 
 
	}

	/**
	 * Render Support_Topic widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() { 
		$settings = $this->get_settings_for_display(); ?>  
		<div class="border-all-1 border-radius-5 border-color-dark-gray text-center p-25px-lr p-40px-tb hover-top box-shadow-only-hover">
			<?php
			$target = $settings['topic_link']['is_external'] ? ' target="_blank"' : '';
			$nofollow = $settings['topic_link']['nofollow'] ? ' rel="nofollow"' : '';  
			echo '<a class="overlay-link" href="' . $settings['topic_link']['url'] . '"' . $target . $nofollow . '></a>'; 
			?> 
			<div class="icon-70 green-color green-bg-alt border-radius-50 d-inline-block m-15px-b">
				<?php Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] ); ?>
			</div>
			<h5 class="h6 m-10px-b m-15px-t"><?php echo esc_html($settings['title']); ?></h5>
			<p class="m-0px"><?php echo wp_kses_post( $settings['desc'] ); ?></p>
		</div>
	<?php } 
}

Plugin::instance()->widgets_manager->register_widget_type( new Mombo_Support_Topic_Widget() );
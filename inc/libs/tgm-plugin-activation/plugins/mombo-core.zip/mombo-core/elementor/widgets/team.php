<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Mombo Team Widget.
 *
 * Mombo widget that inserts an embeddable content into the page, from any given URL.
 *
 * @since 1.0
 */

class Mombo_Team_Widget extends Widget_Base {

	public function get_name() {
		return 'mombo-team';
	}

	public function get_title() {
		return esc_html__( 'Mombo: Team', 'mombo-core' );
	}

	public function get_icon() {
		return 'fa fa-user-o';
	}

	public function get_categories() {
		return [ 'mombo-category' ];
	}

	/**
	 * Register Team widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'mombo-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		); 

		$this->add_control(
			'team_style',
			[
				'label' => esc_html__( 'Team Style', 'mombo-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'square',
				'options' => [
					'square' => esc_html__( 'Square', 'mombo-core' ),
					'circle' => esc_html__( 'Circle', 'mombo-core' ),  
				],
			]
		); 

		$this->add_control(
			'border_style',
			[
				'label' => esc_html__( 'Border Style', 'mombo-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'normal',
				'options' => [
					'normal' => esc_html__( 'Normal', 'mombo-core' ),
					'padding' => esc_html__( 'Padding', 'mombo-core' ),  
				],
			]
		); 

		$this->add_control(
			'img',
			[
				'label'       => esc_html__( 'Image', 'mombo-core' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'name',
			[
				'label' => esc_html__( 'Name', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'Nancy Bayers',
			]
		);

		$this->add_control(
			'position',
			[
				'label' => esc_html__( 'Position', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'Co-Founder',
			]
		);

		$this->add_control(
			'social_url',
			[
				'label' => esc_html__( 'Social URL', 'mombo-core' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,  
				'default' => [
					[
						'icon' => [ 'value' => 'fab fa-facebook-f' ], 
						'website_link' => [ 'url' => 'https://facebook.com' ]
					],  
					[
						'icon' => [ 'value' => 'fab fa-twitter' ], 
						'website_link' => [ 'url' => 'https://twitter.com' ]
					], 
					[
						'icon' => [ 'value' => 'fab fa-linkedin-in' ],  
						'website_link' => [ 'url' => 'https://www.linkedin.com' ]
					], 
					[
						'icon' => [ 'value' => 'fab fa-instagram' ],  
						'website_link' => [ 'url' => 'https://instagram.com' ]
				    ], 
				],
				'fields' => [ 
					[
						'name' => 'icon',
						'label' => esc_html__( 'Icon', 'mombo-core' ),
						'type' => Controls_Manager::ICONS, 
						'default' => [
							'value' => 'fas fa-star',
							'library' => 'brand',
						],
					], 
					[
						'name' => 'website_link',
						'label' => esc_html__( 'Link', 'mombo-core' ),
						'type' => Controls_Manager::URL,
						'placeholder' => esc_html__( 'https://your-link.com', 'mombo-core' ),
						'show_external' => true,
						'default' => [
							'url' => '',
							'is_external' => true,
							'nofollow' => true,
						],
					],
				],
				'title_field' => ' {{ icon.value }}',
			]
		);	  

		$this->add_control(
			'icon_style',
			[
				'label' => esc_html__( 'Social Icon Style', 'mombo-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'circle',
				'options' => [
					'square' => esc_html__( 'Square', 'mombo-core' ),
					'circle' => esc_html__( 'Circle', 'mombo-core' ),  
				],
			]
		); 
		
		$this->end_controls_section(); 

		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Background', 'mombo-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'social_icon_bg',
			[
				'label'     => esc_html__( 'Social Icon Background Color', 'mombo-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '#03c',
				'selectors' => [
					'{{WRAPPER}} .theme a' => 'background-color: {{VALUE}};',
				],
			]
		); 

		$this->add_control(
			'social_icon_hover',
			[
				'label'     => esc_html__( 'Social Icon Background Color Hover', 'mombo-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '#15db95',
				'selectors' => [
					'{{WRAPPER}} .theme a:hover' => 'background-color: {{VALUE}};',
				],
			]
		);  
		
		$this->end_controls_section(); 

	}

	/**
	 * Render Team widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() { 
		$settings = $this->get_settings_for_display(); 

		ob_start();
			foreach ( $settings['social_url'] as $item ) : 
				$target = $item['website_link']['is_external'] ? ' target="_blank"' : '';
				$nofollow = $item['website_link']['nofollow'] ? ' rel="nofollow"' : ''; 
				echo '<a href="' . $item['website_link']['url'] . '"' . $target . $nofollow . '>';
				Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] );
				echo '</a>';
			?> 
		<?php endforeach; 
		$social_url = ob_get_clean();

		if ( $settings['team_style'] == 'square' && $settings['border_style'] == 'normal' ) {
		?> 
		<div class="hover-top-in">
			<div class="overflow-hidden border-radius-5"> 
				<?php if( $settings['img']['id'] ) {
					echo wp_get_attachment_image( $settings['img']['id'], 'full' );
				} ?>  
			</div>
			<div class="m-10px-lr box-shadow border-radius-5 position-relative mt-n4 white-bg p-20px text-center hover-top--in">
				<h6 class="font-w-700 dark-color m-5px-b"><?php echo esc_html($settings['name']); ?></h6>
				<small><?php echo esc_html($settings['position']); ?></small>
				<div class="social-icon si-30 theme <?php echo ($settings['icon_style'] == 'circle') ? 'radius' : 'round'; ?> nav justify-content-center p-10px-t"> 
					<?php echo($social_url); ?>
				</div>
			</div>
		</div>  	
		<?php } elseif( $settings['team_style'] == 'square' && $settings['border_style'] == 'padding' ) { ?>
		<div class="box-shadow-hover hover-top white-bg our-team-hover-icon border-radius-3">
			<div class="p-10px team-img">
				<?php if( $settings['img']['id'] ) {
					echo wp_get_attachment_image( $settings['img']['id'], 'full' );
				} ?>  

				<div class="social-icon si-30 theme <?php echo ($settings['icon_style'] == 'circle') ? 'radius' : 'round'; ?> nav justify-content-center p-20px-t">
					<?php echo($social_url); ?>
				</div>
			</div>
			<div class="p-5px-t p-20px-b text-center">
				<small><?php echo esc_html($settings['position']); ?></small>
				<h6 class="m-5px-b"><?php echo esc_html($settings['name']); ?></h6>
			</div>
		</div>
		<?php } elseif( $settings['team_style'] == 'circle' && $settings['border_style'] == 'normal' ) { ?>
		<div class="hover-top-in text-center">
			<div class="avatar-220 border-radius-50 d-inline-block">
				<?php if( $settings['img']['id'] ) { ?>
				<img src="<?php echo mombo_get_image_size_by_img_id($settings['img']['id'], 265, 318, true); ?>" alt="<?php echo esc_attr($settings['name']); ?>">
				<?php } ?>
			</div>
			<div class="m-10px-lr box-shadow border-radius-5 position-relative mt-n4 white-bg p-20px text-center hover-top--in">
				<h6 class="m-5px-b"><?php echo esc_html($settings['name']); ?></h6>
				<small><?php echo esc_html($settings['position']); ?></small>
				<div class="social-icon si-30 theme <?php echo ($settings['icon_style'] == 'circle') ? 'radius' : 'round'; ?> nav justify-content-center p-10px-t">
					<?php echo($social_url); ?>
				</div>
			</div>
		</div>
		<?php } elseif( $settings['team_style'] == 'circle' && $settings['border_style'] == 'padding' ) { ?>
		<div class="hover-top-in text-center">
			<div class="avatar-220 border-radius-50 d-inline-block border-all-10 border-color-white position-relative z-index-1 box-shadow">
				<?php if( $settings['img']['id'] ) { ?>
				<img src="<?php echo mombo_get_image_size_by_img_id($settings['img']['id'], 265, 318, true); ?>" alt="<?php echo esc_attr($settings['name']); ?>">
				<?php } ?>
			</div>
			<div class="m-10px-lr box-shadow border-radius-15 mt-n5 white-bg p-65px-t p-25px-b p-15px-lr text-center hover-top--in">
				<h6 class="m-5px-b"><?php echo esc_html($settings['name']); ?></h6>
				<small><?php echo esc_html($settings['position']); ?></small>
				<div class="social-icon si-30 theme <?php echo ($settings['icon_style'] == 'circle') ? 'radius' : 'round'; ?> nav justify-content-center p-10px-t">
					<?php echo($social_url); ?>
				</div>
			</div>
		</div> 		
		<?php }
	} 
}

Plugin::instance()->widgets_manager->register_widget_type( new Mombo_Team_Widget() );
<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Mombo Service Widget.
 *
 * Mombo widget that inserts an embeddable content into the page, from any given URL.
 *
 * @since 1.0
 */

class Mombo_Service_Widget extends Widget_Base {

	public function get_name() {
		return 'mombo-service';
	}

	public function get_title() {
		return esc_html__( 'Mombo: Service', 'mombo-core' );
	}

	public function get_icon() {
		return 'eicon-icon-box';
	}

	public function get_categories() {
		return [ 'mombo-category' ];
	}

	/**
	 * Register Service widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'mombo-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		); 

		$this->add_control(
			'style',
			[
				'label' => esc_html__( 'Service Style', 'mombo-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'one',
				'options' => [
					'one' => esc_html__( 'One', 'mombo-core' ),
					'two' => esc_html__( 'Two', 'mombo-core' ), 
					'three' => esc_html__( 'Three', 'mombo-core' ), 
					'four' => esc_html__( 'Four', 'mombo-core' ), 
					'five' => esc_html__( 'Five', 'mombo-core' ), 
					'six' => esc_html__( 'Six', 'mombo-core' ), 
					'seven' => esc_html__( 'Seven', 'mombo-core' ), 
					'eight' => esc_html__( 'Eight', 'mombo-core' ), 
					'nine' => esc_html__( 'Nine', 'mombo-core' ), 
					'ten' => esc_html__( 'Ten (Carousel)', 'mombo-core' ), 
					'eleven' => esc_html__( 'Eleven (Carousel)', 'mombo-core' ), 
				],
			]
		); 

		$this->add_control(
			'icon_from',
			[
				'label' => esc_html__( 'Icon from', 'mombo-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'library',
				'options' => [
					'library' => esc_html__( 'Library', 'mombo-core' ),
					'class' => esc_html__( 'Class', 'mombo-core' ),  
				],
				'conditions' => [
					'terms' => [
						[
							'name' => 'style',
							'operator' => '!in',
							'value' => ['ten', 'eleven'],
						],
					],
				],
			]
		); 

		$this->add_control(
			'icon',
			[ 
				'label' => esc_html__( 'Icon', 'mombo-core' ),
				'type' => Controls_Manager::ICONS, 
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'brand',
				],
				'conditions' => [ 
					'terms' => [
						[
							'name' => 'style',
							'operator' => '!in',
							'value' => ['ten', 'eleven'],
						],
						[
							'name' => 'icon_from',
							'operator' => 'in',
							'value' => ['library'],
						],
					],
                ],
			], 
		); 
		$this->add_control(
			'icon_class',
			[
				'label' => esc_html__( 'Icon Class', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'icon-desktop',
				'conditions' => [ 
					'terms' => [
						[
							'name' => 'style',
							'operator' => '!in',
							'value' => ['ten', 'eleven'],
						],
						[
							'name' => 'icon_from',
							'operator' => 'in',
							'value' => ['class'],
						],
					],
				], 
			]
		); 

		$this->add_control(
			'bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'mombo-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '#f12699',
				'selectors' => [
					'{{WRAPPER}} .service-three' => 'background-color: {{VALUE}}; color: {{VALUE}};',
				],
				'conditions' => [ 
					'terms' => [
						[
							'name' => 'style',
							'operator' => 'in',
							'value' => ['three'],
						], 
					],
				], 
			]
		); 

		$this->add_control(
			'bg_color_seven',
			[
				'label'     => esc_html__( 'Background and Border Color', 'mombo-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '#15db95',
				'selectors' => [
					'{{WRAPPER}} .service-seven' => 'border-color: {{VALUE}};',
					'{{WRAPPER}} .service-seven .icon-100' => 'background-color: {{VALUE}};',
				],
				'conditions' => [ 
					'terms' => [
						[
							'name' => 'style',
							'operator' => 'in',
							'value' => ['seven'],
						], 
					],
				], 
			]
		); 

		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'We can help!',
				'conditions' => [
					'terms' => [
						[
							'name' => 'style',
							'operator' => '!in',
							'value' => ['ten', 'eleven'],
						],
					],
				],
			]
		); 
		$this->add_control(
			'desc',
			[
				'label'       => esc_html__( 'Description', 'mombo-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [ 'active' => true ], 
				'default'     => 'Momboo is a WordPress Theme based on Sass and Bootstrap 4 with modern and creative multipurpose design you can use it as a startups.',
				'conditions' => [
					'terms' => [
						[
							'name' => 'style',
							'operator' => '!in',
							'value' => ['ten', 'eleven'],
						],
					],
				],
			]
		); 
		$this->add_control(
			'btn_text',
			[
				'label' => esc_html__( 'Button Text', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => '',
				'conditions' => [
					'terms' => [
						[
							'name' => 'style',
							'operator' => '!in',
							'value' => ['ten', 'eleven'],
						],
					],
				],
			]
		); 
		$this->add_control(
			'btn_link',
			[ 
				'label' => esc_html__( 'Button Link', 'mombo-core' ),
				'type' => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'mombo-core' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
				'conditions' => [
					'terms' => [
						[
							'name' => 'style',
							'operator' => '!in',
							'value' => ['ten', 'eleven'],
						],
					],
				],
			],
		);  
		$this->add_control(
			'is_highlight',
			[
				'label' => esc_html__( 'Is Highlight?', 'mombo-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'mombo-core' ),
				'label_off' => esc_html__( 'No', 'mombo-core' ),
				'return_value' => 'yes',
				'default' => '', 
				'conditions' => [
					'terms' => [
						[
							'name' => 'style',
							'operator' => '!in',
							'value' => ['ten', 'eleven'],
						],
					],
				],
			]
		);

		$this->add_control(
			'services',
			[
				'label' => esc_html__( 'Carousel Items', 'mombo-core' ),
				'type' => Controls_Manager::REPEATER, 
				'conditions' => [
					'terms' => [
						[
							'name' => 'style',
							'operator' => 'in',
							'value' => ['ten', 'eleven'],
						],
					],
				],
				'fields' => [ 
					[
						'name' => 'img',
						'label'       => esc_html__( 'Image', 'mombo-core' ),
						'description'       => esc_html__( 'Image will only show in style two and three', 'mombo-core' ),
						'type' => Controls_Manager::MEDIA,
						'dynamic' => [
							'active' => true,
						],
						'default' => [
							'url' => Utils::get_placeholder_image_src(),
						], 
					],
					[
						'name' => 'title',
						'label' => esc_html__( 'Title', 'mombo-core' ),
						'type' => Controls_Manager::TEXT,
						'label_block' => true, 
						'default' => 'Web Development',
					],  
					[
						'name' 		  => 'desc',
						'label'       => esc_html__( 'Description', 'mombo-core' ),
						'type'        => Controls_Manager::TEXTAREA,
						'dynamic'     => [ 'active' => true ], 
						'default'     => 'Momboo is a WordPress Theme based on Sass and Bootstrap 4 with modern and creative multipurpose design you can use it as a startups.', 
					],
					[
						'name' 		  => 'btn_text',
						'label' => esc_html__( 'Button Text', 'mombo-core' ),
						'type' => Controls_Manager::TEXT,
						'default' => 'More Info', 
					],
					[ 
						'name' 		  => 'btn_link',
						'label' => esc_html__( 'Button Link', 'mombo-core' ),
						'type' => Controls_Manager::URL,
						'placeholder' => esc_html__( 'https://your-link.com', 'mombo-core' ),
						'show_external' => true,
						'default' => [
							'url' => '',
							'is_external' => true,
							'nofollow' => true,
						], 
					],
				],
				'title_field' => ' {{ title }}',
			]
		);
		$this->end_controls_section();  
	}

	/**
	 * Render Service widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() { 
		$settings = $this->get_settings_for_display(); 
		
		$icon_class = '';
		if ( $settings['icon_from'] == 'library' ) {
			$icon_class = $settings['icon']['value'];
		} else {
			$icon_class = $settings['icon_class'];
		} 

		ob_start();
			$target = $settings['btn_link']['is_external'] ? ' target="_blank"' : '';
			$nofollow = $settings['btn_link']['nofollow'] ? ' rel="nofollow"' : ''; 
			$highlight_class = ( $settings['is_highlight'] == 'yes' ) ? 'theme2nd' : 'theme';
			if ( $settings['btn_text'] ) {
				echo '<div class="p-15px-t"><a class="m-btn m-btn-sm m-btn-'.$highlight_class.' m-btn-radius" href="' . $settings['btn_link']['url'] . '"' . $target . $nofollow . '>'.esc_html($settings['btn_text']).'</a></div>'; 
			} 	
		$service_button = ob_get_clean();
		?> 
		<?php if( $settings['style'] == 'one') { ?>
			<div class="p-50px-tb p-35px-lr box-shadow-hover hover-top hover-rotate text-center border-radius-5 <?php echo ( $settings['is_highlight'] == 'yes' ) ? 'theme-bg' : 'white-bg'; ?>">
				<div class="ef-1 icon-80 border-radius-50 theme2nd-color d-inline-block m-20px-b hr-rotate-after <?php echo ( $settings['is_highlight'] == 'yes' ) ? 'white-bg' : 'theme-bg'; ?>">  
					<i class="<?php echo esc_attr( $icon_class ); ?> <?php echo ( $settings['is_highlight'] == 'yes' ) ? 'theme-color' : 'white-color'; ?>"></i>
				</div>
				<h5 class="h6 m-10px-b <?php echo ( $settings['is_highlight'] == 'yes' ) ? 'white-color' : ''; ?>"><?php echo esc_html($settings['title']); ?></h5>
				<p class="m-0px <?php echo ( $settings['is_highlight'] == 'yes' ) ? 'white-color-light' : ''; ?>"><?php echo wp_kses_post( $settings['desc'] ); ?></p>
				<?php echo($service_button); ?>
			</div>
		<?php } elseif( $settings['style'] == 'two') { ?>
			<div class="p-50px-tb p-25px-lr box-shadow-hover hover-top hover-rotate white-bg text-center border-radius-5">
				<div class="ef-2 icon-80 theme-bg border-radius-50 theme2nd-color d-inline-block m-20px-b hr-rotate-after">
					<i class="<?php echo esc_attr( $icon_class ); ?> white-color"></i>
				</div>
				<h5 class="h6 m-10px-b"><?php echo esc_html($settings['title']); ?></h5>
				<p class="m-0px"><?php echo wp_kses_post( $settings['desc'] ); ?></p>
				<?php echo($service_button); ?>
			</div>
		<?php } elseif( $settings['style'] == 'three') { ?>
			<div class="p-50px-tb p-25px-lr box-shadow-hover hover-top hover-rotate white-bg text-center border-radius-5">
				<div class="ef-2 icon-80 service-three border-radius-50 d-inline-block m-20px-b hr-rotate-after">
					<i class="<?php echo esc_attr( $icon_class ); ?> white-color"></i>
				</div>
				<h5 class="h6 m-10px-b"><?php echo esc_html($settings['title']); ?></h5>
				<p class="m-0px"><?php echo wp_kses_post( $settings['desc'] ); ?></p>
				<?php echo($service_button); ?>
			</div>
		<?php } elseif( $settings['style'] == 'four') { ?>
			<div class="p-50px-tb p-25px-lr box-shadow-hover hover-top hover-rotate text-center border-radius-5 <?php echo ( $settings['is_highlight'] == 'yes' ) ? 'theme-bg' : 'white-bg'; ?>">
				<div class="ef-3 icon-80 border-radius-50 d-inline-block m-20px-b hr-rotate-after <?php echo ( $settings['is_highlight'] == 'yes' ) ? 'white-bg white-color' : 'theme-bg theme-color'; ?>">
					<i class="<?php echo esc_attr( $icon_class ); ?> <?php echo ( $settings['is_highlight'] == 'yes' ) ? 'theme-color' : 'white-color'; ?>"></i>
				</div>
				<h5 class="h6 m-10px-b <?php echo ( $settings['is_highlight'] == 'yes' ) ? 'white-color' : ''; ?>"><?php echo esc_html($settings['title']); ?></h5>
				<p class="m-0px <?php echo ( $settings['is_highlight'] == 'yes' ) ? 'white-color-light' : ''; ?>"><?php echo wp_kses_post( $settings['desc'] ); ?></p>
				<?php echo($service_button); ?>
			</div> 
		<?php } elseif( $settings['style'] == 'five') { ?>
			<div class="p-50px-tb p-25px-lr <?php echo ( $settings['is_highlight'] == 'yes' ) ? 'box-shadow-lg' : 'box-shadow-only-hover'; ?> hover-top hover-rotate white-bg text-center border-radius-5">
				<div class="icon-100 border-radius-50 green-color d-inline-block m-20px-b border-all-1 border-color-dark-gray">
					<i class="<?php echo esc_attr( $icon_class ); ?>"></i>
				</div>
				<h5 class="h6 m-10px-b"><?php echo esc_html($settings['title']); ?></h5>
				<p class="m-0px"><?php echo wp_kses_post( $settings['desc'] ); ?></p>
				<?php echo($service_button); ?>
			</div> 
		<?php } elseif( $settings['style'] == 'six') { ?>
			<div class="box-shadow-hover hover-top hover-rotate white-bg text-center border-radius-5">
				<div class="icon-100 border-radius-50 theme-bg white-color d-inline-block m-20px-b m-40px-t">
					<i class="<?php echo esc_attr( $icon_class ); ?>"></i>
				</div>
				<div class="p-25px-lr">
					<h5 class="h6 m-10px-b"><?php echo esc_html($settings['title']); ?></h5>
					<p class="m-0px"><?php echo wp_kses_post( $settings['desc'] ); ?></p>
				</div>
				<?php
					$target = $settings['btn_link']['is_external'] ? ' target="_blank"' : '';
					$nofollow = $settings['btn_link']['nofollow'] ? ' rel="nofollow"' : '';  
					if ( $settings['btn_text'] ) {
						echo '<div class="border-top-1 border-color-dark-gray p-10px m-20px-t"><a class="font-w-600" href="' . $settings['btn_link']['url'] . '"' . $target . $nofollow . '>'.esc_html($settings['btn_text']).'</a></div>'; 
					} else {
						echo '<div class="m-20px-t">&nbsp;</div>';
					}
				?>
			</div>
		<?php } elseif( $settings['style'] == 'seven') { ?>
			<div class="service-seven box-shadow hover-top hover-rotate text-center border-radius-5 p-40px-tb p-25px-lr <?php echo ( $settings['is_highlight'] == 'yes' ) ? 'theme-bg' : 'white-bg border-bottom-5 border-color-theme2nd'; ?>">
				<div class="icon-100 border-radius-effect d-inline-block m-20px-b <?php echo ( $settings['is_highlight'] == 'yes' ) ? 'white-bg theme-color' : 'theme2nd-bg white-color'; ?>">
					<i class="<?php echo esc_attr( $icon_class ); ?>"></i>
				</div>
				<h5 class="<?php echo ( !$settings['desc'] ) ? 'font-2 m-0px': 'h6 m-10px-b'; ?> <?php echo ( $settings['is_highlight'] == 'yes' ) ? 'white-color' : ''; ?>"><?php echo esc_html($settings['title']); ?></h5>
				<?php if ( $settings['desc'] ) { ?>
					<p class="m-0px <?php echo ( $settings['is_highlight'] == 'yes' ) ? 'white-color-light' : ''; ?>"><?php echo wp_kses_post( $settings['desc'] ); ?></p>
				<?php } ?>
				<?php echo($service_button); ?>
			</div> 
		<?php } elseif( $settings['style'] == 'eight') { ?>
			<div class="box-shadow white-bg hover-top border-radius-10 text-center">
				<div class="icon-90 white-bg theme-color border-radius-10 shadow d-inline-block mt-n3">
					<i class="<?php echo esc_attr( $icon_class ); ?>"></i>
				</div>
				<div class="p-25px">
					<h5><?php echo esc_html($settings['title']); ?></h5>
					<p class="m-0px"><?php echo wp_kses_post( $settings['desc'] ); ?></p>
					<?php 
						$target = $settings['btn_link']['is_external'] ? ' target="_blank"' : '';
						$nofollow = $settings['btn_link']['nofollow'] ? ' rel="nofollow"' : '';  
						if ( $settings['btn_text'] ) {
							echo '<div class="p-15px-t"><a class="m-btn m-btn-theme-light m-btn-radius m-btn-sm" href="' . $settings['btn_link']['url'] . '"' . $target . $nofollow . '>'.esc_html($settings['btn_text']).'</a></div>'; 
						} 	
					?>
				</div>
			</div>
		<?php } elseif( $settings['style'] == 'nine') { ?>
		<div class="box-shadow hover-top white-bg border-radius-5 theme-hover-bg p-20px-lr p-40px-tb text-center">
			<div class="icon-80 gray-bg dots-icon border-radius-50 theme-color d-inline-block m-20px-b"> 
				<i class="<?php echo esc_attr( $icon_class ); ?>"></i>
				<span class="dots"><i class="dot dot1"></i><i class="dot dot2"></i><i class="dot dot3"></i></span>
			</div>
			<h6><?php echo esc_html($settings['title']); ?></h6>
			<p class="m-0px"><?php echo wp_kses_post( $settings['desc'] ); ?></p>
		</div>
		<?php } elseif( $settings['style'] == 'ten') { ?>
			<div class="owl-carousel owl-no-overflow" 
                    data-items="3" 
                    data-nav-dots="true" 
                    data-md-items="2" 
                    data-sm-items="2" 
                    data-xs-items="1" 
                    data-xx-items="1" 
                    data-space="30"
                    data-center="true"
					data-stage="50">
				<?php foreach ( $settings['services'] as $item ) : ?>	
				<div class="box-shadow-hover p-30px white-bg text-center border-top-3 border-color-theme hover-top m-25px-b" >
					<div class="avatar-100 border-radius-5 theme-bg-alt m-20px-b border-radius-50"> 
						<?php if( $item['img']['id'] ) { ?>
						<img src="<?php echo mombo_get_image_size_by_img_id($item['img']['id'], 100, 100, true); ?>" alt="<?php echo esc_attr($item['title']); ?>">
						<?php } ?>
					</div>
					<h6 class="font-2"><?php echo esc_html($item['title']); ?></h6>
					<p class="m-0px"><?php echo wp_kses_post( $item['desc'] ); ?></p>  
					<?php
						$target = $item['btn_link']['is_external'] ? ' target="_blank"' : '';
						$nofollow = $item['btn_link']['nofollow'] ? ' rel="nofollow"' : '';  
						if ( $item['btn_text'] ) {
							echo '<div class="p-15px-t"><a class="m-btn m-btn-theme-light m-btn-radius m-btn-sm" href="' . $item['btn_link']['url'] . '"' . $target . $nofollow . '>'.esc_html($item['btn_text']).'</a></div>'; 
						}  
					?>
				</div> 
				<?php endforeach; ?> 
			</div>
		
		<?php } else { ?>
			<div class="owl-carousel" 
				data-items="3" 
				data-nav-dots="false" 
				data-md-items="3" 
				data-sm-items="2" 
				data-xs-items="2" 
				data-xx-items="1" 
				data-space="30">
				<?php foreach ( $settings['services'] as $item ) : ?>
				<div class="box-shadow hover-top white-bg border-radius-5 p-20px-lr p-40px-tb text-center m-15px-t m-25px-b">
					<div class="d-inline-block m-30px-b"> 
						<?php if( $item['img']['id'] ) { ?>
						<img src="<?php echo mombo_get_image_size_by_img_id($item['img']['id'], 310, 218, true); ?>" alt="<?php echo esc_attr($item['title']); ?>">
						<?php } ?>
					</div>
					<h5><?php echo esc_html($item['title']); ?></h5>
					<p class="m-0px font-2"><?php echo wp_kses_post( $item['desc'] ); ?></p>
					 
					<?php
						$target = $item['btn_link']['is_external'] ? ' target="_blank"' : '';
						$nofollow = $item['btn_link']['nofollow'] ? ' rel="nofollow"' : '';  
						if ( $item['btn_text'] ) {
							echo '<div class="p-15px-t"><a class="m-btn m-btn-t-theme m-btn-radius" href="' . $item['btn_link']['url'] . '"' . $target . $nofollow . '>'.esc_html($item['btn_text']).'</a></div>'; 
						}  
					?> 
				</div>
				<?php endforeach; ?> 
			</div>
		<?php } ?>
	<?php } 
}

Plugin::instance()->widgets_manager->register_widget_type( new Mombo_Service_Widget() );
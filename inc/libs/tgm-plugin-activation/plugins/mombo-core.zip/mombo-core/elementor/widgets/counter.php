<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Mombo Counter Widget.
 *
 * Mombo widget that inserts an embeddable content into the page, from any given URL.
 *
 * @since 1.0
 */

class Mombo_Counter_Widget extends Widget_Base {

	public function get_name() {
		return 'mombo-counter';
	}

	public function get_title() {
		return esc_html__( 'Mombo: Counter', 'mombo-core' );
	}

	public function get_icon() {
		return 'eicon-counter';
	}

	public function get_categories() {
		return [ 'mombo-category' ];
	}

	/**
	 * Register Counter widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'mombo-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'style',
			[
				'label' => esc_html__( 'Style', 'mombo-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'one',
				'options' => [
					'one' => esc_html__( 'One', 'mombo-core' ),
					'two' => esc_html__( 'Two', 'mombo-core' ), 
					'three' => esc_html__( 'Three', 'mombo-core' ), 
				],
			]
		);

		$this->add_control(
			'icon_from',
			[
				'label' => esc_html__( 'Icon from', 'mombo-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'library',
				'options' => [
					'library' => esc_html__( 'Library', 'mombo-core' ),
					'class' => esc_html__( 'Class', 'mombo-core' ),  
				], 
				'conditions' => [ 
					'terms' => [ 
						[
							'name' => 'style',
							'operator' => 'in',
							'value' => ['one'],
						],
					],
                ],
			]
		); 

		$this->add_control(
			'icon',
			[ 
				'label' => esc_html__( 'Icon', 'mombo-core' ),
				'type' => Controls_Manager::ICONS, 
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'brand',
				],
				'conditions' => [ 
					'terms' => [ 
						[
							'name' => 'icon_from',
							'operator' => 'in',
							'value' => ['library'],
						],
						[
							'name' => 'style',
							'operator' => 'in',
							'value' => ['one'],
						],
					],
                ],
			], 
		); 
		$this->add_control(
			'icon_class',
			[
				'label' => esc_html__( 'Icon Class', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'icon-desktop',
				'conditions' => [ 
					'terms' => [ 
						[
							'name' => 'icon_from',
							'operator' => 'in',
							'value' => ['class'],
						],
						[
							'name' => 'style',
							'operator' => 'in',
							'value' => ['one'],
						],
					],
				], 
			]
		);  
		
		$this->add_control(
			'text',
			[
				'label' => esc_html__( 'Text', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'Happy Client',
				'conditions' => [ 
					'terms' => [  
						[
							'name' => 'style',
							'operator' => '!in',
							'value' => ['three'],
						],
					],
				], 
			]
		); 
		$this->add_control(
			'number_text',
			[
				'label' => esc_html__( 'Number Text', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'k',
				'conditions' => [ 
					'terms' => [  
						[
							'name' => 'style',
							'operator' => 'in',
							'value' => ['three'],
						],
					],
				], 
			]
		); 

		$this->add_control(
			'number',
			[
				'label' => esc_html__( 'Number', 'mombo-core' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 200,
			]
		);
		$this->end_controls_section(); 

	}

	/**
	 * Render Counter widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() { 
		$settings = $this->get_settings_for_display(); ?>  
		<?php
			$icon_class = '';
			if ( $settings['icon_from'] == 'library' ) {
				$icon_class = $settings['icon']['value'];
			} else {
				$icon_class = $settings['icon_class'];
			}  
		if ( $settings['style'] == 'one' ) { ?> 
		<div class="counter-col-02 theme-after d-flex">
			<div class="cc-icon"> 
				<i class="<?php echo esc_attr( $icon_class ); ?> theme-color"></i>
			</div>
			<div class="count-data">
				<div class="count dark-color" data-to="<?php echo esc_attr($settings['number']); ?>" data-speed="<?php echo esc_attr($settings['number']); ?>"><?php echo esc_attr($settings['number']); ?></div>
				<h6><?php echo esc_html($settings['text']); ?></h6>
			</div>
		</div>
		<?php } elseif ($settings['style'] == 'two' ) { ?>
			<div class="counter text-center">
				<div class="count white-color h1 font-w-600" data-to="<?php echo esc_attr($settings['number']); ?>" data-speed="<?php echo esc_attr($settings['number']); ?>"><?php echo esc_attr($settings['number']); ?></div>
				<h6 class="white-color-light after-50px white-after p-20px-b m-0px"><?php echo esc_html($settings['text']); ?></h6>
			</div>
		<?php } else { ?>
			<div class="counter text-center"> 
				<h2 class="count white-color display-4 font-w-300 d-inline-block" data-to="<?php echo esc_attr($settings['number']); ?>" data-speed="<?php echo esc_attr($settings['number']); ?>"><?php echo esc_attr($settings['number']); ?></h2>
				<span class="h2 font-w-300 white-color m-5px-l"><?php echo esc_attr($settings['number_text']); ?></span> 
			</div>
		<?php } ?>
	<?php } 
}

Plugin::instance()->widgets_manager->register_widget_type( new Mombo_Counter_Widget() );
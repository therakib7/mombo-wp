<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Mombo Post_Latest Widget.
 *
 * Mombo widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0
 */

class Mombo_Post_Latest_Widget extends Widget_Base {

	public function get_name() {
		return 'mombo-post-latest';
	}

	public function get_title() {
		return esc_html__( 'Mombo: Post Latest', 'mombo-core' );
	}

	public function get_icon() {
		return 'eicon-image-box';
	}

	public function get_categories() {
		return [ 'mombo-category' ];
	}

	/**
	 * Register Post_Latest widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'mombo-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'post_style',
			[
				'label' => esc_html__( 'Post Style', 'mombo-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'one',
				'options' => [
					'one' => esc_html__( 'One', 'mombo-core' ),
					'two' => esc_html__( 'Two', 'mombo-core' ), 
					'three' => esc_html__( 'Three', 'mombo-core' ), 
					'four' => esc_html__( 'Four', 'mombo-core' ), 
				],
			]
		); 

		$this->add_control(
			'total',
			[
				'label' => esc_html__( 'Total Post', 'mombo-core' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 3,
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render Post_Latest widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display(); 
		?> 
		<div class="row">
			<?php 
			$args = array(
				'posts_per_page' => $settings['total'],  
				'post_type' => 'post'
			);
			$the_query = new \WP_Query( $args ); 
			while ( $the_query->have_posts() ) : $the_query->the_post();
				set_query_var( 'mombo_col', 3 );
				switch ($settings['post_style']) {
					case "one":
						get_template_part( 'template-parts/post/content' );
					  	break;
					case "two":
						get_template_part( 'template-parts/post/style/content', 'two' );
					  	break;
					case "three":
						get_template_part( 'template-parts/post/style/content', 'three' );
						break;
					case "four":
						get_template_part( 'template-parts/post/style/content', 'four' );
					  	break;
					default:
						get_template_part( 'template-parts/post/content' );
				}
							 
			endwhile; wp_reset_postdata(); ?>
		</div>
		<?php  
	}

}

Plugin::instance()->widgets_manager->register_widget_type( new Mombo_Post_Latest_Widget() );
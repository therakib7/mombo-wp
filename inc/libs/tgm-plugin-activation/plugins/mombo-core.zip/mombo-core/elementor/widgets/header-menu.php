<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Mombo Header_Menu Widget.
 *
 * Mombo widget that inserts an embeddable content into the page, from any given URL.
 *
 * @since 1.0
 */

class Mombo_Header_Menu_Widget extends Widget_Base {

	public function get_name() {
		return 'mombo-header-menu';
	}

	public function get_title() {
		return esc_html__( 'Mombo: Header Menu', 'mombo-core' );
	}

	public function get_icon() {
		return 'eicon-nav-menu';
	}

	public function get_categories() {
		return [ 'mombo-category' ];
	}

	/**
	 * Register Header_Menu widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'mombo-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);  

		$this->add_control(
			'menu_pos',
			[
				'label' => esc_html__( 'Menu Position', 'mombo-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'center',
				'options' => [
					'center' => esc_html__( 'Center', 'mombo-core' ),  
					'right' => esc_html__( 'Right', 'mombo-core' ),
				],
			]
		);

		$this->add_control(
			'container_size',
			[
				'label' => esc_html__( 'Container Area Size', 'mombo-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'container',
				'options' => [
					'container' => esc_html__( 'Container', 'mombo-core' ),  
					'large' => esc_html__( 'Container Large', 'mombo-core' ),
				],
			]
		);

		$menu_lists = [];
		$wp_nav_menus = wp_get_nav_menus();
		foreach( $wp_nav_menus as $menu ) {
			$menu_lists[$menu->slug] = $menu->name;
		} 

		$this->add_control(
			'menu_id',
			[
				'label' => esc_html__( 'Choose Menu', 'mombo-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'header-menu',
				'options' => $menu_lists,
			]
		); 

		$this->add_control(
			'btn_text',
			[
				'label' => esc_html__( 'Button Text', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => '', 
				'conditions' => [ 
					'terms' => [ 
						[
							'name' => 'menu_pos',
							'operator' => '!in',
							'value' => ['right'],
						],
					],
				], 
			]
		);

		$this->add_control(
			'menu_color_dark',
			[
				'label' => esc_html__( 'Menu Color Dark?', 'mombo-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'mombo-core' ),
				'label_off' => esc_html__( 'No', 'mombo-core' ),
				'return_value' => 'yes',
				'default' => '', 
			]
		);

		$this->add_control(
			'btn_link',
			[
				'label' => esc_html__( 'Button Link', 'mombo-core' ),
				'type' => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'mombo-core' ),
				'show_external' => true,
				'conditions' => [ 
					'terms' => [ 
						[
							'name' => 'menu_pos',
							'operator' => '!in',
							'value' => ['right'],
						],
					],
				], 
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				], 
			]
		);   
		$this->end_controls_section(); 

		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Background', 'mombo-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		); 
		$this->add_control(
			'btn_bg',
			[
				'label'     => esc_html__( 'Button Background Color', 'mombo-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '#15db95',
				'selectors' => [
					'{{WRAPPER}} .menu-right-btn' => 'background-color: {{VALUE}}; color: #fff;',
				],
			]
		);   
		$this->add_control(
			'btn_hover_bg',
			[
				'label'     => esc_html__( 'Button Hover Color', 'mombo-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '#0e9566',
				'selectors' => [
					'{{WRAPPER}} .menu-right-btn:hover' => 'background-color: {{VALUE}}; color: #fff;',
				],
			]
		);   
		$this->end_controls_section(); 

	}

	/**
	 * Render Header_Menu widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() { 
		$settings = $this->get_settings_for_display(); 
		$container_size = ( $settings['container_size'] == 'large' ) ? ' ' : 'container';
		?>   
		<!-- Header -->
		<header class="header-nav header-white">
			<div class="fixed-header-bar">
				<div class="<?php echo esc_attr( $container_size ); ?> container-large">
					<div class="navbar navbar-default navbar-expand-lg main-navbar">
						<div class="navbar-brand">
							<a href="<?php echo esc_url( home_url('/') ); ?>" title="<?php esc_attr( bloginfo( 'name' ) ); ?>" class="logo"> 
								<?php if ( $settings['menu_color_dark'] ) { ?>
									<img src="<?php echo esc_url(  mombo_get_options( array('logo_sticky_menu', get_theme_file_uri('/assets/img/logo.svg')) ) ); ?>" class="light-logo" alt="<?php esc_attr( bloginfo( 'name' ) ); ?>">
								<?php } else { ?>
									<img src="<?php echo esc_url(  mombo_get_options( array('logo', get_theme_file_uri('/assets/img/logo-light.svg')) ) ); ?>" class="light-logo" alt="<?php esc_attr( bloginfo( 'name' ) ); ?>">
								<?php } ?>

								<img src="<?php echo esc_url(  mombo_get_options( array('logo_sticky_menu', get_theme_file_uri('/assets/img/logo.svg')) ) ); ?>" class="dark-logo" alt="<?php esc_attr( bloginfo( 'name' ) ); ?>">
							</a>
						</div> 

						<?php 
							$menu_color_dark = ( $settings['menu_color_dark'] ) ? ' menu-color-dark' : '';
							$menu_align_right = ( $settings['menu_pos'] == 'right' ) ? ' menu-align-right' : '';
							wp_nav_menu ( array(
								'container_class' => 'main-menu' . $menu_color_dark . $menu_align_right,
								'container'=> 'div',
								'theme_location' => $settings['menu_id'],  
								'walker' => new \Mombo_Custom_Walker() ,
								'fallback_cb'  => 'Mombo_Custom_Walker::fallback_header_menu', 
							)); 
						?>  

						<div class="extra-menu d-flex align-items-center">  

							<?php
							if ( $settings['menu_pos'] != 'right' ) {
								$target = $settings['btn_link']['is_external'] ? ' target="_blank"' : '';
								$nofollow = $settings['btn_link']['nofollow'] ? ' rel="nofollow"' : '';  
								if ( $settings['btn_text'] ) {
									echo '<div class="d-none d-md-block h-btn m-35px-l"><a class="m-btn menu-right-btn m-btn-radius" href="' . $settings['btn_link']['url'] . '"' . $target . $nofollow . '>'.esc_html($settings['btn_text']).'</a></div>'; 
								}  
							}
							?>

							<button type="button" class="tc-toggle-menu d-lg-none">
								<i class="fas fa-bars"></i>
							</button>
						</div>
					</div>
				</div>
			</div>
		</header>
		<!-- Header End --> 	 
	<?php } 
}

Plugin::instance()->widgets_manager->register_widget_type( new Mombo_Header_Menu_Widget() );
<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Mombo Icon Widget.
 *
 * Mombo widget that inserts an embeddable content into the page, from any given URL.
 *
 * @since 1.0
 */

class Mombo_Icon_Widget extends Widget_Base {

	public function get_name() {
		return 'mombo-icon';
	}

	public function get_title() {
		return esc_html__( 'Mombo: Icon', 'mombo-core' );
	}

	public function get_icon() {
		return 'eicon-favorite';
	}

	public function get_categories() {
		return [ 'mombo-category' ];
	}

	/**
	 * Register Icon widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'mombo-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		); 

		$this->add_control(
			'style',
			[
				'label' => esc_html__( 'Style', 'mombo-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'circle',
				'options' => [
					'circle' => esc_html__( 'Circle', 'mombo-core' ),
					'square' => esc_html__( 'Square', 'mombo-core' ), 
				],
			]
		);

		$this->add_control(
			'animation_style',
			[
				'label' => esc_html__( 'Animation Style', 'mombo-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'spin',
				'options' => [
					'spin' => esc_html__( 'Spin', 'mombo-core' ),
					'twincle' => esc_html__( 'Twincle', 'mombo-core' ), 
				],
			]
		);  

		$this->add_control(
			'icon_from',
			[
				'label' => esc_html__( 'Icon from', 'mombo-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'library',
				'options' => [
					'library' => esc_html__( 'Library', 'mombo-core' ),
					'class' => esc_html__( 'Class', 'mombo-core' ),  
				], 
			]
		); 

		$this->add_control(
			'icon',
			[ 
				'label' => esc_html__( 'Icon', 'mombo-core' ),
				'type' => Controls_Manager::ICONS, 
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'brand',
				],
				'conditions' => [ 
					'terms' => [ 
						[
							'name' => 'icon_from',
							'operator' => 'in',
							'value' => ['library'],
						],
					],
                ],
			], 
		); 
		$this->add_control(
			'icon_class',
			[
				'label' => esc_html__( 'Icon Class', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'icon-desktop',
				'conditions' => [ 
					'terms' => [ 
						[
							'name' => 'icon_from',
							'operator' => 'in',
							'value' => ['class'],
						],
					],
				], 
			]
		);  
		$this->end_controls_section(); 

		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Background', 'mombo-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		); 
		$this->add_control(
			'icon_bg',
			[
				'label'     => esc_html__( 'Icon Background Color', 'mombo-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '#f1f6fd',
				'selectors' => [
					'{{WRAPPER}} .mombo-icon' => 'background-color: {{VALUE}};',
				],
			]
		);  
		$this->add_control(
			'icon_color',
			[
				'label'     => esc_html__( 'Icon Color', 'mombo-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '#03c',
				'selectors' => [
					'{{WRAPPER}} .mombo-icon' => 'color: {{VALUE}};',
				],
			]
		);   
		$this->add_control(
			'icon_border_color',
			[
				'label'     => esc_html__( 'Icon Border Color', 'mombo-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '',
				'selectors' => [
					'{{WRAPPER}} .mombo-icon' => 'border-color: {{VALUE}};',
				],
			]
		);  
		$this->add_control(
			'icon_spin_color',
			[
				'label'     => esc_html__( 'Icon Spin Color', 'mombo-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '#03c',
				'condition' => [
					'animation_style' => 'spin'
				],
				'selectors' => [
					'{{WRAPPER}} .mombo-icon i' => 'color: {{VALUE}};',
				],
			]
		);  
		$this->end_controls_section(); 

	}

	/**
	 * Render Icon widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() { 
		$settings = $this->get_settings_for_display(); ?> 
		<?php
			$icon_class = '';
			if ( $settings['icon_from'] == 'library' ) {
				$icon_class = $settings['icon']['value'];
			} else {
				$icon_class = $settings['icon_class'];
			}  
		?>
		<?php if ( $settings['animation_style'] == 'spin' ) { ?>
			<div class="hover-rotate">
				<div class="mombo-icon ef-1 icon-80  border-radius-50 d-inline-block m-20px-b hr-rotate-after">
					<i class="<?php echo esc_attr( $icon_class ); ?>"></i>
				</div>
			</div>
		<?php } else { ?>
			<div class="mombo-icon <?php echo ( ( $settings['style'] == 'circle' ) ) ? 'icon-80 border-radius-50' : 'icon-70 border-radius-5 border-all-1' ; ?> dots-icon d-inline-block m-20px-b">
				<i class="<?php echo esc_attr( $icon_class ); ?>"></i>
				<span class="dots"><i class="dot dot1"></i><i class="dot dot2"></i><i class="dot dot3"></i></span>
			</div>
		<?php } ?>  
	<?php } 
}

Plugin::instance()->widgets_manager->register_widget_type( new Mombo_Icon_Widget() );
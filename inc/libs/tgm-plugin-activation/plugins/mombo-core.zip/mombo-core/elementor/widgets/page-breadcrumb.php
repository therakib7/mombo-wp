<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Mombo Page_Breadcrumb Widget.
 *
 * Mombo widget that inserts an embeddable content into the page, from any given URL.
 *
 * @since 1.0
 */

class Mombo_Page_Breadcrumb_Widget extends Widget_Base {

	public function get_name() {
		return 'mombo-page-breadcrumb';
	}

	public function get_title() {
		return esc_html__( 'Mombo: Page Breadcrumb', 'mombo-core' );
	}

	public function get_icon() {
		return 'eicon-archive-title';
	}

	public function get_categories() {
		return [ 'mombo-category' ];
	}

	/**
	 * Register Page_Breadcrumb widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'mombo-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);  
		
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => '',
			]
		);  
		$this->end_controls_section(); 

	}

	/**
	 * Render Page_Breadcrumb widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() { 
		$settings = $this->get_settings_for_display(); ?>   
		<ol class="breadcrumb white justify-content-center">
			<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e('Home', 'mombo'); ?></a></li>
			<li class="active"><?php echo esc_html( $settings['title'] ); ?></li>
		</ol>	 
	<?php } 
}

Plugin::instance()->widgets_manager->register_widget_type( new Mombo_Page_Breadcrumb_Widget() );
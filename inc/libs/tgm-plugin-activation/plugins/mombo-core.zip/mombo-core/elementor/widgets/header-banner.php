<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Mombo Header_Banner Widget.
 *
 * Mombo widget that inserts an embeddable content into the page, from any given URL.
 *
 * @since 1.0
 */

class Mombo_Header_Banner_Widget extends Widget_Base {

	public function get_name() {
		return 'mombo-header-banner';
	}

	public function get_title() {
		return esc_html__( 'Mombo: Header Banner', 'mombo-core' );
	}

	public function get_icon() {
		return 'eicon-media-carousel';
	}

	public function get_categories() {
		return [ 'mombo-category' ];
	}

	/**
	 * Register Header_Banner widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'mombo-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		); 

		$this->add_control(
			'style',
			[
				'label' => esc_html__( 'Header Banner Style', 'mombo-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'one',
				'options' => [
					'one' => esc_html__( 'One', 'mombo-core' ),
					'two' => esc_html__( 'Two', 'mombo-core' ), 
					'three' => esc_html__( 'Three', 'mombo-core' ), 
					'four' => esc_html__( 'Four', 'mombo-core' ), 
					'five' => esc_html__( 'Five', 'mombo-core' ), 
					'six' => esc_html__( 'Six', 'mombo-core' ), 
					'seven' => esc_html__( 'Seven', 'mombo-core' ), 
					'eight' => esc_html__( 'Eight', 'mombo-core' ), 
					'nine' => esc_html__( 'Nine', 'mombo-core' ), 
					'ten' => esc_html__( 'Ten', 'mombo-core' ), 
					'eleven' => esc_html__( 'Eleven', 'mombo-core' ), 
					'twelve' => esc_html__( 'Twelve', 'mombo-core' ), 
					'thirteen' => esc_html__( 'Thirteen', 'mombo-core' ), 
				],
			]
		);  
		
		$this->add_control(
			'title_top',
			[
				'label' => esc_html__( 'Title Top', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'Welcome to <span class="theme-color">Mombo</span>. Develop anything.',
				'conditions' => [
					'terms' => [
						[
							'name' => 'style',
							'operator' => 'in',
							'value' => ['twelve'],
						],
						[
							'name' => 'style',
							'operator' => '!in',
							'value' => ['seven', 'thirteen'],
						],
					],
				],
			]
		); 
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'Our Analysis is your financial results',
				'conditions' => [
					'terms' => [
						[
							'name' => 'style',
							'operator' => '!in',
							'value' => ['seven', 'thirteen'],
						],
					],
				],
			]
		);  
		$this->add_control(
			'desc',
			[
				'label'       => esc_html__( 'Description', 'mombo-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [ 'active' => true ], 
				'default'     => 'Mombo is a WordPress theme based on Sass and Bootstrap 4 with modern and creative multipurpose design you can use it as a startups.',
				'conditions' => [
					'terms' => [
						[
							'name' => 'style',
							'operator' => '!in',
							'value' => ['seven', 'thirteen'],
						],
					],
				],
			]
		); 

		$this->add_control(
			'img',
			[
				'label'       => esc_html__( 'Image', 'mombo-core' ),
				'type' => Controls_Manager::MEDIA,
				'conditions' => [
					'terms' => [ 
						[
							'name' => 'style',
							'operator' => '!in',
							'value' => ['thirteen'],
						],
					],
				],
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'mailchimp_shortcode',
			[
				'label' => esc_html__( 'MailChimp ShortCode', 'mombo-core' ),
				'type' => Controls_Manager::TEXT, 
				'description' => __( 'For show ID <a href="admin.php?page=mailchimp-for-wp-forms" target="_blank"> Click here </a>', 'mombo-core' ),
				'conditions' => [
					'terms' => [ 
						[
							'name' => 'style',
							'operator' => 'in',
							'value' => ['one', 'five', 'eleven'],
						],
					],
				],
				'label_block' => true,
				'separator'   => 'before',
			]
		);

		$this->add_control(
			'btn_text',
			[
				'label' => esc_html__( 'Button Text', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'Start now',
				'conditions' => [
					'terms' => [
						[
							'name' => 'style',
							'operator' => 'in',
							'value' => ['two', 'three', 'four', 'six', 'ten', 'twelve'],
						],
						[
							'name' => 'style',
							'operator' => '!in',
							'value' => ['seven', 'thirteen'],
						],
					],
				],
			]
		); 
		$this->add_control(
			'btn_link',
			[ 
				'label' => esc_html__( 'Button Link', 'mombo-core' ),
				'type' => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'mombo-core' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
				'conditions' => [
					'terms' => [
						[
							'name' => 'style',
							'operator' => 'in',
							'value' => ['two', 'three', 'four', 'six', 'ten', 'twelve'],
						],
						[
							'name' => 'style',
							'operator' => '!in',
							'value' => ['seven', 'thirteen'],
						],
					],
				],
			],
		);  

		$this->add_control(
			'btn_two_text',
			[
				'label' => esc_html__( 'Button Text', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'How it works',
				'conditions' => [
					'terms' => [
						[
							'name' => 'style',
							'operator' => 'in',
							'value' => ['two', 'three', 'four', 'ten', 'twelve'],
						],
						[
							'name' => 'style',
							'operator' => '!in',
							'value' => ['seven', 'thirteen'],
						],
					],
				],
			]
		); 
		$this->add_control(
			'btn_two_link',
			[ 
				'label' => esc_html__( 'Two Link Link', 'mombo-core' ),
				'type' => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'mombo-core' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
				'conditions' => [
					'terms' => [
						[
							'name' => 'style',
							'operator' => 'in',
							'value' => ['two', 'three', 'four', 'ten', 'twelve'],
						],
						[
							'name' => 'style',
							'operator' => '!in',
							'value' => ['seven', 'thirteen'],
						],
					],
				],
			],
		);  
		
		$this->add_control(
			'slider_items',
			[
				'label' => esc_html__( 'Slider Items', 'mombo-core' ),
				'type' => Controls_Manager::REPEATER, 
				'conditions' => [
					'terms' => [
						[
							'name' => 'style',
							'operator' => 'in',
							'value' => ['seven', 'thirteen'],
						],
					],
				],
				'fields' => [  
					[
						'name' => 'icon_or_img',
						'label' => esc_html__( 'Icon Or Image', 'mombo-core' ),
						'type' => Controls_Manager::SELECT,
						'default' => 'icon',
						'options' => [
							'icon' => esc_html__( 'Icon', 'mombo-core' ),
							'img' => esc_html__( 'Image', 'mombo-core' ),  
						],
					],
					[
						'name' => 'icon_from',
						'label' => esc_html__( 'Icon from', 'mombo-core' ),
						'type' => Controls_Manager::SELECT,
						'default' => 'library',
						'options' => [
							'library' => esc_html__( 'Library', 'mombo-core' ),
							'class' => esc_html__( 'Class', 'mombo-core' ),  
						],
						'conditions' => [
							'terms' => [
								[
									'name' => 'icon_or_img',
									'operator' => 'in',
									'value' => ['icon'],
								],
							],
						],
					], 
					[ 
						'name' => 'icon',
						'label' => esc_html__( 'Icon', 'mombo-core' ),
						'type' => Controls_Manager::ICONS, 
						'default' => [
							'value' => 'fas fa-star',
							'library' => 'brand',
						],
						'conditions' => [ 
							'terms' => [
								[
									'name' => 'icon_or_img',
									'operator' => 'in',
									'value' => ['icon'],
								],
								[
									'name' => 'icon_from',
									'operator' => 'in',
									'value' => ['library'],
								],
							],
				        ],
					],  
					[
						'name' => 'icon_class',
						'label' => esc_html__( 'Icon Class', 'mombo-core' ),
						'type' => Controls_Manager::TEXT,
						'default' => 'icon-desktop',
						'conditions' => [ 
							'terms' => [
								[
									'name' => 'icon_or_img',
									'operator' => 'in',
									'value' => ['icon'],
								],
								[
									'name' => 'icon_from',
									'operator' => 'in',
									'value' => ['class'],
								],
							],
						], 
					],
					[
						'name' => 'img',
						'label'       => esc_html__( 'Image', 'mombo-core' ), 
						'type' => Controls_Manager::MEDIA,
						'conditions' => [ 
							'terms' => [
								[
									'name' => 'icon_or_img',
									'operator' => 'in',
									'value' => ['img'],
								], 
							],
						], 
						'dynamic' => [
							'active' => true,
						],
						'default' => [
							'url' => Utils::get_placeholder_image_src(),
						], 
					],
					[
						'name' => 'title',
						'label' => esc_html__( 'Title', 'mombo-core' ),
						'type' => Controls_Manager::TEXT,
						'label_block' => true, 
						'default' => 'Web Development',
					],  
					[
						'name' 		  => 'desc',
						'label'       => esc_html__( 'Description', 'mombo-core' ),
						'type'        => Controls_Manager::TEXTAREA,
						'dynamic'     => [ 'active' => true ], 
						'default'     => 'Momboo is a WordPress Theme based on Sass and Bootstrap 4 with modern and creative multipurpose design you can use it as a startups.', 
					],
					[
						'name' 		  => 'btn_text',
						'label' => esc_html__( 'Button Text', 'mombo-core' ),
						'type' => Controls_Manager::TEXT,
						'default' => 'Start Now', 
					],
					[ 
						'name' 		  => 'btn_link',
						'label' => esc_html__( 'Button Link', 'mombo-core' ),
						'type' => Controls_Manager::URL,
						'placeholder' => esc_html__( 'https://your-link.com', 'mombo-core' ),
						'show_external' => true,
						'default' => [
							'url' => '',
							'is_external' => true,
							'nofollow' => true,
						], 
					], 
					[
						'name' 		  => 'btn_two_text',
						'label' => esc_html__( 'Button Text', 'mombo-core' ),
						'type' => Controls_Manager::TEXT,
						'default' => 'How it works', 
					], 
					[ 
						'name' 		  => 'btn_two_link',
						'label' => esc_html__( 'Two Link Link', 'mombo-core' ),
						'type' => Controls_Manager::URL,
						'placeholder' => esc_html__( 'https://your-link.com', 'mombo-core' ),
						'show_external' => true,
						'default' => [
							'url' => '',
							'is_external' => true,
							'nofollow' => true,
						], 
					], 
				],
				'title_field' => ' {{ title }}',
			]
		);
		$this->end_controls_section();  
	}

	/**
	 * Render Header_Banner widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() { 
		$settings = $this->get_settings_for_display(); ?>   
		<?php if ( $settings['style'] == 'one') { ?>
		<section id="home" class="effect-section gray-bg">
            <div class="effect theme-bg effect-skew"></div>
            <div class="particles-box" id="particles-box"></div>
            <div class="container container-large">
                <div class="row full-screen align-items-center p-100px-tb">
                    <div class="col-12 col-lg-5 col-xl-4 p-50px-tb">
                        <h1 class="white-color h1 m-15px-b"><?php echo esc_html($settings['title']); ?></h1>
                        <p class="font-2 white-color-light m-20px-b"><?php echo wp_kses_post( $settings['desc'] ); ?></p>
                        <?php echo do_shortcode( $settings['mailchimp_shortcode'] ); ?>
                    </div>
                    <div class="col-lg-7 col-xl-8">
						<?php if( $settings['img']['id'] ) { ?>
						<img class="max-width-auto" src="<?php echo mombo_get_image_size_by_img_id($settings['img']['id'], 917, 586, true); ?>" alt="<?php echo esc_attr($settings['title']); ?>">
						<?php } ?>
                    </div>
                </div>
            </div>
        </section>
		<?php } elseif( $settings['style'] == 'two') { ?>
		<section id="home" class="effect-section gray-bg">
            <div class="effect theme-bg effect-radius"></div>
            <div class="container">
                <div class="row full-screen align-items-center p-100px-tb justify-content-between">
                    <div class="col-lg-5 lg-m-40px-t md-m-10px-t">
                        <h1 class="white-color display-4 m-15px-b"><?php echo esc_html($settings['title']); ?></h1>
                        <p class="font-2 white-color-light m-0px"><?php echo wp_kses_post( $settings['desc'] ); ?></p>
                        <div class="btn-bar p-25px-t">
							<?php
								$target = $settings['btn_link']['is_external'] ? ' target="_blank"' : '';
								$nofollow = $settings['btn_link']['nofollow'] ? ' rel="nofollow"' : '';  
								if ( $settings['btn_text'] ) {
									echo '<a class="m-btn m-btn-theme2nd m-btn-radius" href="' . $settings['btn_link']['url'] . '"' . $target . $nofollow . '>'.esc_html($settings['btn_text']).'</a> '; 
								} 

								$target = $settings['btn_two_link']['is_external'] ? ' target="_blank"' : '';
								$nofollow = $settings['btn_two_link']['nofollow'] ? ' rel="nofollow"' : '';  
								if ( $settings['btn_two_text'] ) {
									echo '<a class="m-btn m-btn-white m-btn-radius" href="' . $settings['btn_two_link']['url'] . '"' . $target . $nofollow . '>'.esc_html($settings['btn_two_text']).'</a>'; 
								} 
							?> 
                        </div>
                    </div>
                    <div class="col-lg-6 lg-m-30px-t"> 
						<?php if( $settings['img']['id'] ) { ?>
						<img class="max-width-auto" src="<?php echo mombo_get_image_size_by_img_id($settings['img']['id'], 767, 590, true); ?>" alt="<?php echo esc_attr($settings['title']); ?>">
						<?php } ?>
                    </div>
                </div>
            </div>
        </section>
		<?php } elseif( $settings['style'] == 'three') { ?>
		<section id="home" class="effect-section theme-bg">
            <div class="effect effect-bg opacity-5 bg-cover bg-fixed bg-center" style="background-image: url(<?php echo get_template_directory_uri(); ?>/assets/img/home-3-1-bg.png);"></div>
            <div class="container">
                <div class="row full-screen align-items-center justify-content-between lg-m-80px-tb">
                    <div class="col-lg-6 m-50px-tb">
                        <h1 class="white-color display-4 m-20px-b"><?php echo esc_html($settings['title']); ?>.</h1>
                        <p class="font-2 white-color-light"><?php echo wp_kses_post( $settings['desc'] ); ?></p>
                        <div class="btn-bar p-25px-t">
							<?php
								$target = $settings['btn_link']['is_external'] ? ' target="_blank"' : '';
								$nofollow = $settings['btn_link']['nofollow'] ? ' rel="nofollow"' : '';  
								if ( $settings['btn_text'] ) {
									echo '<a class="m-btn m-btn-theme2nd m-btn-radius" href="' . $settings['btn_link']['url'] . '"' . $target . $nofollow . '>'.esc_html($settings['btn_text']).'</a>'; 
								} 

								$target = $settings['btn_two_link']['is_external'] ? ' target="_blank"' : '';
								$nofollow = $settings['btn_two_link']['nofollow'] ? ' rel="nofollow"' : '';  
								if ( $settings['btn_two_text'] ) {
									echo '<a class="m-btn m-link white popup-youtube m-20px-l" href="' . $settings['btn_two_link']['url'] . '"' . $target . $nofollow . '>'.esc_html($settings['btn_two_text']).' <i class="fas fa-play p-5px-l"></i></a>'; 
								} 
							?>  
                        </div>
                    </div>
                    <div class="col-lg-6">
						<?php if( $settings['img']['id'] ) { ?>
						<img class="max-width-auto" src="<?php echo mombo_get_image_size_by_img_id($settings['img']['id'], 640, 761, true); ?>" alt="<?php echo esc_attr($settings['title']); ?>">
						<?php } ?>
                    </div>
                </div>
            </div>
        </section>			
		<?php } elseif( $settings['style'] == 'four') { ?>
		<section id="home" class="effect-section">
            <div class="effect-shape theme-bg"></div>
            <div class="container">
                <div class="row full-screen align-items-center justify-content-between lg-m-80px-tb">
                    <div class="col-lg-6 m-50px-tb">
                        <h1 class="white-color display-4 m-20px-b"><?php echo esc_html($settings['title']); ?>.</h1>
                        <p class="font-2 white-color-light"><?php echo wp_kses_post( $settings['desc'] ); ?></p>
                        <div class="btn-bar p-25px-t">
							<?php
								$target = $settings['btn_link']['is_external'] ? ' target="_blank"' : '';
								$nofollow = $settings['btn_link']['nofollow'] ? ' rel="nofollow"' : '';  
								if ( $settings['btn_text'] ) {
									echo '<a class="m-btn m-btn-theme2nd m-btn-radius" href="' . $settings['btn_link']['url'] . '"' . $target . $nofollow . '>'.esc_html($settings['btn_text']).'</a>'; 
								} 

								$target = $settings['btn_two_link']['is_external'] ? ' target="_blank"' : '';
								$nofollow = $settings['btn_two_link']['nofollow'] ? ' rel="nofollow"' : '';  
								if ( $settings['btn_two_text'] ) {
									echo '<a class="m-btn m-link white popup-youtube m-20px-l" href="' . $settings['btn_two_link']['url'] . '"' . $target . $nofollow . '>'.esc_html($settings['btn_two_text']).' <i class="fas fa-play p-5px-l"></i></a>'; 
								} 
							?>  
                        </div>
                    </div>
                    <div class="col-lg-6"> 
						<?php if( $settings['img']['id'] ) { ?>
						<img class="max-width-auto" src="<?php echo mombo_get_image_size_by_img_id($settings['img']['id'], 802, 774, true); ?>" alt="<?php echo esc_attr($settings['title']); ?>">
						<?php } ?>
                    </div>
                </div>
            </div>
        </section>	
		<?php } elseif( $settings['style'] == 'five') { ?>
		<section id="home" class="effect-section">
            <div class="effect effect-bg-75 theme-bg"></div>
            <div class="container">
                <div class="row align-items-center justify-content-center m-100px-t">
                    <div class="col-lg-9 text-center m-60px-t md-m-40px-t">
                        <h1 class="display-3 white-color m-40px-b"><?php echo esc_html($settings['title']); ?></h1>
                        <p class="lead white-color-light m-30px-b"><?php echo wp_kses_post( $settings['desc'] ); ?></p>
                        <?php echo do_shortcode( $settings['mailchimp_shortcode'] ); ?>
                    </div>
                    <div class="col-lg-12 text-center"> 
						<?php if( $settings['img']['id'] ) { ?>
						<img src="<?php echo mombo_get_image_size_by_img_id($settings['img']['id'], 1110, 737, true); ?>" alt="<?php echo esc_attr($settings['title']); ?>">
						<?php } ?>
                    </div>
                </div>
            </div>
        </section>	
		<?php } elseif( $settings['style'] == 'six') { ?>
		<section id="home" class="gray-bg overflow-hidden">
            <div class="container">
                <div class="row full-screen align-items-center justify-content-between lg-p-80px-tb">
                    <div class="col-lg-6 m-50px-tb">
                        <label class="theme2nd-bg p-5px-tb p-20px-lr border-radius-5 white-color m-20px-b font-small">Get Start With Us</label>
                        <h1 class="dark-color display-4 m-20px-b"><?php echo esc_html($settings['title']); ?>.</h1>
                        <p class="font-2"><?php echo wp_kses_post( $settings['desc'] ); ?></p>
                        <div class="p-10px-t">
							<?php
								$target = $settings['btn_link']['is_external'] ? ' target="_blank"' : '';
								$nofollow = $settings['btn_link']['nofollow'] ? ' rel="nofollow"' : '';  
								if ( $settings['btn_text'] ) {
									echo '<a class="m-btn m-btn-theme m-btn-radius" href="' . $settings['btn_link']['url'] . '"' . $target . $nofollow . '>'.esc_html($settings['btn_text']).'</a>'; 
								}  
							?>   
                        </div>
                    </div>
                    <div class="col-lg-6"> 
						<?php if( $settings['img']['id'] ) { ?>
						<img class="max-width-auto" src="<?php echo mombo_get_image_size_by_img_id($settings['img']['id'], 924, 706, true); ?>" alt="<?php echo esc_attr($settings['title']); ?>">
						<?php } ?>
                    </div>
                </div>
            </div>
        </section>
		<?php } elseif( $settings['style'] == 'seven') { ?>
		<section id="home" class="theme-g-bg overflow-hidden">
            <div class="container">
                <div class="row full-screen align-items-center justify-content-center p-100px-t">
                    <div class="col-12 col-lg-4">
                        <div class="owl-carousel white-dot" data-items="1" data-nav-dots="true" data-space="30">
							<?php foreach ( $settings['slider_items'] as $item ) : ?>	
                            <div class="box-shadow white-bg border-radius-5 p-20px-lr p-40px-tb m-30px-b">
                                <div class="icon-80 gray-bg dots-icon border-radius-50 theme-color d-inline-block m-25px-b">
									<?php
										$icon_class = '';
										if ( $item['icon_from'] == 'library' ) {
											$icon_class = $item['icon']['value'];
										} else {
											$icon_class = $item['icon_class'];
										} 
									?>
                                    <i class="<?php echo esc_attr( $icon_class ); ?>"></i>
                                    <span class="dots"><i class="dot dot1"></i><i class="dot dot2"></i><i class="dot dot3"></i></span>
                                </div>
                                <h6 class="h5 m-20px-b"><?php echo esc_html($item['title']); ?></h6>
                                <p class="m-0px"><?php echo wp_kses_post( $item['desc'] ); ?></p>
                                <div class="m-30px-t"> 
									<?php
										$target = $item['btn_link']['is_external'] ? ' target="_blank"' : '';
										$nofollow = $item['btn_link']['nofollow'] ? ' rel="nofollow"' : '';  
										if ( $item['btn_text'] ) {
											echo '<a class="m-btn m-btn-theme m-btn-radius" href="' . $item['btn_link']['url'] . '"' . $target . $nofollow . '>'.esc_html($item['btn_text']).'</a>'; 
										}  
									?>
                                </div>
							</div>
							<?php endforeach; ?> 
                        </div>
                    </div>
                    <div class="col-12 col-lg-8 lg-m-40px-tb"> 
						<?php if( $settings['img']['id'] ) { ?>
						<img class="max-width-auto" src="<?php echo esc_url( wp_get_attachment_url( $settings['img']['id'],'full' ) ); ?>" alt="<?php echo esc_attr($settings['title']); ?>">
						<?php } ?>
                    </div>
                </div>
            </div>
        </section>
		<?php } elseif( $settings['style'] == 'eight') { ?>
		<section id="home" class="effect-section theme-g-bg">
            <div class="effect-img effect bottom"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/effect/home-effect--bottom-gray.svg" title="" alt=""></div>
            <div class="container">
                <div class="row align-items-center justify-content-center">
                    <div class="col-12 col-lg-10 text-center">
                        <div class="p-100px-t m-60px-t p-60px-b md-m-40px-t sm-m-20px-t">
                            <h3 class="white-color display-3 m-30px-b"><?php echo esc_html($settings['title']); ?></h3>
                            <p class="white-color-light lead m-0px"><?php echo wp_kses_post( $settings['desc'] ); ?></p>
                        </div>
                    </div>
                    <div class="col-12"> 
						<?php if( $settings['img']['id'] ) { ?>
						<img src="<?php echo mombo_get_image_size_by_img_id($settings['img']['id'], 1110, 520, true); ?>" alt="<?php echo esc_attr($settings['title']); ?>">
						<?php } ?>
                    </div>
                </div>
            </div>
        </section>
		<?php } elseif( $settings['style'] == 'nine') { ?>
		<section id="home" class="theme-bg section">
            <div class="container">
                <div class="row align-items-center justify-content-center">
                    <div class="col-12 col-lg-8 text-center">
                        <div class="p-60px-b">
                            <h3 class="white-color display-4 m-25px-b"><?php echo esc_html($settings['title']); ?></h3>
                            <p class="white-color-light lead m-0px"><?php echo wp_kses_post( $settings['desc'] ); ?></p>
                        </div>
                    </div>
                    <div class="col-12 text-center"> 
						<?php if( $settings['img']['id'] ) { ?>
						<img src="<?php echo mombo_get_image_size_by_img_id($settings['img']['id'], 960, 560, true); ?>" alt="<?php echo esc_attr($settings['title']); ?>">
						<?php } ?>
                    </div>
                </div>
            </div>
        </section>
		<?php } elseif( $settings['style'] == 'ten') { ?>
		<section id="home" class="effect-section parallax" style="background-image: url(<?php echo get_template_directory_uri(); ?>/assets/img/home-9-b-bg.png);">
            <div class="container">
                <div class="row full-screen align-items-center justify-content-between lg-m-80px-tb">
                    <div class="col-lg-6 m-50px-tb">
                        <h1 class="white-color display-4 m-20px-b"><?php echo esc_html($settings['title']); ?>.</h1>
                        <p class="font-2 white-color-light"><?php echo wp_kses_post( $settings['desc'] ); ?></p>
                        <div class="btn-bar p-25px-t">
							<?php
								$target = $settings['btn_link']['is_external'] ? ' target="_blank"' : '';
								$nofollow = $settings['btn_link']['nofollow'] ? ' rel="nofollow"' : '';  
								if ( $settings['btn_text'] ) {
									echo '<a class="m-btn m-btn-white m-btn-radius" href="' . $settings['btn_link']['url'] . '"' . $target . $nofollow . '>'.esc_html($settings['btn_text']).'</a>'; 
								} 

								$target = $settings['btn_two_link']['is_external'] ? ' target="_blank"' : '';
								$nofollow = $settings['btn_two_link']['nofollow'] ? ' rel="nofollow"' : '';  
								if ( $settings['btn_two_text'] ) {
									echo '<a class="m-btn m-link white popup-youtube m-20px-l" href="' . $settings['btn_two_link']['url'] . '"' . $target . $nofollow . '>'.esc_html($settings['btn_two_text']).' <i class="fas fa-play p-5px-l"></i></a>'; 
								} 
							?>   
                        </div>
                    </div>
                    <div class="col-lg-6"> 
						<?php if( $settings['img']['id'] ) { ?>
						<img class="max-width-auto" src="<?php echo mombo_get_image_size_by_img_id($settings['img']['id'], 828, 879, true); ?>" alt="<?php echo esc_attr($settings['title']); ?>">
						<?php } ?>
                    </div>
                </div>
            </div>
        </section>
		<?php } elseif( $settings['style'] == 'eleven') { ?>
		<section class="theme-bg section p-0px-b">
            <div class="particles-box" id="particles-box"></div>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12 col-lg-8 p-50px-tb text-center">
                        <h1 class="white-color h1 m-15px-b"><?php echo wp_kses_post( $settings['title'] ); ?></h1>
                        <p class="font-2 white-color-light font-w-400 m-20px-b"><?php echo wp_kses_post( $settings['desc'] ); ?></p>
                        <?php echo do_shortcode( $settings['mailchimp_shortcode'] ); ?>
                    </div>
                    <div class="col-12 col-lg-10"> 
						<?php if( $settings['img']['id'] ) { ?>
						<img src="<?php echo mombo_get_image_size_by_img_id($settings['img']['id'], 920, 505, true); ?>" alt="<?php echo esc_attr($settings['title']); ?>">
						<?php } ?>
                    </div>
                </div>
            </div>
        </section>
		<?php } elseif( $settings['style'] == 'twelve' ) { ?>
		<section class="section">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-5 m-15px-tb">
						<?php if ( $settings['title_top'] ) { ?>
                        <h1 class="h1 m-15px-b"><?php echo wp_kses_post( $settings['title_top'] ); ?></h1>
						<?php } ?>
                        <p class="font-2 m-20px-b"><?php echo wp_kses_post( $settings['desc'] ); ?></p>
                        <div class="p-10px-t">
							<?php
								$target = $settings['btn_link']['is_external'] ? ' target="_blank"' : '';
								$nofollow = $settings['btn_link']['nofollow'] ? ' rel="nofollow"' : '';  
								if ( $settings['btn_text'] ) {
									echo '<a class="m-btn m-btn-theme m-btn-radius" href="' . $settings['btn_link']['url'] . '"' . $target . $nofollow . '>'.esc_html($settings['btn_text']).' <i class="fas fa-arrow-right d-none d-md-inline m-10px-l"></i></a> '; 
								} 

								$target = $settings['btn_two_link']['is_external'] ? ' target="_blank"' : '';
								$nofollow = $settings['btn_two_link']['nofollow'] ? ' rel="nofollow"' : '';  
								if ( $settings['btn_two_text'] ) {
									echo '<a class="m-btn m-btn-theme-light m-btn-radius" href="' . $settings['btn_two_link']['url'] . '"' . $target . $nofollow . '>'.esc_html($settings['btn_two_text']).'</a>'; 
								} 
							?>    
                        </div>
                    </div>
                    <div class="col-lg-7 m-15px-tb"> 
						<?php if( $settings['img']['id'] ) { ?>
						<img src="<?php echo mombo_get_image_size_by_img_id($settings['img']['id'], 635, 465, true); ?>" alt="<?php echo esc_attr($settings['title']); ?>">
						<?php } ?>
                    </div>
                </div>
            </div>
        </section>
		<?php } else { ?>
		<section class="p-20px-b">
            <div class="container">
                <div class="owl-carousel" data-nav-dots="trust" data-items="1" data-md-items="1" data-sm-items="1" data-xs-items="1" data-xx-items="1" data-space="30">
					<?php foreach ( $settings['slider_items'] as $index => $item ) : ?>	
                    <div class="row align-items-center p-40px-tb justify-content-between <?php if(($index % 2) != 0) echo 'flex-row-reverse'; ?>">
                        <div class="col-lg-5 m-20px-tb">
                            <h1 class="m-20px-b"><?php echo esc_html($item['title']); ?></h1>
                            <p class="font-2"><?php echo wp_kses_post( $item['desc'] ); ?></p>
                            <div class="p-10px-t"> 
								<?php
								$target = $item['btn_link']['is_external'] ? ' target="_blank"' : '';
								$nofollow = $item['btn_link']['nofollow'] ? ' rel="nofollow"' : '';  
								if ( $item['btn_text'] ) {
									echo '<a class="m-btn m-btn-theme m-btn-radius" href="' . $item['btn_link']['url'] . '"' . $target . $nofollow . '>'.esc_html($item['btn_text']).' <i class="fas fa-arrow-right d-none d-md-inline m-10px-l"></i></a> '; 
								} 

								$target = $item['btn_two_link']['is_external'] ? ' target="_blank"' : '';
								$nofollow = $item['btn_two_link']['nofollow'] ? ' rel="nofollow"' : '';  
								if ( $item['btn_two_text'] ) {
									echo '<a class="m-btn m-btn-theme-light m-btn-radius" href="' . $item['btn_two_link']['url'] . '"' . $target . $nofollow . '>'.esc_html($item['btn_two_text']).'</a>'; 
								} 
							?>   
							</div> 
                        </div>
                        <div class="col-lg-6 m-20px-tb"> 
							<?php if( $item['img']['id'] ) { ?>
							<img src="<?php echo mombo_get_image_size_by_img_id($item['img']['id'], 540, 540, true); ?>" alt="<?php echo esc_attr($item['title']); ?>">
							<?php } ?>
                        </div>
					</div>
					<?php endforeach; ?> 
                </div>
            </div>
        </section>
		<?php } ?>
	<?php } 
}

Plugin::instance()->widgets_manager->register_widget_type( new Mombo_Header_Banner_Widget() );
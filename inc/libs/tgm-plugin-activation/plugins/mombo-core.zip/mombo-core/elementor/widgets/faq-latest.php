<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Mombo Faq_Latest Widget.
 *
 * Mombo widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0
 */

class Mombo_Faq_Latest_Widget extends Widget_Base {

	public function get_name() {
		return 'mombo-faq-latest';
	}

	public function get_title() {
		return esc_html__( 'Mombo: Faq Latest', 'mombo-core' );
	}

	public function get_icon() {
		return 'eicon-help-o';
	}

	public function get_categories() {
		return [ 'mombo-category' ];
	}

	/**
	 * Register Faq_Latest widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$faq_categories = [];

		$terms = get_terms('faq-category');
		foreach($terms as $term) {
			$faq_categories[$term->term_id] = $term->name;
		} 

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'mombo-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		); 

		$this->add_control(
			'number',
			[
				'label' => esc_html__( 'Total Faq', 'mombo-core' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 6,
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render Faq_Latest widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();  
		?> 
		<div class="m-15px-tb">
		<?php 
			$args = array(
				'posts_per_page' => $settings['number'],  
				'post_type' => 'faq', 
			);
			$the_query = new \WP_Query( $args ); 
			while ( $the_query->have_posts() ) : $the_query->the_post(); ?>  
			<div class="card m-15px-b box-shadow-only-hover transition">
				<div class="card-body p-15px-tb p-25px-lr">
					<div class="row justify-content-sm-between align-items-sm-center">
						<div class="col-sm-6 m-5px-tb">
							<i class="fas fa-pencil-alt m-10px-r theme-color"></i>
							<?php the_title(); ?>
						</div>
						<div class="col-sm-6 m-5px-tb text-sm-right dark-color">
							<i class="fas fa-user m-10px-r theme2nd-color"></i> 
							<?php echo esc_html( sprintf( _nx( '%s answer', '%s answers', get_comments_number(), 'comments title', 'mombo' ), number_format_i18n( get_comments_number() ) ) ); ?>
						</div>
					</div>
				</div>
				<a href="<?php the_permalink(); ?>" class="overlay-link"></a>
			</div> 
			<?php endwhile; wp_reset_postdata(); ?>
		</div> 
		<?php  
	}

}

Plugin::instance()->widgets_manager->register_widget_type( new Mombo_Faq_Latest_Widget() );
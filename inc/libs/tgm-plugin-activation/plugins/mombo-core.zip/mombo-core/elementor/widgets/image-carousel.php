<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Mombo Image_Carousel Widget.
 *
 * Mombo widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0
 */

class Mombo_Image_Carousel_Widget extends Widget_Base {

	public function get_name() {
		return 'mombo-image-carousel';
	}

	public function get_title() {
		return esc_html__( 'Mombo: Image Carousel', 'mombo-core' );
	}

	public function get_icon() {
		return 'eicon-slider-push';
	}

	public function get_categories() {
		return [ 'mombo-category' ];
	}

	/**
	 * Register Image_Carousel widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'mombo-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);  
		 
	 	$this->add_control(
	 		'items',
	 		[
	 			'label' => esc_html__( 'Items', 'mombo-core' ),
	 			'type' => Controls_Manager::REPEATER,
	 			'default' => [ 
	 			],
	 			'fields' => [  
					[
						'name' => 'img',
						'label'       => esc_html__( 'Image', 'mombo-core' ),
						'description'       => esc_html__( 'Image will only show in style two and three', 'mombo-core' ),
						'type' => Controls_Manager::MEDIA,
						'dynamic' => [
							'active' => true,
						],
						'default' => [
							'url' => Utils::get_placeholder_image_src(),
						], 
					],		
					[ 
						'name' => 'link',
						'label' => esc_html__( 'Link', 'mombo-core' ),
						'type' => Controls_Manager::URL,
						'placeholder' => esc_html__( 'https://your-link.com', 'mombo-core' ),
						'show_external' => true,
						'default' => [
							'url' => '#',
							'is_external' => true,
							'nofollow' => true,
						],
					],		 
	 			],
	 			// 'title_field' => '{{ link }}',
	 		]
		);
		 
		$this->add_control(
			'items_number',
			[
				'label' => esc_html__( 'Items Per Slide', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => '6', 
			]
		); 

		$this->end_controls_section();

	}

	/**
	 * Render Image_Carousel widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() { 
		$settings = $this->get_settings_for_display(); ?>  
		<div class="owl-carousel" data-items="<?php echo esc_attr( $settings['items_number'] ); ?>" data-md-items="<?php echo esc_attr( $settings['items_number'] ); ?>" data-sm-items="3" data-xs-items="3" data-xx-items="2" data-space="10" data-nav-dots="false" data-autoplay="ture">
			<?php foreach ( $settings['items'] as $item ) : 
				if ( $item['img']['id'] ) {
			?>
			<div class="grayscale-hover">
				<?php
					$target = $item['link']['is_external'] ? ' target="_blank"' : '';
					$nofollow = $item['link']['nofollow'] ? ' rel="nofollow"' : ''; 
					echo '<a href="' . $item['link']['url'] . '"' . $target . $nofollow . '>';
					
					echo wp_get_attachment_image( $item['img']['id'], 'large' ); ?>
				</a>
			</div> 
			<?php } endforeach; ?> 
		</div> 
		<?php  
	} 
}

Plugin::instance()->widgets_manager->register_widget_type( new Mombo_Image_Carousel_Widget() );
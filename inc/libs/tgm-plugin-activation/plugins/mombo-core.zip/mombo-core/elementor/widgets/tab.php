<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Mombo Tab Widget.
 *
 * Mombo widget that inserts an embeddable content into the page, from any given URL.
 *
 * @since 1.0
 */

class Mombo_Tab_Widget extends Widget_Base {

	public function get_name() {
		return 'mombo-tab';
	}

	public function get_title() {
		return esc_html__( 'Mombo: Tab', 'mombo-core' );
	}

	public function get_icon() {
		return 'eicon-tabs';
	}

	public function get_categories() {
		return [ 'mombo-category' ];
	}

	/**
	 * Register Tab widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'mombo-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'style',
			[
				'label' => esc_html__( 'Tab Style', 'mombo-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'one',
				'options' => [
					'one' => esc_html__( 'One', 'mombo-core' ),
					'two' => esc_html__( 'Two', 'mombo-core' ),  
					'three' => esc_html__( 'Three', 'mombo-core' ),  
					'four' => esc_html__( 'Four', 'mombo-core' ),  
					'five' => esc_html__( 'Five', 'mombo-core' ),  
				],
			]
		); 

		$this->add_control(
			'tab_items',
			[
				'label' => esc_html__( 'Tab Items', 'mombo-core' ),
				'type' => Controls_Manager::REPEATER, 
				'conditions' => [ 
					'terms' => [ 
						[
							'name' => 'style',
							'operator' => 'in',
							'value' => ['one', 'two'],
						],
					],
				], 
				'fields' => [  
					[
						'name' => 'tab_title',
						'label' => esc_html__( 'Tab Title', 'mombo-core' ),
						'type' => Controls_Manager::TEXT, 
						'default' => 'Discussion',
					],
					[
						'name' => 'icon_from',
						'label' => esc_html__( 'Tab Icon from', 'mombo-core' ),
						'type' => Controls_Manager::SELECT,
						'default' => 'library',
						'options' => [
							'library' => esc_html__( 'Library', 'mombo-core' ),
							'class' => esc_html__( 'Class', 'mombo-core' ),  
						], 
					],			
					[ 
						'name' => 'icon',
						'label' => esc_html__( 'Tab Icon', 'mombo-core' ),
						'type' => Controls_Manager::ICONS, 
						'default' => [
							'value' => 'fas fa-star',
							'library' => 'brand',
						],
						'conditions' => [ 
							'terms' => [ 
								[
									'name' => 'icon_from',
									'operator' => 'in',
									'value' => ['library'],
								],
							],
						],
					],  
					[
						'name' => 'icon_class',
						'label' => esc_html__( 'Tab Icon Class', 'mombo-core' ),
						'type' => Controls_Manager::TEXT,
						'default' => 'icon-desktop',
						'conditions' => [ 
							'terms' => [ 
								[
									'name' => 'icon_from',
									'operator' => 'in',
									'value' => ['class'],
								],
							],
						], 
					], 
					[
						'name' => 'title',
						'label' => esc_html__( 'Title', 'mombo-core' ),
						'type' => Controls_Manager::TEXT, 
						'default' => 'Welcome to Mombo <u class="theme-color">Digital Marketing</u>',
					],
					[
						'name' => 'img',
						'label'       => esc_html__( 'Image', 'mombo-core' ),
						'type' => Controls_Manager::MEDIA,
						'dynamic' => [
							'active' => true,
						],
						'default' => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
					[
						'name' => 'img_pos',
						'label' => esc_html__( 'Image Position', 'mombo-core' ),
						'type' => Controls_Manager::SELECT,
						'default' => 'left',
						'options' => [
							'left' => esc_html__( 'Left', 'mombo-core' ),
							'right' => esc_html__( 'Right', 'mombo-core' ),  
						],
					],
					[
						'name' => 'desc',
						'label'       => esc_html__( 'Description', 'mombo-core' ),
						'type'        => Controls_Manager::WYSIWYG,
						'dynamic'     => [ 'active' => true ], 
							'default'     => '<p class="m-5px-b">Mombo is a WordPress Theme based on Sass and Bootstrap 4 with modern and creative multipurpose design you can use it as a startups. Ut enim ad minim veniam.</p><div class="row">
							<div class="col-md-6 m-15px-tb">
								<h5 class="theme-color h6 m-10px-b">Mobile Friendly</h5>
								<p class="m-0px">Lorem ipsum dolor sit amet, consectetur adipisicing.</p>
							</div>
							<!-- col -->
							<div class="col-md-6 m-15px-tb">
								<h5 class="theme-color h6 m-10px-b">Multiple Layouts</h5>
								<p class="m-0px">Lorem ipsum dolor sit amet, consectetur adipisicing.</p>
							</div>
							<!-- col -->
						</div>',
					],  
					[
						'name' => 'desc_three',
						'label'       => esc_html__( 'Description tab style three', 'mombo-core' ),
						'description' => esc_html__( 'Description for tab style three', 'mombo-core' ),
						'type'        => Controls_Manager::WYSIWYG,
						'dynamic'     => [ 'active' => true ],  
						'default'     => '<p class="m-25px-b">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut.</p>
						<div class="media m-30px-b">
							<div class="icon-60 dots-icon border-radius-5 border-color-theme border-all-1 theme-color">
								<i class="icon-desktop"></i>
								<span class="dots"><i class="dot dot1"></i><i class="dot dot2"></i><i class="dot dot3"></i></span>
							</div>
							<div class="media-body p-20px-l">
								<h6>Web Development</h6>
								<p class="m-0px">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.</p>
							</div>
						</div>
						<div class="media">
							<div class="icon-60 dots-icon border-radius-5 border-color-theme border-all-1 theme-color">
								<i class="icon-tools"></i>
								<span class="dots"><i class="dot dot1"></i><i class="dot dot2"></i><i class="dot dot3"></i></span>
							</div>
							<div class="media-body p-20px-l">
								<h6>Logo & Identity</h6>
								<p class="m-0px">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.</p>
							</div>
						</div>',
					],  
				    [
					   'name' => 'btn_label',
					   'label' => esc_html__( 'Button Text', 'mombo-core' ),
					   'type' => Controls_Manager::TEXT, 
					   'default' => 'More About',
				    ],
				    [ 
					   'name' => 'btn_link',
					   'label' => esc_html__( 'Button Link', 'mombo-core' ),
					   'type' => Controls_Manager::URL,
					   'placeholder' => esc_html__( 'https://your-link.com', 'mombo-core' ),
					   'show_external' => true,
					   'default' => [
						   'url' => '#',
						   'is_external' => true,
						   'nofollow' => true,
					    ],
				    ],
				],
				'title_field' => ' {{{ tab_title }}}',
			]
		); 
		
		$this->add_control(
			'tab_three_items',
			[
				'label' => esc_html__( 'Tab Items', 'mombo-core' ),
				'type' => Controls_Manager::REPEATER, 
				'conditions' => [ 
					'terms' => [ 
						[
							'name' => 'style',
							'operator' => 'in',
							'value' => ['three'],
						],
					],
				], 
				'fields' => [  
					[
						'name' => 'tab_title',
						'label' => esc_html__( 'Tab Title', 'mombo-core' ),
						'type' => Controls_Manager::TEXT, 
						'default' => 'Discussion',
					],
					[
						'name' => 'icon_from',
						'label' => esc_html__( 'Tab Icon from', 'mombo-core' ),
						'type' => Controls_Manager::SELECT,
						'default' => 'library',
						'options' => [
							'library' => esc_html__( 'Library', 'mombo-core' ),
							'class' => esc_html__( 'Class', 'mombo-core' ),  
						], 
					],			
					[ 
						'name' => 'icon',
						'label' => esc_html__( 'Tab Icon', 'mombo-core' ),
						'type' => Controls_Manager::ICONS, 
						'default' => [
							'value' => 'fas fa-star',
							'library' => 'brand',
						],
						'conditions' => [ 
							'terms' => [ 
								[
									'name' => 'icon_from',
									'operator' => 'in',
									'value' => ['library'],
								],
							],
						],
					],  
					[
						'name' => 'icon_class',
						'label' => esc_html__( 'Tab Icon Class', 'mombo-core' ),
						'type' => Controls_Manager::TEXT,
						'default' => 'icon-desktop',
						'conditions' => [ 
							'terms' => [ 
								[
									'name' => 'icon_from',
									'operator' => 'in',
									'value' => ['class'],
								],
							],
						], 
					], 
					[
						'name' => 'title',
						'label' => esc_html__( 'Title', 'mombo-core' ),
						'type' => Controls_Manager::TEXT, 
						'default' => 'Welcome to Mombo Digital Marketing',
					],
					[
						'name' => 'img',
						'label'       => esc_html__( 'Image', 'mombo-core' ),
						'type' => Controls_Manager::MEDIA,
						'dynamic' => [
							'active' => true,
						],
						'default' => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
					[
						'name' => 'img_pos',
						'label' => esc_html__( 'Image Position', 'mombo-core' ),
						'type' => Controls_Manager::SELECT,
						'default' => 'left',
						'options' => [
							'left' => esc_html__( 'Left', 'mombo-core' ),
							'right' => esc_html__( 'Right', 'mombo-core' ),  
						],
					], 
					[
						'name' => 'desc',
						'label'       => esc_html__( 'Description', 'mombo-core' ),
						'type'        => Controls_Manager::WYSIWYG,
						'dynamic'     => [ 'active' => true ],  
						'default'     => '<p class="m-25px-b">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut.</p>
						<div class="media m-30px-b">
							<div class="icon-60 dots-icon border-radius-5 border-color-theme border-all-1 theme-color">
								<i class="icon-desktop"></i>
								<span class="dots"><i class="dot dot1"></i><i class="dot dot2"></i><i class="dot dot3"></i></span>
							</div>
							<div class="media-body p-20px-l">
								<h6>Web Development</h6>
								<p class="m-0px">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.</p>
							</div>
						</div>
						<div class="media">
							<div class="icon-60 dots-icon border-radius-5 border-color-theme border-all-1 theme-color">
								<i class="icon-tools"></i>
								<span class="dots"><i class="dot dot1"></i><i class="dot dot2"></i><i class="dot dot3"></i></span>
							</div>
							<div class="media-body p-20px-l">
								<h6>Logo & Identity</h6>
								<p class="m-0px">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.</p>
							</div>
						</div>',
					],   
				],
				'title_field' => ' {{{ tab_title }}}',
			]
		); 
		
		$this->add_control(
			'tab_four_items',
			[
				'label' => esc_html__( 'Tab Items', 'mombo-core' ),
				'type' => Controls_Manager::REPEATER, 
				'conditions' => [ 
					'terms' => [ 
						[
							'name' => 'style',
							'operator' => 'in',
							'value' => ['four'],
						],
					],
				], 
				'fields' => [  
					[
						'name' => 'tab_title',
						'label' => esc_html__( 'Tab Title', 'mombo-core' ),
						'type' => Controls_Manager::TEXT, 
						'default' => 'Discussion',
					], 
					[
						'name' => 'title_top',
						'label' => esc_html__( 'Title Top', 'mombo-core' ),
						'type' => Controls_Manager::TEXT, 
						'default' => 'Our Portal',
					],
					[
						'name' => 'title',
						'label' => esc_html__( 'Title', 'mombo-core' ),
						'type' => Controls_Manager::TEXT, 
						'default' => 'Set your priorities and align your teams',
					],
					[
						'name' => 'img',
						'label'       => esc_html__( 'Image', 'mombo-core' ),
						'type' => Controls_Manager::MEDIA,
						'dynamic' => [
							'active' => true,
						],
						'default' => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
					[
						'name' => 'img_pos',
						'label' => esc_html__( 'Image Position', 'mombo-core' ),
						'type' => Controls_Manager::SELECT,
						'default' => 'left',
						'options' => [
							'left' => esc_html__( 'Left', 'mombo-core' ),
							'right' => esc_html__( 'Right', 'mombo-core' ),  
						],
					], 
					[
						'name' => 'desc',
						'label'       => esc_html__( 'Description', 'mombo-core' ),
						'type'        => Controls_Manager::WYSIWYG,
						'dynamic'     => [ 'active' => true ],  
						'default'     => '<p class="font-2">Mombo is a HTML5 template based on Sass and Bootstrap 4 with modern and creative</p>
						<ul class="list-type-02 theme">
							<li><i class="fas fa-check"></i>Built with customization</li>
							<li><i class="fas fa-check"></i>Quality design and thoughfully</li>
							<li><i class="fas fa-check"></i>Created with the latest technologies</li>
						</ul>',
					],   
				],
				'title_field' => ' {{{ tab_title }}}',
			]
		);  
		
		$this->add_control(
			'tab_five_items',
			[
				'label' => esc_html__( 'Tab Items', 'mombo-core' ),
				'type' => Controls_Manager::REPEATER, 
				'conditions' => [ 
					'terms' => [ 
						[
							'name' => 'style',
							'operator' => 'in',
							'value' => ['five'],
						],
					],
				], 
				'fields' => [   
					[
						'name' => 'tab_title',
						'label' => esc_html__( 'Tab Title', 'mombo-core' ),
						'type' => Controls_Manager::TEXT, 
						'default' => 'Friendly',
					], 
					[
						'name' => 'desc',
						'label'       => esc_html__( 'Description', 'mombo-core' ),
						'type'        => Controls_Manager::WYSIWYG,
						'dynamic'     => [ 'active' => true ],  
						'default'     => '<p>Mombo is a HTML5 template based on Sass and Bootstrap 4 with modern and creative multipurpose design you can use it as a startups.</p>
						<p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>',
					],   
				],
				'title_field' => ' {{{ tab_title }}}',
			]
	    );  

		$this->end_controls_section(); 

	}

	/**
	 * Render Tab widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() { 
		$settings = $this->get_settings_for_display(); 

		$tab_style = '1';
		switch ( $settings['style'] ) {
			case 'one':
				$tab_style = '1';
				break;
			
			case 'two':
				$tab_style = '3';
				break; 

			case 'three':
				$tab_style = '4';
				break; 
		}
		$tab_items = ( $settings['style'] == 'three' ) ? $settings['tab_three_items'] : $settings['tab_items'];

		if ( $settings['style'] == 'one' || $settings['style'] == 'two' || $settings['style'] == 'three') {
		?> 
		<div class="tab-style-<?php echo esc_attr($tab_style); ?>">
			<ul class="nav nav-fill nav-tabs">
				<?php foreach( $tab_items as $key => $item ): 
					$icon_class = '';
					if ( $item['icon_from'] == 'library' ) {
						$icon_class = $item['icon']['value'];
					} else {
						$icon_class = $item['icon_class'];
					}  
				?>
				<li class="nav-item">
					<a href="#about-tab-<?php echo esc_attr( $this->get_id().$key ); ?>" data-toggle="tab" class="<?php if ( $key == 0 ) echo 'active'; ?>">
						<div class="icon"><i class="<?php echo esc_attr( $icon_class ); ?>"></i></div>
						<span><?php echo esc_html( $item['tab_title'] ); ?></span>
					</a>
				</li> 
				<?php endforeach; ?>
			</ul>
			<div class="tab-content">
				<?php foreach( $tab_items as $key => $item ): ?>
				<!-- start tab content -->
				<div id="about-tab-<?php echo esc_attr( $this->get_id().$key ); ?>" class="tab-pane fade in <?php if ( $key == 0 ) echo 'active show'; ?>">
					<div class="row align-items-center p-25px-t md-p-15px-t">
						<?php if( $item['img_pos'] == 'left' ) { ?>
						<div class="col-lg-6 text-center">
							<?php if( $item['img']['id'] ) {
								echo wp_get_attachment_image( $item['img']['id'], 'full' );
							} ?>
						</div>
						<?php } ?>
						<div class="col-lg-6">
							<div class="p-70px-l lg-p-0px-l lg-m-30px-t">
								<h2 class="<?php echo ( $settings['style'] == 'three' ) ? 'h2 m-15px-b' :'h1 m-25px-b';?>"><?php echo wp_kses_post( $item['title'] ); ?></h2>
								<?php echo wp_kses_post( $item['desc'] ); ?>
								
								<?php 
								if ( $settings['style'] != 'three' && $item['btn_label'] ) {
									echo '<div class="btn-bar p-15px-t">';
									$target = $item['btn_link']['is_external'] ? ' target="_blank"' : '';
									$nofollow = $item['btn_link']['nofollow'] ? ' rel="nofollow"' : '';  
									echo '<a class="m-btn m-btn-radius m-btn-theme" href="' . $item['btn_link']['url'] . '"' . $target . $nofollow . '>'.esc_html($item['btn_label']).'</a></div>';
								}
								?> 
							</div>
						</div>
						<?php if( $item['img_pos'] == 'right' ) { ?>
						<div class="col-lg-6 order-lg-2 order-first text-center">
							<?php if( $item['img']['id'] ) {
								echo wp_get_attachment_image( $item['img']['id'], 'full' );
							} ?>
						</div>
						<?php } ?>
					</div>
				</div>
				<!-- end tab content -->
				<?php endforeach; ?>
			</div>
		</div> 
		<?php } elseif ( $settings['style'] == 'four' ) { ?>
		<div class="tab-style-5">
			<div class="row justify-content-center m-35px-b">
				<div class="col-lg-10">
					<ul class="nav nav-fill nav-tabs">
						<?php foreach( $settings['tab_four_items'] as $key => $item ):  ?>
						<li class="nav-item">
							<a href="#about-tab-<?php echo esc_attr( $this->get_id().$key ); ?>" data-toggle="tab" class="nav-link box-shadow-lg <?php if ( $key == 0 ) echo 'active'; ?>"> 
								<span><?php echo esc_html( $item['tab_title'] ); ?></span>
							</a>
						</li> 
						<?php endforeach; ?> 
					</ul>
				</div>
			</div>
			<div class="tab-content">
				<?php foreach( $settings['tab_four_items'] as $key => $item ): ?>
				<!-- start tab content -->
				<div id="about-tab-<?php echo esc_attr( $this->get_id().$key ); ?>" class="tab-pane fade in <?php if ( $key == 0 ) echo 'active show'; ?>">
					<div class="row <?php if( $item['img_pos'] == 'left' ) echo 'flex-row-reverse'; ?> align-items-center justify-content-between">
						<div class="col-lg-5 m-15px-tb">
							<?php if( $item['title_top'] ) { ?>
							<label class="theme-bg-alt font-small font-w-500 p-20px-lr p-5px-tb theme-color border-radius-15 m-15px-b"><?php echo esc_html($item['title_top']); ?></label>
							<?php } ?>
							<h3><?php echo wp_kses_post( $item['title'] ); ?></h3>
							<?php echo wp_kses_post( $item['desc'] ); ?>
						</div>
						<div class="col-lg-6 m-15px-tb"> 
							<?php if( $item['img']['id'] ) { ?>
							<img src="<?php echo mombo_get_image_size_by_img_id($item['img']['id'], 720, 696, true); ?>" alt="<?php echo esc_attr($item['tab_title']); ?>">
							<?php } ?>
						</div>
					</div>
				</div>
				<!-- end tab content -->
				<?php endforeach; ?>  
			</div>
		</div>
		<?php } elseif ( $settings['style'] == 'five' ) { ?>
		<div class="tab-style-2 dark p-15px-t">
			<ul class="nav" id="pills-tab" role="tablist">
				<?php foreach( $settings['tab_five_items'] as $key => $item ): ?>
				<li class="nav-item">
					<a class="nav-link <?php if ( $key == 0 ) echo 'active'; ?>" id="about-tab-<?php echo esc_attr( $this->get_id().$key ); ?>-tab" data-toggle="pill" href="#about-tab-<?php echo esc_attr( $this->get_id().$key ); ?>" role="tab" aria-controls="about-tab-<?php echo esc_attr( $this->get_id().$key ); ?>" aria-selected="false">
					<?php echo esc_html( $item['tab_title'] ); ?>
					</a>
				</li>
				<?php endforeach; ?>   
			</ul>
			<div class="tab-content" id="pills-tabContent">
				<?php foreach( $settings['tab_five_items'] as $key => $item ): ?>
				<div class="tab-pane fade  <?php if ( $key == 0 ) echo 'show active'; ?>" id="about-tab-<?php echo esc_attr( $this->get_id().$key ); ?>" role="tabpanel" aria-labelledby="about-tab-<?php echo esc_attr( $this->get_id().$key ); ?>-tab">
					<?php echo wp_kses_post( $item['desc'] ); ?>
				</div>
				<?php endforeach; ?>   
			</div>
		</div>
		<?php } ?>
	<?php } 
}

Plugin::instance()->widgets_manager->register_widget_type( new Mombo_Tab_Widget() );
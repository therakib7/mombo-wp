<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Mombo Assistance Widget.
 *
 * Mombo widget that inserts an embeddable content into the page, from any given URL.
 *
 * @since 1.0
 */

class Mombo_Assistance_Widget extends Widget_Base {

	public function get_name() {
		return 'mombo-assistance';
	}

	public function get_title() {
		return esc_html__( 'Mombo: Assistance', 'mombo-core' );
	}

	public function get_icon() {
		return 'eicon-help-o';
	}

	public function get_categories() {
		return [ 'mombo-category' ];
	}

	/**
	 * Register Assistance widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'mombo-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		); 
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'We can help!',
			]
		); 
		$this->add_control(
			'desc',
			[
				'label'       => esc_html__( 'Description', 'mombo-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [ 'active' => true ], 
				'default'     => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque',
			]
		); 
		$this->add_control(
			'btn_text',
			[
				'label' => esc_html__( 'Button Text', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'Submit Query',
			]
		); 
		$this->add_control(
			'btn_link',
			[ 
				'label' => esc_html__( 'Button Link', 'mombo-core' ),
				'type' => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'mombo-core' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			],
		);  
		$this->add_control(
			'is_highlight',
			[
				'label' => esc_html__( 'Is Highlight?', 'mombo-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'mombo-core' ),
				'label_off' => esc_html__( 'No', 'mombo-core' ),
				'return_value' => 'yes',
				'default' => '', 
			]
		);
		$this->end_controls_section(); 
 
	}

	/**
	 * Render Assistance widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() { 
		$settings = $this->get_settings_for_display(); ?>  
		 

		<div class="card <?php echo ( $settings['is_highlight'] == 'yes' ) ? 'theme-bg' : 'white-bg'; ?>">
			<div class="card-body p-25px">
				<h4 class="m-10px-b h5 <?php echo ( $settings['is_highlight'] == 'yes' ) ? 'white-color' : ''; ?>">
				<?php echo esc_html($settings['title']); ?>
				</h4>
				<p class="<?php echo ( $settings['is_highlight'] == 'yes' ) ? 'white-color-light' : ''; ?>"><?php echo wp_kses_post( $settings['desc'] ); ?></p>
				<?php
				$target = $settings['btn_link']['is_external'] ? ' target="_blank"' : '';
				$nofollow = $settings['btn_link']['nofollow'] ? ' rel="nofollow"' : '';  
				$is_highlight = ( $settings['is_highlight'] == 'yes' ) ? 't-white' : 'theme';
				echo '<a class="m-btn-wide m-btn m-btn-radius m-btn-'.$is_highlight.' m-btn-radius" href="' . $settings['btn_link']['url'] . '"' . $target . $nofollow . '>'.esc_html($settings['btn_text']).'</a>';
				?>  
			</div>
		</div> 
	<?php } 
}

Plugin::instance()->widgets_manager->register_widget_type( new Mombo_Assistance_Widget() );
<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Mombo Menu_List Widget.
 *
 * Mombo widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0
 */

class Mombo_Menu_List_Widget extends Widget_Base {

	public function get_name() {
		return 'mombo-menu-list';
	}

	public function get_title() {
		return esc_html__( 'Mombo: Menu List', 'mombo-core' );
	}

	public function get_icon() {
		return 'eicon-anchor';
	}

	public function get_categories() {
		return [ 'mombo-category' ];
	}

	/**
	 * Register Menu_List widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'mombo-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[ 
				'label' => esc_html__( 'Title', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,  
			], 
		);  
	 	$this->add_control(
	 		'menu_lists',
	 		[
	 			'label' => esc_html__( 'Menu Lists', 'mombo-core' ),
	 			'type' => Controls_Manager::REPEATER, 
	 			'fields' => [  
					[
						'name' => 'menu_label',
						'label' => esc_html__( 'Label', 'mombo-core' ),
						'type' => Controls_Manager::TEXT, 
						'default' => '',
					],
					[ 
						'name' => 'link',
						'label' => esc_html__( 'Link', 'mombo-core' ),
						'type' => Controls_Manager::URL,
						'placeholder' => esc_html__( 'https://your-link.com', 'mombo-core' ),
						'show_external' => true,
						'default' => [
							'url' => '#',
							'is_external' => true,
							'nofollow' => true,
						],
					],
	 			],
	 			'title_field' => ' {{{ menu_label }}}',
	 		]
		); 

		$this->add_control(
			'menu_color',
			[
				'label' => esc_html__( 'Menu Color', 'mombo-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'dark',
				'options' => [
					'dark' => esc_html__( 'Dark', 'mombo-core' ),
					'light' => esc_html__( 'Light', 'mombo-core' ),  
				],
			]
		); 
		 
		$this->end_controls_section();

	}

	/**
	 * Render Menu_List widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() { 
		$settings = $this->get_settings_for_display(); ?> 
		<?php if ( $settings['title'] ) { ?> 
			<h6 class="<?php if ($settings['menu_color'] == 'light') echo 'white-color'; ?>">
				<?php echo esc_html($settings['title']); ?>
			</h6>
		<?php } ?>
		<div class="footer">
			<ul class="list-unstyled <?php echo ($settings['menu_color'] == 'light') ? 'links-white' : 'links-dark'; ?> footer-link-1">
				<?php foreach ( $settings['menu_lists'] as $item ) : ?>
				<li> 
					<?php
						$target = $item['link']['is_external'] ? ' target="_blank"' : '';
						$nofollow = $item['link']['nofollow'] ? ' rel="nofollow"' : '';  
						echo '<a href="' . $item['link']['url'] . '"' . $target . $nofollow . '>'.esc_html($item['menu_label']).'</a>';
					?> 
				</li> 
				<?php endforeach; ?>
			</ul>
		</div> 
		<?php 
	} 
}

Plugin::instance()->widgets_manager->register_widget_type( new Mombo_Menu_List_Widget() );
<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Mombo Testimonial Widget.
 *
 * Mombo widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0
 */

class Mombo_Testimonial_Widget extends Widget_Base {

	public function get_name() {
		return 'mombo-testimonial';
	}

	public function get_title() {
		return esc_html__( 'Mombo: Testimonial', 'mombo-core' );
	}

	public function get_icon() {
		return 'eicon-testimonial';
	}

	public function get_categories() {
		return [ 'mombo-category' ];
	}

	/**
	 * Register Testimonial widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'mombo-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'style',
			[
				'label' => esc_html__( 'Testimonial Style', 'mombo-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'one',
				'options' => [
					'one' => esc_html__( 'One', 'mombo-core' ),
					'two' => esc_html__( 'Two', 'mombo-core' ),  
					'three' => esc_html__( 'Three', 'mombo-core' ),  
				],
			]
		);  
	 	$this->add_control(
	 		'testimonials',
	 		[
	 			'label' => esc_html__( 'Testimonials', 'mombo-core' ),
	 			'type' => Controls_Manager::REPEATER,
	 			'default' => [
	 				[
	 					'name' => 'Zohan Smith',
	 					'position' => 'Chif Dighal Officer',
	 					'testimonial' => "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.",
					], 
					[
						'name' => 'Nancy Bayers',
						'position' => 'Co Founder',
						'testimonial' => "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.",
					], 
					[
						'name' => 'Rakib Hasan',
						'position' => 'Co Founder',
						'testimonial' => "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.",
					], 
					[
						'name' => 'Zohan Smith',
						'position' => 'Chif Dighal Officer',
						'testimonial' => "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.",
				   	], 
	 			],
	 			'fields' => [ 
	 				[
	 					'name' => 'name',
	 					'label' => esc_html__( 'Name', 'mombo-core' ),
	 					'type' => Controls_Manager::TEXT,
	 					'label_block' => true, 
	 					'default' => 'Zohan Smith',
	 				],  
	 				[
	 					'name' => 'position',
	 					'label' => esc_html__( 'Position', 'mombo-core' ),
	 					'type' => Controls_Manager::TEXT,
	 					'label_block' => true, 
	 					'default' => 'Chif Dighal Officer',
					],
					[
						'name' => 'img',
						'label'       => esc_html__( 'Image', 'mombo-core' ),
						'description'       => esc_html__( 'Image will only show in style two and three', 'mombo-core' ),
						'type' => Controls_Manager::MEDIA,
						'dynamic' => [
							'active' => true,
						],
						'default' => [
							'url' => Utils::get_placeholder_image_src(),
						], 
					],					 
	 				[
	 					'name' => 'testimonial',
	 					'label' => esc_html__( 'Testimonial', 'mombo-core' ),
	 					'type' => Controls_Manager::WYSIWYG,
	 					'dynamic' => [
	 						'active' => true,
	 					],
	 					'default' => "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.",
	 				],
	 			],
	 			'title_field' => ' {{{ name }}} -- {{ position }}',
	 		]
	 	);

		$this->end_controls_section();

	}

	/**
	 * Render Testimonial widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() { 
		$settings = $this->get_settings_for_display(); 

		if ( $settings['style'] == 'one' ) { ?> 
		<div class="owl-carousel" data-items="3" data-nav-dots="true" data-md-items="3" data-sm-items="2" data-xs-items="1" data-xx-items="1" data-space="30">
			<?php foreach ( $settings['testimonials'] as $item ) : ?>
			<div class="border-all-1 border-color-dark-gray text-center m-25px-t m-20px-b white-bg">
				<div class="icon-60 border-radius-50 theme2nd-bg white-color d-inline-block mt-n5">
					<i class="fas fa-quote-left"></i>
				</div>
				<div class="p-25px">
					<p><?php if(isset($item['testimonial'])) echo wp_kses_post($item['testimonial']); ?></p>
					<h5 class="h6 m-0px"><?php if(isset($item['name'])) echo esc_html($item['name']); ?></h5>
					<label class="font-w-600 font-small m-0px"><?php if(isset($item['position'])) echo esc_html($item['position']); ?></label>
				</div>
			</div> 
			<?php endforeach; ?> 
		</div>
		<?php } elseif ( $settings['style'] == 'two' ) { ?>
		<div class="owl-carousel" data-items="2" data-nav-dots="true" data-md-items="2" data-sm-items="2" data-xs-items="2" data-xx-items="1" data-space="0">
			<?php foreach ( $settings['testimonials'] as $item ) : ?>
			<div class="box-shadow m-10px overflow-hidden border-radius-5">
				<div class="d-flex align-items-center h-100 min-h-150px bg-cover bg-no-repeat position-relative" style="background-image: url(<?php echo mombo_get_image_size_by_img_id($item['img']['id'], 250, 155, true); ?>);">
					<div class="mask theme-bg opacity-5"></div>
					<div class="position-relative w-100 text-center">
						<h5 class="white-color m-0px font-w-600"><?php if(isset($item['name'])) echo esc_html($item['name']); ?></h5>
						<label class="m-0px font-small white-color"><?php if(isset($item['position'])) echo esc_html($item['position']); ?></label>
					</div>
				</div>
				<div class="mt-n4 p-20px-lr p-30px-b position-relative text-center">
					<div class="icon-50 theme2nd-bg border-radius-50 d-inline-block white-color m-15px-b"><i class="fas fa-quote-left"></i></div>
					<p class="m-0px"><?php if(isset($item['testimonial'])) echo wp_kses_post($item['testimonial']); ?></p>
				</div>
			</div> 
			<?php endforeach; ?> 
		</div>
		<?php } else { ?>
		<div class="owl-carousel" 
                    data-nav-dots="true" 
                    data-items="3" 
                    data-md-items="2" 
                    data-sm-items="2" 
                    data-xs-items="2" 
                    data-xx-items="1"
					data-space="0">
			<?php foreach ( $settings['testimonials'] as $item ) : ?>
			<div class="box-shadow overflow-hidden border-radius-5 white-bg text-center p-25px-lr p-45px-tb m-15px hover-top">
				<?php if( $item['img']['id'] ) { ?>
				<div class="avatar-100 d-inline-block border-radius-50"> 
					<img src="<?php echo mombo_get_image_size_by_img_id($item['img']['id'], 100, 100, true); ?>" alt="<?php echo esc_attr($item['name']); ?>">
				</div>
				<?php } ?>
				<div class="mt-n3 position-relative text-center">
					<div class="icon-50 theme2nd-bg border-radius-50 d-inline-block white-color m-15px-b"><i class="fas fa-quote-left"></i></div>
					<p><?php if(isset($item['testimonial'])) echo wp_kses_post($item['testimonial']); ?></p>
					<h5 class="h6 m-0px"><?php if(isset($item['name'])) echo esc_html($item['name']); ?></h5>
					<label class="font-w-600 font-small m-0px"><?php if(isset($item['position'])) echo esc_html($item['position']); ?></label>
				</div>
			</div> 
			<?php endforeach; ?> 
		</div>
		<?php 
		}
	} 
}

Plugin::instance()->widgets_manager->register_widget_type( new Mombo_Testimonial_Widget() );
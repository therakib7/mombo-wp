<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Mombo Video_Popup Widget.
 *
 * Mombo widget that inserts an embeddable content into the page, from any given URL.
 *
 * @since 1.0
 */

class Mombo_Video_Popup_Widget extends Widget_Base {

	public function get_name() {
		return 'mombo-counter';
	}

	public function get_title() {
		return esc_html__( 'Mombo: Video Popup', 'mombo-core' );
	}

	public function get_icon() {
		return 'eicon-youtube';
	}

	public function get_categories() {
		return [ 'mombo-category' ];
	}

	/**
	 * Register Video_Popup widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'mombo-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		); 

		$this->add_control(
			'img',
			[
				'label'       => esc_html__( 'Image', 'mombo-core' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		
		$this->add_control(
			'video_url',
			[
				'label' => esc_html__( 'Video URL', 'mombo-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => '', 
			]
		);  
		$this->end_controls_section(); 

	}

	/**
	 * Render Video_Popup widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() { 
		$settings = $this->get_settings_for_display(); ?>   
		<div class="video-box">
			<?php if( $settings['img']['id'] ) { ?>
				<img class="box-shadow border-radius-5" src="<?php echo mombo_get_image_size_by_img_id($settings['img']['id'], 540, 360, true); ?>">
				<?php } ?> 
			<a class="video-btn white popup-youtube p-center" href="<?php echo esc_attr( $settings['video_url'] ); ?>"><span></span></a>
		</div>
	<?php } 
}

Plugin::instance()->widgets_manager->register_widget_type( new Mombo_Video_Popup_Widget() );
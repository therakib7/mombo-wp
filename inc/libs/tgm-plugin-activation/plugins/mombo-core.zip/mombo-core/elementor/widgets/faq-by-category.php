<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Mombo Faq_By_Category Widget.
 *
 * Mombo widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0
 */

class Mombo_Faq_By_Category_Widget extends Widget_Base {

	public function get_name() {
		return 'mombo-faq-by-cateogry';
	}

	public function get_title() {
		return esc_html__( 'Mombo: Faq By Category', 'mombo-core' );
	}

	public function get_icon() {
		return 'eicon-help-o';
	}

	public function get_categories() {
		return [ 'mombo-category' ];
	}

	/**
	 * Register Faq_By_Category widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$faq_categories = [];

		$terms = get_terms('faq-category');
		foreach($terms as $term) {
			$faq_categories[$term->term_id] = $term->name;
		} 

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'mombo-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'style',
			[
				'label' => esc_html__( 'Faq Style', 'mombo-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'simple',
				'options' => [
					'simple' => esc_html__( 'Simple', 'mombo-core' ),
					'advance' => esc_html__( 'Advance', 'mombo-core' ),  
				],
			]
		); 

		$this->add_control(
			'category',
			[
				'label' => esc_html__( 'Choose Category', 'mombo-core' ),
				'type' => Controls_Manager::SELECT, 
				'options' => $faq_categories,
				'condition' => [
					'style' => ['simple'], 
                ],
			]
		); 

		$this->add_control(
			'category_lists',
			[
				'label' => esc_html__( 'Category Lists', 'mombo-core' ),
				'type' => Controls_Manager::REPEATER, 
				'condition' => [
					'style' => ['advance'], 
                ],
				'fields' => [  
				    [
					   'name' => 'sec_title',
					   'label' => esc_html__( 'Section Title', 'mombo-core' ),
					   'type' => Controls_Manager::TEXT, 
					   'default' => 'Our Basic Helps!',
				    ],
				    [
						'name' => 'cat_id',
						'label' => esc_html__( 'Choose Category', 'mombo-core' ),
						'type' => Controls_Manager::SELECT,  
						'options' => $faq_categories, 
					]
				],
				'title_field' => ' {{ sec_title }}',
			]
	    ); 

		$this->add_control(
			'number',
			[
				'label' => esc_html__( 'Total Faq', 'mombo-core' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 6,
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render Faq_By_Category widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();  
		if( $settings['style'] == 'simple' ) { ?> 
		<div class="row">
			<?php 
			$args = array(
				'posts_per_page' => $settings['number'],  
				'post_type' => 'faq',
				'tax_query' => array(
					array(
						'taxonomy' => 'faq-category',   
						'field' => 'term_id',          
						'terms' => $settings['category'],                  
					)
				)
			);
			$the_query = new \WP_Query( $args ); 
			while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
			<div class="col-lg-6">
				<div class="media box-shadow p-15px white-bg border-radius-5 align-items-center m-25px-b">
					<div class="icon-30 border-radius-50 theme-bg-alt theme-color">
						<i class="fas fa-check"></i>
					</div>
					<div class="p-15px-l media-body">
						<h6 class="font-w-600 m-0px"><a href="<?php the_permalink(); ?>" class="body-color"><?php the_title(); ?></a></h6>
					</div>
				</div>  
			</div>  
			<?php endwhile; wp_reset_postdata(); ?>
		</div> 
		<?php } else { ?>
			<div class="row align-items-start">
				<div class="col-lg-3 go-to sticky-lg-top">
					<div class="card m-40px-b">
						<div class="list-group list-group-flush box-shadow">
							<?php foreach( $settings['category_lists'] as $key => $item ): ?>
							<a href="#faq-cat<?php echo esc_attr($key); ?>" class="nav-link list-group-item list-group-item-action d-flex justify-content-between p15px-tb">
								<div>
									<i class="ti-help m-10px-r"></i>
									<span><?php echo get_term_by('id', $item['cat_id'], 'faq-category')->name; ?></span>
								</div>
								<div>
									<i class="ti-angle-right"></i>
								</div>
							</a> 
							<?php endforeach; ?>
						</div>
					</div>
				</div>
				<div class="col-lg-8 ml-lg-auto">
					<?php foreach( $settings['category_lists'] as $key => $item ): ?>
					<h3 id="faq-cat<?php echo esc_attr($key); ?>" class="m-20px-b"><?php echo esc_html($item['sec_title']); ?></h3>
					<div class="accordion accordion-05 m-40px-b">
						<?php 
						$args = array(
							'posts_per_page' => $settings['number'],  
							'post_type' => 'faq',
							'tax_query' => array(
								array(
									'taxonomy' => 'faq-category',   
									'field' => 'term_id',          
									'terms' => $item['cat_id'],                  
								)
							)
						);
						$the_query = new \WP_Query( $args ); 
						while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
						<div class="acco-group white-bg">
							<a href="#" class="acco-heading"><?php the_title(); ?></a>
							<div class="acco-des">
								<?php echo mombo_content_limit_with_read_more(40, ' <a href="'.get_the_permalink().'">'.esc_html__( 'Read More ...', 'mombo' ).'</a>'); ?> 
							</div>
						</div> 
						<?php endwhile; wp_reset_postdata(); ?>
					</div>
					<?php endforeach; ?>
				</div>
			</div>
		<?php  
		}
	}

}

Plugin::instance()->widgets_manager->register_widget_type( new Mombo_Faq_By_Category_Widget() );
<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Mombo Job_List Widget.
 *
 * Mombo widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0
 */

class Mombo_Job_List_Widget extends Widget_Base {

	public function get_name() {
		return 'mombo-job-list';
	}

	public function get_title() {
		return esc_html__( 'Mombo: Job List', 'mombo-core' );
	}

	public function get_icon() {
		return 'eicon-post-list';
	}

	public function get_categories() {
		return [ 'mombo-category' ];
	}

	/**
	 * Register Job_List widget controls.
	 *
	 * @since 1.0
	 */
	protected function _register_controls() {

		$job_categories = [];

		$terms = get_terms('job-category');
		foreach($terms as $term) {
			$job_categories[$term->term_id] = $term->name;
		} 

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'mombo-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'categories',
			[
				'label' => esc_html__( 'Category Lists', 'mombo-core' ),
				'type' => Controls_Manager::REPEATER,
				'prevent_empty' => false,  
				'fields' => [ 
					[
						'name' => 'cat',
						'label' => esc_html__( 'Select Category', 'mombo-core' ),
						'type' => Controls_Manager::SELECT, 
						'options' => $job_categories,
					],
					[
						'name' => 'cat_bg',
						'label'     => esc_html__( 'Category Background Color', 'mombo-core' ),
						'type'      => Controls_Manager::COLOR,
						'default'	=> 'rgba(0, 51, 204, 0.1)', 
					],
					[
						'name' => 'cat_color',
						'label'     => esc_html__( 'Category Color', 'mombo-core' ),
						'type'      => Controls_Manager::COLOR,
						'default'	=> '#03c', 
					],
				],
				// 'title_field' => ' {{ cat }}',
			]
		); 

		$this->add_control(
			'number',
			[
				'label' => esc_html__( 'Total Job Per Category', 'mombo-core' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 6,
			]
		);

		$this->add_control(
			'search_bar',
			[
				'label' => esc_html__( 'Show Search Bar?', 'mombo-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'mombo-core' ),
				'label_off' => esc_html__( 'No', 'mombo-core' ),
				'return_value' => 'yes',
				'default' => 'yes', 
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Background', 'mombo-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'location_bg',
			[
				'label'     => esc_html__( 'Location Background Color', 'mombo-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '#15db95', 
			]
		); 

		$this->add_control(
			'location_color',
			[
				'label'     => esc_html__( 'Location Color', 'mombo-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '#fff', 
			]
		);  
		
		$this->end_controls_section(); 

	}

	/**
	 * Render Job_List widget output on the frontend.
	 *
	 * @since 1.0
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();  
		?> 
		<style>
			.box-shadow-hover {
				box-shadow: 0px 3px 10px 0px rgba(38, 59, 94, 0.1) !important;
			}
			.box-shadow-hover:hover {
				box-shadow: 0 1.5rem 4rem rgba(22, 28, 45, 0.1) !important;
			}
		</style>

		<?php if ( $settings['search_bar'] == 'yes' ) { ?>
		<div class="m-40px-b p-15px-t">
			<form class="d-flex flex-column flex-md-row m-5px-b" id="job-list" method="post">
				<input name="title" type="text" class="form-control md-m-0px-r m-20px-r md-m-10px-b" placeholder="<?php esc_attr_e( 'Search Jobs', 'mombo' ); ?>">
				<input type="hidden" name="action" value="mombo_job_search" /> 
				<?php wp_nonce_field( 'mombo_job_search', 'job-search' ); ?>

				<select name="cat_id" class="custom-select md-m-0px-r m-20px-r md-m-10px-b">
					<option selected value=""><?php esc_html_e( 'All Categories', 'mombo' ); ?></option>
					<?php
						$job_cats = get_terms('job-category');
						foreach($job_cats as $cat) { 
							echo '<option value="'.$cat->term_id.'">'.$cat->name.'</option>';
						} 
					?> 
				</select>
				<select name="location_id" class="custom-select md-m-0px-r m-20px-r md-m-10px-b">
					<option selected value=""><?php esc_html_e( 'All Locations', 'mombo' ); ?></option>
					<?php
						$job_locations = get_terms('job-location');
						foreach($job_locations as $location) { 
							echo '<option value="'.$location->term_id.'">'.$location->name.'</option>';
						} 
					?> 
				</select>
				<button class="m-btn m-btn-theme m-btn-radius flex-shrink-0" type="submit"><?php esc_html_e( 'Search Job', 'mombo' ); ?></button>
			</form>
		</div>
		<?php } ?>
		
		<div class="job-ajax">
			<?php foreach ( $settings['categories'] as $item ) : ?>
			<div class="m-40px-b">
				<div class="m-20px-b">
					<span class="d-inlin-block border-radius-15 p-5px-tb p-15px-lr" style="background-color: <?php echo esc_attr($item['cat_bg']); ?>; color: <?php echo esc_attr($item['cat_color']); ?>;"><?php if ( $item['cat'] ) { echo get_term_by('id', $item['cat'], 'job-category')->name; } ?></span>
				</div>
				<?php 
				$args = array(
					'posts_per_page' => $settings['number'],  
					'post_type' => 'job',
					'tax_query' => array(
						array(
							'taxonomy' => 'job-category',   
							'field' => 'term_id',          
							'terms' => $item['cat'],                  
						)
					)
				);
				$the_query = new \WP_Query( $args ); 
				while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
				<a class="card box-shadow-hover transition m-15px-b" href="<?php the_permalink(); ?>">
					<div class="card-body p-15px-tb p-25px-lr">
						<span class="row justify-content-sm-between align-items-sm-center">
							<span class="col-sm-6 m-5px-tb dark-color">
								<?php the_title(); ?>
							</span>
							<span class="col-sm-6 m-5px-tb text-sm-right">
								<span class="theme2nd-bg p-5px-tb p-10px-lr border-radius-15 white-color small" style="background-color: <?php echo esc_attr($settings['location_bg']); ?>; color: <?php echo esc_attr($settings['location_color']); ?>;">
									<?php 
										$job_location = get_the_terms( get_the_ID(), 'job-location' ); 
										$director = $job_location[0];
										if ( $job_location ) {
											echo esc_html( $job_location[0]->name );
										} 
									?>
									<i class="fas fa-arrow-right small m-5px-l"></i></span>
							</span>
						</span>
					</div>
				</a> 
				<?php endwhile; wp_reset_postdata(); ?>
			</div> 
			<?php endforeach; ?>
		</div>	
	<?php
	} 
}

Plugin::instance()->widgets_manager->register_widget_type( new Mombo_Job_List_Widget() );
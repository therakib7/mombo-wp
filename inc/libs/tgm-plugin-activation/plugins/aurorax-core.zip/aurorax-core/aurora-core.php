<?php
/*
    Plugin Name: AuroraX Core
    Plugin URI: https://demo.softhopper.net/aurorax-wp
    Description: This plugin is some component/shortcode and essential function for Aurorax Creative Portfolio WordPress theme, To use Aurorax theme properly you must install this plugin.
    Author: SoftHopper
    Version: 1.0
    Author URI: https://softhopper.net/
*/

if( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$theme = wp_get_theme(); // gets the current theme
if ( 'AuroraX' == $theme->name || 'AuroraX' == $theme->parent_theme ) : 
    
	define( 'ARURAX_PG_IS_ACTIVE_KC', in_array( 'kingcomposer/kingcomposer.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ); 
    
    require_once plugin_dir_path( __FILE__ ) . 'functions.php';
    if ( is_admin() ) {
    	require_once plugin_dir_path( __FILE__ ) . 'welcome-page.php';
    }
	require_once plugin_dir_path( __FILE__ ) . 'kc-shortcodes/kc-shortcodes.php';
	require_once plugin_dir_path( __FILE__ ) . 'custom-post.php';

endif; 


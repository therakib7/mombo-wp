<?php 
/**
 * Some theme and plugin funcitons goes here
 */
/**
 *  Remove Unnecessary p and br tag from shortcode
 *
 * @package Aurorax
 * @since 1.0
 */
if( !function_exists('aurorax_fix_shortcodes') ) :
    function aurorax_fix_shortcodes($content){
        $array = array (
            '<p>[' => '[',
            ']</p>' => ']',
            ']<br />' => ']'
        );
        $content = strtr($content, $array);
        return $content;   
    }
    add_filter('the_content', 'aurorax_fix_shortcodes');
endif;

/**
 *  Aurorax Social Post Share
 *
 * @package Aurorax
 * @since 1.0
 */
if ( ! function_exists( 'aurorax_social_share_link' ) ) :
function aurorax_social_share_link($before_text = "") { ?>
     <?php if($before_text != ""): ?> 
    <span class="meta-name"><?php echo esc_html($before_text); ?></span>    
    <?php endif; ?>               
    <!-- facebook share -->
    <a class="customer share facebook" rel="nofollow" title="<?php esc_html_e(  'Share on Facebook', 'litmus' ); ?>" href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>" onclick="aurorax_PopupWindow(this.href, 'facebook-share', 580, 400); return false;">
       <i class="fa fa-facebook"></i>
    </a>
    <a class="customer share twitter" rel="nofollow" title="<?php esc_html_e(  'Share on Twitter', 'litmus' ); ?>" href="https://twitter.com/home?status=<?php the_permalink(); ?>"  onclick="aurorax_PopupWindow(this.href, 'facebook-share', 580, 400); return false;">
        <i class="fa fa-twitter"></i>
    </a>

    <a class="customer share google-plus" rel="nofollow" title="<?php esc_html_e(  'Share on GooglePlus', 'litmus' ); ?>" href="https://plus.google.com/share?url=<?php the_permalink(); ?>" onclick="aurorax_PopupWindow(this.href, 'facebook-share', 580, 400); return false;">
        <i class="fa fa-google-plus"></i>
    </a>

    <a class="customer share linkedin" rel="nofollow" title="<?php esc_html_e(  'Share on Linkedin', 'litmus' ); ?>" href="http://www.linkedin.com/shareArticle?mini=true&url=<?php the_permalink(); ?>" onclick="aurorax_PopupWindow(this.href, 'facebook-share', 580, 400); return false;">
        <i class="fa fa-linkedin"></i>
    </a>
    <a rel="nofollow" class="customer share pinterest" title="<?php esc_html_e(  'Share on Pinterest', 'litmus' ); ?>" href="javascript:void((function()%7Bvar%20e=document.createElement('script');e.setAttribute('type','text/javascript');e.setAttribute('charset','UTF-8');e.setAttribute('src','http://assets.pinterest.com/js/pinmarklet.js?r='+Math.random()*99999999);document.body.appendChild(e)%7D)());">
        <i class="fa fa-pinterest-p"></i>
    </a> 
    <?php
}
endif;

/**
 *  Remove Query String
 *
 * @package Aurorax
 * @since 1.0
 */
function aurorax_remove_query_string_one( $src ){   
    $rqs = explode( '?ver', $src );
    return $rqs[0];
}
if ( !is_admin() ) { 
    add_filter( 'script_loader_src', 'aurorax_remove_query_string_one', 15, 1 );
    add_filter( 'style_loader_src', 'aurorax_remove_query_string_one', 15, 1 );
}

function aurorax_remove_query_string_two( $src ){
    $rqs = explode( '&ver', $src );
    return $rqs[0];
}
if ( !is_admin() ) { 
    add_filter( 'script_loader_src', 'aurorax_remove_query_string_two', 15, 1 );
    add_filter( 'style_loader_src', 'aurorax_remove_query_string_two', 15, 1 );
}

// avoid error when inactive KingComposer
if (function_exists('kc_prebuilt_template')) {
    $xml_path = get_template_directory().'inc/demos/section.xml';
    kc_prebuilt_template('Aurorax', $xml_path);
}
<?php
/**
 *  Aurorax Register Custom Post type
 *
 * @package Aurorax
 * @since 1.0
 */
if ( ! function_exists( 'aurorax_custom_posts' ) ) :
function aurorax_custom_posts() {

    /* Portfolio Custom Post*/  
    $portfolio_label = array(
        'name' => esc_html_x('Portfolio', 'Post Type General Name', 'aurorax'),
        'singular_name' => esc_html_x('Portfolio', 'Post Type Singular Name', 'aurorax'),
        'menu_name' => esc_html__('Portfolio', 'aurorax'),
        'parent_item_colon' => esc_html__('Parent Portfolio:', 'aurorax'),
        'all_items' => esc_html__('All Portfolio', 'aurorax'),
        'view_item' => esc_html__('View Portfolio', 'aurorax'),
        'add_new_item' => esc_html__('Add New Portfolio', 'aurorax'),
        'add_new' => esc_html__('New Portfolio', 'aurorax'),
        'edit_item' => esc_html__('Edit Portfolio', 'aurorax'),
        'update_item' => esc_html__('Update Portfolio', 'aurorax'),
        'search_items' => esc_html__('Search Portfolio', 'aurorax'),
        'not_found' => esc_html__('No portfolio found', 'aurorax'),
        'not_found_in_trash' => esc_html__('No portfolio found in Trash', 'aurorax'),
    );
    $portfolio_args = array(
        'label' => esc_html__('Portfolio', 'aurorax'),
        'description' => esc_html__('Portfolio', 'aurorax'),
        'labels' => $portfolio_label,
        'supports' => array('title', 'editor', 'thumbnail'),
        'taxonomies' => array('portfolio-category', 'portfolio-tag'),
        'hierarchical' => false,
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => true,
        'show_in_admin_bar' => true,
        'menu_position' => 20,
        'menu_icon' => 'dashicons-screenoptions',
        'can_export' => true,
        'has_archive' => true,
        'exclude_from_search' => true,
        'publicly_queryable' => true,
        'capability_type' => 'page',
    );
    register_post_type('portfolio', $portfolio_args);   

    // Add new taxonomy, make it hierarchical (like categories) 
    $portfolio_cat_taxonomy_labels = array(
        'name'              => esc_html__( 'Portfolio Categories','aurorax' ),
        'singular_name'     => esc_html__( 'Portfolio Categories','aurorax' ),
        'search_items'      => esc_html__( 'Search Portfolio Category','aurorax' ),
        'all_items'         => esc_html__( 'All Portfolio Category','aurorax' ),
        'parent_item'       => esc_html__( 'Parent Portfolio Category','aurorax' ),
        'parent_item_colon' => esc_html__( 'Parent Portfolio Category:','aurorax' ),
        'edit_item'         => esc_html__( 'Edit Portfolio Category','aurorax' ),
        'update_item'       => esc_html__( 'Update Portfolio Category','aurorax' ),
        'add_new_item'      => esc_html__( 'Add New Portfolio Category','aurorax' ),
        'new_item_name'     => esc_html__( 'New Portfolio Category Name','aurorax' ),
        'menu_name'         => esc_html__( 'Portfolio Category','aurorax' ),
    );    

    // Now register the portfolio taxonomy
    register_taxonomy('portfolio-category', array('portfolio'), array(
        'hierarchical' => true,
        'labels' => $portfolio_cat_taxonomy_labels,
        'query_var' => true,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array( 'slug' => 'portfolio-category' ),
    ));    
}
endif;
add_action('init', 'aurorax_custom_posts', 0);
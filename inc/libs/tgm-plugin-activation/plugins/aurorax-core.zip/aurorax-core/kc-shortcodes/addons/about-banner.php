<?php
add_shortcode( 'aurorax_about_banner', function($atts, $content = null) {
	extract(shortcode_atts(array(  
		'title' => '',  
		'desc' => '',        
		'scroll_down_id' => '',   
	), $atts));
	extract($atts);
	$master_class = apply_filters( 'kc-el-class', $atts );
	ob_start(); ?>
	<div class="<?php echo esc_attr( implode( ' ', $master_class ) ); ?>">
		<?php if(!empty($title)) : ?>   
		<div class="banner-background banner">
			<div class="banner-text">
			  	<h2 class="banner-title"><?php echo wp_kses_post( $title ); ?></h2>
			  	<h3 class="banner-subtitle"><?php echo wp_kses_post( $desc ); ?></h3>
			</div><!-- /banner-text -->
			<div class="discover">
			  	<span class="discover-line"></span>
			 	<a href="#<?php echo esc_attr($scroll_down_id); ?>"><?php esc_html_e('Scroll Down', 'aurorax'); ?></a>
			</div><!-- /discover -->
		</div><!-- /banner -->
		<?php endif; ?>
	</div>
	<?php return ob_get_clean();
});

// King Composer Custom Shortcode
add_action( 'init', 'aurorax_kc_about_banner', 99 );
function aurorax_kc_about_banner() {
	if (function_exists('kc_add_map')) { 
	    kc_add_map(
	        array( 
	            'aurorax_about_banner' => array(
	                'name' => esc_html__('Author Banner', 'aurorax'),
	                'description' => esc_html__('This banner component for author introduction', 'aurorax'),
	                'icon' => 'et-desktop',
	                'category' => 'Aurorax',
	                'params' => array(
	                	'general' => array(        	
	                		array(
	                			'name' => 'title',
	                			'type' => 'text',
	                			'label' => esc_html__('Banner Title', 'aurorax'),  
	                			'value' => "Hello, I'm Adam Doe.",   
	                			'admin_label' => true,
	                		),
	                		array(
	                			'name' => 'desc',
	                			'type' => 'textarea',
	                			'label' => esc_html__('Banner Short Description', 'aurorax'), 
	                			'value' => "I'm a creative graphic designer <br /> and sometimes also a photographer.",
	                		), 
	                		array(
	                			'name' => 'scroll_down_id',
	                			'type' => 'text',
	                			'label' => esc_html__('Scroll Down Arrow Component ID', 'aurorax'),  
	                			'value' => "about-me",    
	                		),
	                	),
	                	'styling' => array(
	                		array(
	                			'name'		=> 'css_custom',
	                			'type'		=> 'css',
	                			'options'	=> array(
	                				array(
	                					"screens" => "any,1024,999,767,479",
	                					'Background' => array(
	                						array(
	                							'property' => 'background',
	                							'selector' => '.banner-background'
	                						),						
	                						array(
	                							'property' => 'height',
	                							'selector' => '.banner-background'
	                						),
	                					),
	                					'Title' => array(
	                						array(
	                							'property' => 'color',
	                							'selector' => '.banner-title'
	                						),						
	                						array(
	                							'property' => 'font-family',
	                							'selector' => '.banner-title'
	                						),  						
	                						array(
	                							'property' => 'font-size',
	                							'selector' => '.banner-title'
	                						),				
	                						array(
	                							'property' => 'font-weight',
	                							'selector' => '.banner-title'
	                						),			
	                						array(
	                							'property' => 'line-height',
	                							'selector' => '.banner-title'
	                						),				
	                						array(
	                							'property' => 'letter-spacing',
	                							'selector' => '.banner-title'
	                						),				
	                						array(
	                							'property' => 'text-transform',
	                							'selector' => '.banner-title'
	                						),		
	                						array(
	                							'property' => 'text-align',
	                							'selector' => '.banner-title'
	                						),			
	                						array(
	                							'property' => 'display',
	                							'selector' => '.banner-title'
	                						),		
	                						array(
	                							'property' => 'padding',
	                							'selector' => '.banner-title'
	                						),
	                						array(
	                							'property' => 'margin',
	                							'selector' => '.banner-title'
	                						),
	                					),			
	                					'SubTitle' => array(
	                						array(
	                							'property' => 'color',
	                							'selector' => '.banner-subtitle'
	                						),						
	                						array(
	                							'property' => 'font-family',
	                							'selector' => '.banner-subtitle'
	                						),  						
	                						array(
	                							'property' => 'font-size',
	                							'selector' => '.banner-subtitle'
	                						),				
	                						array(
	                							'property' => 'font-weight',
	                							'selector' => '.banner-subtitle'
	                						),			
	                						array(
	                							'property' => 'line-height',
	                							'selector' => '.banner-subtitle'
	                						),				
	                						array(
	                							'property' => 'letter-spacing',
	                							'selector' => '.banner-subtitle'
	                						),				
	                						array(
	                							'property' => 'text-transform',
	                							'selector' => '.banner-subtitle'
	                						),		
	                						array(
	                							'property' => 'text-align',
	                							'selector' => '.banner-subtitle'
	                						),			
	                						array(
	                							'property' => 'display',
	                							'selector' => '.banner-subtitle'
	                						),		
	                						array(
	                							'property' => 'padding',
	                							'selector' => '.banner-subtitle'
	                						),
	                						array(
	                							'property' => 'margin',
	                							'selector' => '.banner-subtitle'
	                						),
	                					),	                					
	                					'ScrollElement' => array(
	                						array(
	                							'property' => 'color',
	                							'selector' => '.discover a'
	                						),	
	                						array(
	                							'property' => 'font-weight',
	                							'selector' => '.discover a'
	                						),						
	                						array(
	                							'property' => 'background',
	                							'selector' => '.discover .discover-line'
	                						),
	                					),
	                				),
	                			),
	                		),
	                	),
						'animate' => array(
							array(
								'name'    => 'animate',
								'type'    => 'animate'
							)
						),
	                ),
	            ),  // End of elemnt kc_icon 
	        )
	    ); // End add map
	
	} // End if
}
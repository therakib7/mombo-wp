<?php
add_shortcode( 'aurorax_call_to_action', function($atts, $content = null) {
	extract(shortcode_atts(array(    
		'title' => '',  
		'btn_url' => '',   
	), $atts));  
	extract($atts);
	$master_class = apply_filters( 'kc-el-class', $atts );
	ob_start(); ?>
	<div class="<?php echo esc_attr( implode( ' ', $master_class ) ); ?>">
		<div class="portfolio-contact">
		  	<h2 class="call-to-action-title"><?php echo wp_kses_post( $title ); ?></h2>
		  	<?php 
		  		$linkurl = aurorax_theme_kc_custom_link($btn_url);
		  		$button_attr = array();
		  		if(  $linkurl["url"] != "" ) {
		  			$button_attr[] = 'href="'. esc_attr($linkurl["url"]) .'"';
		  		} else {
		  			$button_attr[] = 'href="#"';
		  		}
		  		if( $linkurl["target"] != "" ){
		  			$button_attr[] = 'target="'. esc_attr($linkurl["target"]) .'"';
		  		}
		  		if(  $linkurl["title"] != "" ){
		  			$button_attr[] = 'title="'. esc_attr($linkurl["title"]) .'"';
		  		}
		  	?>
		  	<?php 
		  		if($linkurl) { ?>
		  			<a class="btn btn-dark2 call-to-action-btn" <?php echo implode(' ', $button_attr); ?>><?php echo esc_html($linkurl["title"]); ?></a>
		  		<?php }
		  	?>
		</div><!-- /portfolio-contact -->
	</div>
	<?php return ob_get_clean();
});

// King Composer Custom Shortcode
add_action( 'init', 'aurorax_kc_call_to_action', 101 );
function aurorax_kc_call_to_action() {
	if (function_exists('kc_add_map')) { 
	    kc_add_map(
	        array( 
	            'aurorax_call_to_action' => array(
	                'name' => esc_html__('Call To Action', 'litmus'),
	                'description' => esc_html__('Call To Action', 'litmus'),
	                'icon' => 'et-streetsign',
	                'category' => 'Aurorax',
	                'params' => array(
	                	'general' => array( 
		                    array(
		                    	'name' => 'title',
		                    	'type' => 'textarea',
		                    	'value' => "Do you like my work? <br />Let's create something wonderful together.",
		                    	'label' => esc_html__('Title', 'litmus'),  
		                    	'admin_label' => true,
		                    ),
		                    array(
		                    	'name' => 'btn_url',
		                    	'type' => 'link', 
		                    	'label' => esc_html__('Button', 'litmus'), 
		                    ),
	                	),
	                	'styling' => array(
	                		array(
	                			'name'		=> 'css_custom',
	                			'type'		=> 'css',
	                			'options'	=> array(
	                				array(
	                					"screens" => "any, 1024, 999, 767, 479",
	                					'Background' => array(
	                						array(
	                							'property' => 'background',
	                							'selector' => '.portfolio-contact'
	                						),	                						
	                						array(
	                							'property' => 'padding',
	                							'selector' => '.portfolio-contact'
	                						),
	                					),
	                					'Title' => array(
	                						array(
	                							'property' => 'color',
	                							'selector' => '.call-to-action-title'
	                						),						
	                						array(
	                							'property' => 'font-family',
	                							'selector' => '.call-to-action-title'
	                						),  						
	                						array(
	                							'property' => 'font-size',
	                							'selector' => '.call-to-action-title'
	                						),				
	                						array(
	                							'property' => 'font-weight',
	                							'selector' => '.call-to-action-title'
	                						),			
	                						array(
	                							'property' => 'line-height',
	                							'selector' => '.call-to-action-title'
	                						),				
	                						array(
	                							'property' => 'letter-spacing',
	                							'selector' => '.call-to-action-title'
	                						),				
	                						array(
	                							'property' => 'text-transform',
	                							'selector' => '.call-to-action-title'
	                						),		
	                						array(
	                							'property' => 'text-align',
	                							'selector' => '.call-to-action-title'
	                						),			
	                						array(
	                							'property' => 'display',
	                							'selector' => '.call-to-action-title'
	                						),		
	                						array(
	                							'property' => 'padding',
	                							'selector' => '.call-to-action-title'
	                						),
	                						array(
	                							'property' => 'margin',
	                							'selector' => '.call-to-action-title'
	                						),
	                					),
	                					'Button Style' => array(
	                						array('property' => 'color', 'label' => 'Text Color', 'selector' => '.call-to-action-btn'),
	                						array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.call-to-action-btn'),
	                						array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.call-to-action-btn'),
	                						array('property' => 'font-size', 'label' => 'Text Size', 'selector' => '.call-to-action-btn'),
	                						array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.call-to-action-btn'),
	                						array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.call-to-action-btn'),
	                						array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.call-to-action-btn'),
	                						array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.call-to-action-btn'),
	                						array('property' => 'text-align', 'label' => 'Align'),
	                						array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.call-to-action-btn'),
	                						array('property' => 'text-shadow', 'label' => 'Text Shadow', 'selector' => '.call-to-action-btn'),
	                						array('property' => 'width', 'selector' => '.call-to-action-btn'),
	                						array('property' => 'height', 'selector' => '.call-to-action-btn'),
	                						array('property' => 'display', 'label' => 'Display'),
	                						array('property' => 'border', 'label' => 'Border', 'selector' => '.call-to-action-btn'),
	                						array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.call-to-action-btn'),
	                						array('property' => 'padding', 'label' => 'Padding', 'selector' => '.call-to-action-btn'),
	                						array('property' => 'margin', 'label' => 'Margin', 'selector' => '.call-to-action-btn'),
	                					),
	                					'Mouse Hover' => array(
	                						array('property' => 'font-size', 'label' => 'Text Size', 'selector' => '.call-to-action-btn:hover'),
	                						array('property' => 'color', 'label' => 'Text Color', 'selector'=>'.call-to-action-btn:hover'),
	                						array('property' => 'background-color', 'label' => 'Background Color', 'selector'=>'.call-to-action-btn:hover'),
	                						array('property' => 'border', 'label' => 'Border', 'selector'=>'.call-to-action-btn:hover'),
	                						array('property' => 'border-radius', 'label' => 'Border Radius Hover', 'selector'=>'.call-to-action-btn:hover')
	                					) 
	                				),
	                			),
	                		),
	                	),
						'animate' => array(
							array(
								'name'    => 'animate',
								'type'    => 'animate'
							)
						),
	                )
	            ),  // End of elemnt kc_icon 

	        )
	    ); // End add map
	
	} // End if
}
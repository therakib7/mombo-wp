<?php
add_shortcode( 'aurorax_portfilio', function($atts, $content = null) {
	extract(shortcode_atts(array(  
		'style' => '',  
		'number' => '',  
	), $atts));  
	extract($atts);
	$master_class = apply_filters( 'kc-el-class', $atts );
	ob_start(); ?> 

	<?php if($style == 'one'): ?>
	<!-- ======== WORK ======== -->
	<div class="<?php echo esc_attr( implode( ' ', $master_class ) ); ?>">
		<div class="work">
			<div class="aurorax-container-portfolio">
				<div class="row">
		    		<div class="col-md-12">
		    			<div class="swiper-container">
				          	<div class="swiper-wrapper">
							<?php 
								$portfolio_query = new WP_Query(
								    array(
								        'post_type' => 'portfolio', 
								        'posts_per_page' => $number, 
								    )
								); 
								while ($portfolio_query->have_posts()) : $portfolio_query->the_post(); ?>
				            		<div class="swiper-slide"> 
						                <?php if ( has_post_thumbnail() ) { 
						                	aurorax_post_featured_image(1030, 722, true);
						                } ?>
				                		<div class="work-overlay">
				                  			<div class="work-overlay-txt">
				                  				<h2 class="portfolio-tille">
								                    <a href="<?php the_permalink(); ?>">
								                      	<?php the_title(); ?>
								                    </a>
							                    </h2>
							                    <h4 class="portfolio-category">
													<?php 
														$categories = get_the_terms( get_the_ID(), 'portfolio-category' );
														if ( ! empty( $categories ) ) {
														    echo '<a href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>';
														}
													?>
							                    </h4>
				                  			</div><!-- /work-overlay-txt -->
				                		</div><!-- /work-overlay -->
				            		</div><!-- /swiper-slide -->
				            	<?php endwhile; wp_reset_postdata(); ?> 
				          		</div><!-- /swiper-wrapper -->
		    				</div><!-- /swiper-container -->
		    			<div class="swiper-scrollbar"></div>
		    		</div><!-- /col-md-12 -->
				</div><!-- /row -->
			</div><!-- /container-fluid -->
		</div><!-- /work -->
	</div>
	<!-- ======== /WORK ======== -->
	<?php else: ?> 
	<!-- ======== PORTFOLIO ======== -->
	<div class="<?php echo esc_attr( implode( ' ', $master_class ) ); ?>">
		<div class="work">
			<div class="aurorax-container-portfolio">
			  	<div class="row">
		      		<div class="col-md-12 no-padding">
					    <div class="owl-carousel owl-full owl-theme">
							<?php 
							$portfolio_query = new WP_Query(
							    array(
							        'post_type' => 'portfolio', 
							        'posts_per_page' => $number, 
							    )
							); 
							while ($portfolio_query->have_posts()) : $portfolio_query->the_post(); ?>
				            <div class="item item-work" style="background: url(<?php echo aurorax_get_image_crop_size(get_post_thumbnail_id(), 700, 750); ?>)">
				              	<div class="work-overlay">
				                	<div class="work-overlay-txt">
		                  				<h2 class="portfolio-tille">
						                    <a href="<?php the_permalink(); ?>">
						                      	<?php the_title(); ?>
						                    </a>
					                    </h2>
					                    <h4 class="portfolio-category">
											<?php 
												$categories = get_the_terms( get_the_ID(), 'portfolio-category' );
												if ( ! empty( $categories ) ) {
												    echo '<a href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>';
												}
											?>
					                    </h4>
				                	</div><!-- /work-overlay-txt -->
				              	</div><!-- /work-overlay -->
				            </div><!-- /item -->
				            <?php endwhile; wp_reset_postdata(); ?> 
					    </div><!-- /owl-carousel -->
		      		</div><!-- /col-md-12 -->
			  	</div><!-- /row -->
			</div><!-- /container-fluid -->
		</div><!-- /work -->
	</div>
	<!-- ======== /PORTFOLIO ======== -->
	<?php endif; ?> 
	<?php return ob_get_clean();
});

// Visual Composer Custom Shortcode
add_action( 'init', 'aurorax_kc_portfilio', 100 );
function aurorax_kc_portfilio() {
	if (function_exists('kc_add_map')) { 
	    kc_add_map(
	        array( 
	            'aurorax_portfilio' => array(
	                'name' => esc_html__('Portfolio', 'litmus'),
	                'description' => esc_html__('Portfolio', 'litmus'),
	                'icon' => 'sl-grid',
	                'category' => 'Aurorax',
	                'params' => array(
	                	'general' => array( 
		                	array(
		                		'name' => 'style',
		                		'label' => esc_html__('Style', 'litmus'),  
		                		'type' => 'select',  
		                		'options' => array(  
		                			'one' => esc_html__('One', 'litmus'), 
		                			'two' => esc_html__('Two', 'litmus'),    
		                		),
		                		'value' => 'one',
		                	),
		                    array(
		                    	'name' => 'number',
		                    	'label' => esc_html__('Total Post', 'litmus'), 
		                    	'type' => 'number_slider',  
		                    	'options' => array(  
		                    		'min' => 3,
		                    		'max' => 50, 
		                    		'show_input' => true
		                    	), 
		                    	'value' => 10
		                    ), 
	                	),
	                	'styling' => array(
	                		array(
	                			'name'		=> 'css_custom',
	                			'type'		=> 'css',
	                			'options'	=> array(
	                				array(
	                					"screens" => "any,1024,999,767,479",
	                					'Hover'	=> array(
	                						array(
	                							'property' => 'background',
	                							'label' => esc_html__('Hover Background','litmus'),
	                							'selector' => '.portfolio-thumb .hover-content'
	                						),	                						
	                					),
	                					'Title' => array(
	                						array(
	                							'property' => 'color',
	                							'selector' => '.portfolio-tille'
	                						),						
	                						array(
	                							'property' => 'font-family',
	                							'selector' => '.portfolio-tille'
	                						),  						
	                						array(
	                							'property' => 'font-size',
	                							'selector' => '.portfolio-tille'
	                						),				
	                						array(
	                							'property' => 'font-weight',
	                							'selector' => '.portfolio-tille'
	                						),			
	                						array(
	                							'property' => 'line-height',
	                							'selector' => '.portfolio-tille'
	                						),				
	                						array(
	                							'property' => 'letter-spacing',
	                							'selector' => '.portfolio-tille'
	                						),				
	                						array(
	                							'property' => 'text-transform',
	                							'selector' => '.portfolio-tille'
	                						),		
	                						array(
	                							'property' => 'text-align',
	                							'selector' => '.portfolio-tille'
	                						),			
	                						array(
	                							'property' => 'display',
	                							'selector' => '.portfolio-tille'
	                						),		
	                						array(
	                							'property' => 'padding',
	                							'selector' => '.portfolio-tille'
	                						),
	                						array(
	                							'property' => 'margin',
	                							'selector' => '.portfolio-tille'
	                						),
	                					),			
	                					'Category' => array(
	                						array(
	                							'property' => 'color',
	                							'selector' => '.portfolio-category'
	                						),						
	                						array(
	                							'property' => 'font-family',
	                							'selector' => '.portfolio-category'
	                						),  						
	                						array(
	                							'property' => 'font-size',
	                							'selector' => '.portfolio-category'
	                						),				
	                						array(
	                							'property' => 'font-weight',
	                							'selector' => '.portfolio-category'
	                						),			
	                						array(
	                							'property' => 'line-height',
	                							'selector' => '.portfolio-category'
	                						),				
	                						array(
	                							'property' => 'letter-spacing',
	                							'selector' => '.portfolio-category'
	                						),				
	                						array(
	                							'property' => 'text-transform',
	                							'selector' => '.portfolio-category'
	                						),		
	                						array(
	                							'property' => 'text-align',
	                							'selector' => '.portfolio-category'
	                						),			
	                						array(
	                							'property' => 'display',
	                							'selector' => '.portfolio-category'
	                						),		
	                						array(
	                							'property' => 'padding',
	                							'selector' => '.portfolio-category'
	                						),
	                						array(
	                							'property' => 'margin',
	                							'selector' => '.portfolio-category'
	                						),
	                					),
	                					'Scrollbar' => array(
	                						array(
	                							'property' => 'background',
	                							'label' => esc_html__('Scrollbar Background','aurorax'),
	                							'selector' => '.swiper-scrollbar-drag'
	                						),
	                					),		                					
	                					'Nav Dot' => array(
	                						array(
	                							'property' => 'background',
	                							'label' => esc_html__('Carousel Dot Background','aurorax'),
	                							'selector' => '.owl-theme .owl-dots .owl-dot.active span, .owl-theme .owl-dots .owl-dot:hover span'
	                						),
	                					),	 
	                				),
	                			),
	                		),
	                	),
						'animate' => array(
							array(
								'name'    => 'animate',
								'type'    => 'animate'
							)
						),
	                ),
	            ),  // End of elemnt kc_icon 
	        )
	    ); // End add map
	} // End if
}
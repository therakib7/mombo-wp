<?php
add_shortcode( 'aurorax_services', function($atts, $content = null) {
	extract(shortcode_atts(array(
		'icon' => '', 
		'title' => '', 
		'desc' => '', 
	), $atts));  
	$master_class = apply_filters( 'kc-el-class', $atts );
	ob_start(); ?>   
	<!-- ======== SERVICES ======== -->
	<div class="<?php echo esc_attr( implode( ' ', $master_class ) ); ?>">
		<div class="services">
			<div class="services-item">
				<div class="services-icon">
					<span class="<?php echo esc_attr($icon); ?>"></span>
				</div><!-- /services-icon -->

				<div class="services-info">
					<h4 class="service-title"><?php echo esc_html($title); ?></h4>
					<p class="service-description"><?php echo esc_html($desc); ?></p>
				</div><!-- /services-info -->
			</div><!-- /services-item -->
		</div><!-- /services -->
	</div>
	<!-- ======== /SERVICES ======== -->
	<?php return ob_get_clean();
});

// Visual Composer Custom Shortcode
add_action( 'init', 'aurorax_kc_services', 102 );
function aurorax_kc_services() {
	if (function_exists('kc_add_map')) { 
	    kc_add_map(
	        array( 
	            'aurorax_services' => array(
	                'name' => esc_html__('Services', 'litmus'),
	                'description' => esc_html__('Services', 'litmus'),
	                'icon' => 'et-gears',
	                'category' => 'Aurorax',
	                'params' => array(
	                	'general' => array(
		                	array(
		                		'name' => 'icon',
		                		'type' => 'icon_picker',
		                		'label' => esc_html__('Icon', 'litmus'),  
		                		"value" => "icon-laptop",  
		                	),
		                	array(
		                		'name' => 'title',
		                		'type' => 'text',
		                		'label' => esc_html__('Title', 'litmus'),  
		                		'value' => "Web design",
		                		'admin_label' => true,
		                	),
		                	array(
		                		'name' => 'desc',
		                		'type' => 'textarea',
		                		'label' => esc_html__('Short Description', 'litmus'),
		                		'value' => "Curabitur vitae magna felis. Nulla ac libero ornare, vestibulum lacus quis blandit enimdicta sunt libero ornare.",
		                	),
	                	),
	                	'styling' => array(
	                		array(
	                			'name'		=> 'css_custom',
	                			'type'		=> 'css',
	                			'options'	=> array(
	                				array(
	                					"screens" => "any, 1024, 999, 767, 479",
	                					'Icon' => array(
	                						array(
	                							'property' => 'font-size',
	                							'selector' => '.services-icon span'
	                						),	                						
	                						array(
	                							'property' => 'line-height', 
	                							'selector' => '.services-icon span'
	                						),					
	                						array(
	                							'property' => 'text-align', 
	                							'selector' => '.services-icon'
	                						),				
	                						array(
	                							'property' => 'display', 
	                							'selector' => '.services-icon'
	                						),
	                						array(
	                							'property' => 'color',
	                							'selector' => '.services-icon span'
	                						),
	                						array(
	                							'property' => 'background', 
	                							'selector' => '.services-icon'
	                						),	               						
	                						array(
	                							'property' => 'width', 
	                							'selector' => '.services-icon'
	                						),				
	                						array(
	                							'property' => 'height', 
	                							'selector' => '.services-icon'
	                						),			
	                						array(
	                							'property' => 'border-radius', 
	                							'selector' => '.services-icon'
	                						),					
	                						array(
	                							'property' => 'border', 
	                							'selector' => '.services-icon'
	                						),	         						
	                						array(
	                							'property' => 'margin', 
	                							'selector' => '.services-icon'
	                						),	    						
	                						array(
	                							'property' => 'padding', 
	                							'selector' => '.services-icon'
	                						),	                						
	                					),
	                					'Title' => array(
	                						array(
	                							'property' => 'color',
	                							'selector' => '.service-title'
	                						),						
	                						array(
	                							'property' => 'font-family',
	                							'selector' => '.service-title'
	                						),  						
	                						array(
	                							'property' => 'font-size',
	                							'selector' => '.service-title'
	                						),				
	                						array(
	                							'property' => 'font-weight',
	                							'selector' => '.service-title'
	                						),			
	                						array(
	                							'property' => 'line-height',
	                							'selector' => '.service-title'
	                						),				
	                						array(
	                							'property' => 'letter-spacing',
	                							'selector' => '.service-title'
	                						),				
	                						array(
	                							'property' => 'text-transform',
	                							'selector' => '.service-title'
	                						),		
	                						array(
	                							'property' => 'text-align',
	                							'selector' => '.service-title'
	                						),			
	                						array(
	                							'property' => 'display',
	                							'selector' => '.service-title'
	                						),		
	                						array(
	                							'property' => 'padding',
	                							'selector' => '.service-title'
	                						),
	                						array(
	                							'property' => 'margin',
	                							'selector' => '.service-title'
	                						),
	                					),	                					
	                					'Description' => array(
	                						array(
	                							'property' => 'color',
	                							'selector' => '.service-description'
	                						),						
	                						array(
	                							'property' => 'font-family',
	                							'selector' => '.service-description'
	                						),  						
	                						array(
	                							'property' => 'font-size',
	                							'selector' => '.service-description'
	                						),				
	                						array(
	                							'property' => 'font-weight',
	                							'selector' => '.service-description'
	                						),			
	                						array(
	                							'property' => 'line-height',
	                							'selector' => '.service-description'
	                						),				
	                						array(
	                							'property' => 'letter-spacing',
	                							'selector' => '.service-description'
	                						),				
	                						array(
	                							'property' => 'text-transform',
	                							'selector' => '.service-description'
	                						),		
	                						array(
	                							'property' => 'text-align',
	                							'selector' => '.service-description'
	                						),			
	                						array(
	                							'property' => 'display',
	                							'selector' => '.service-description'
	                						),		
	                						array(
	                							'property' => 'padding',
	                							'selector' => '.service-description'
	                						),
	                						array(
	                							'property' => 'margin',
	                							'selector' => '.service-description'
	                						),
	                					),
	                				),
	                			),
	                		),
	                	),
						'animate' => array(
							array(
								'name'    => 'animate',
								'type'    => 'animate'
							)
						),
	                )
	            ),  // End of elemnt kc_icon 

	        )
	    ); // End add map
	
	} // End if
}
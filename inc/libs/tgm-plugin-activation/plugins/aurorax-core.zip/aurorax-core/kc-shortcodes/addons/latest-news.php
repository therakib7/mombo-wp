<?php
add_shortcode( 'aurorax_latest_news', function($atts, $content = null) {
	extract(shortcode_atts(array(  
		'number' => '',    
	), $atts));  
	$master_class = apply_filters( 'kc-el-class', $atts );
	ob_start(); ?> 
	<!-- ======== BLOG ======== -->
	<div class="<?php echo esc_attr( implode( ' ', $master_class ) ); ?>">
		<div class="blog">
		    <div class="row item-3">
				<?php  
				$args = array(
				  'posts_per_page' => $number,  
				  'post_type' => 'post'
				);
				$col_class = 'col-md-4 col-item';
				$the_query = new WP_Query( $args ); 
				while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
					<div class="<?php echo esc_attr($col_class); ?> col-sm-6 col-xs-12 blog-spacing col-item">
					    <div id="post-<?php the_ID(); ?>" <?php post_class('blog-item'); ?>> 
					        <?php if ( has_post_thumbnail() ) { ?>
					            <figure class="post-thumb">            
					                <a href="<?php the_permalink(); ?>">
					                    <?php aurorax_post_featured_image(409, 275, true); ?>            
					                </a> 
					            </figure> 
					        <?php } ?>
					        <div class="blog-content">
					        	<div class="post-meta">
					        		<?php esc_html_e('By', 'aurorax'); ?> <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ); ?>"><?php the_author(); ?></a>
					        		<?php if( get_the_post_thumbnail() == "" && get_the_title() == ""): ?>
					        		<span class="entry-date no-title"><i class="fa fa-link"></i><a href="<?php the_permalink(); ?>"><?php the_time( get_option( 'date_format' ) ); ?></a></span>
					        		<?php else: ?>
					        		<span class="entry-date"><?php the_time( get_option( 'date_format' ) ); ?></span>
					        		<?php endif; ?> 
					        	</div><!-- /post-meta -->
					        	<div class="post-title">
					        	  	<?php the_title( sprintf( '<h4 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h4>' ); ?>
					        	</div><!-- /post-title -->
					        </div><!-- /blog-content -->
					    </div><!-- /blog-item -->
					</div><!-- /col-md-4 -->
				<?php endwhile; ?>  
		    </div><!-- /row -->
		</div><!-- /blog -->
	</div>
	<!-- ======== /BLOG ======== -->  
	<?php return ob_get_clean();
});

// King Composer Custom Shortcode
add_action( 'init', 'aurorax_kc_latest_news', 104 );
function aurorax_kc_latest_news() {
	if (function_exists('kc_add_map')) { 
	    kc_add_map(
	        array( 
	            'aurorax_latest_news' => array(
	                'name' => esc_html__('Latest News', 'litmus'),
	                'description' => esc_html__('Latest News', 'litmus'),
	                'icon' => 'et-book-open',
	                'category' => 'Aurorax',
	                'params' => array( 
	                	'general' => array(
		                	array(
		                		'name' => 'number',
		                		'label' => esc_html__('Total Post', 'aurorax'), 
		                		'type' => 'number_slider',  
		                		'options' => array(  
		                			'min' => 1,
		                			'max' => 20, 
		                			'show_input' => true
		                		), 
		                		'value' => 3
		                	),
	                	),
	                	'styling' => array(
	                		array(
	                			'name'		=> 'css_custom',
	                			'type'		=> 'css',
	                			'options'	=> array(
	                				array(
	                					"screens" => "any,1024,999,767,479",
	                					'Post'  => array(
	                						array(
	                							'property' => 'background', 
	                							'selector' => '.blog-item'
	                						), 	   						
	                						array(
	                							'property' => 'margin', 
	                							'selector' => '.blog-item'
	                						), 				
	                						array(
	                							'property' => 'padding',
	                							'selector' => '.blog-item'
	                						), 
	                					),
	                					'Meta'	=> array(
	                						array(
	                							'property' => 'color', 
	                							'selector' => '.post-meta'
	                						), 	   						
	                						array(
	                							'property' => 'color',
	                							'label'	   => esc_html__('Meta Anchor color','aurorax'), 
	                							'selector' => '.post-meta a'
	                						), 				
	                						array(
	                							'property' => 'font-size', 
	                							'selector' => '.post-meta'
	                						), 				
	                						array(
	                							'property' => 'font-weight', 
	                							'selector' => '.post-meta'
	                						), 			
	                						array(
	                							'property' => 'line-height', 
	                							'selector' => '.post-meta'
	                						), 				
	                						array(
	                							'property' => 'letter-spacing', 
	                							'selector' => '.post-meta'
	                						), 			
	                						array(
	                							'property' => 'text-align', 
	                							'selector' => '.post-meta'
	                						), 		
	                						array(
	                							'property' => 'text-transform', 
	                							'selector' => '.post-meta'
	                						), 
	                					),
	                					'Title' => array(
	                						array(
	                							'property' => 'color',
	                							'selector' => '.entry-title'
	                						),											
	                						array(
	                							'property' => 'font-family',
	                							'selector' => '.entry-title'
	                						),  						
	                						array(
	                							'property' => 'font-size',
	                							'selector' => '.entry-title'
	                						),				
	                						array(
	                							'property' => 'font-weight',
	                							'selector' => '.entry-title'
	                						),			
	                						array(
	                							'property' => 'line-height',
	                							'selector' => '.entry-title'
	                						),				
	                						array(
	                							'property' => 'letter-spacing',
	                							'selector' => '.entry-title'
	                						),				
	                						array(
	                							'property' => 'text-transform',
	                							'selector' => '.entry-title'
	                						),		
	                						array(
	                							'property' => 'text-align',
	                							'selector' => '.entry-title'
	                						),			
	                						array(
	                							'property' => 'display',
	                							'selector' => '.entry-title'
	                						),		
	                						array(
	                							'property' => 'padding',
	                							'selector' => '.entry-title'
	                						),
	                						array(
	                							'property' => 'margin',
	                							'selector' => '.entry-title'
	                						),
	                					),	 
	                				),
	                			),
	                		),
	                	),
	                	'animate' => array(
	                		array(
	                			'name'    => 'animate',
	                			'type'    => 'animate'
	                		)
	                	),
	                )
	            ),  // End of elemnt kc_icon  
	        )
	    ); // End add map 
	} // End if
}
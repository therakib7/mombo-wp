<?php
add_shortcode( 'aurorax_testimonials', function($atts, $content = null) {
	extract(shortcode_atts(array( 
		'testimonials' => '', 
	), $atts));  
	extract($atts);
	$master_class = apply_filters( 'kc-el-class', $atts );
	ob_start(); ?> 
	<!-- ======== TESTIMONIALS ======== -->
	<div class="<?php echo esc_attr( implode( ' ', $master_class ) ); ?>">
		<div class="testimonials text-center">
			<div class="row">
				<div class="col-md-8 col-md-offset-2">
			      	<div class="owl-carousel owl-theme">
				    <?php 
						if(!empty($testimonials)) {
						foreach ($testimonials as $testimonial) { 
					?>
			        	<div class="item">
			        	  	<img src="<?php echo esc_url(aurorax_get_image_crop_size($testimonial->img, 90, 90)); ?>" class="img-responsive" alt="<?php if(isset($testimonial->name)) echo esc_attr($testimonial->name); ?>" />
			        	  	<p class="testimonial-content"><?php echo wp_kses( $testimonial->testimonial, Aurorax_Static::html_allow() ); ?></p>
			        	  	<h4 class="testimonial-author"><?php if(isset($testimonial->name)) echo esc_html($testimonial->name); ?> - <span><?php if(isset($testimonial->company)) echo esc_html($testimonial->company); ?></span></h4>
			        	</div><!-- /item -->
			          <?php } } ?>
			      	</div><!-- /owlcarousel -->
				</div><!-- /col-md-8 -->
			</div><!-- /row -->
		</div><!-- /testimonials -->
	</div>
	<!-- ======== /TESTIMONIALS ======== -->
	<?php return ob_get_clean();
});

// King Composer Custom Shortcode
add_action( 'init', 'aurorax_kc_testimonials', 103 );
function aurorax_kc_testimonials() {
	if (function_exists('kc_add_map')) { 
	    kc_add_map(
	        array( 
	            'aurorax_testimonials' => array(
	                'name' => esc_html__('Testimonials', 'litmus'),
	                'description' => esc_html__('Testimonials', 'litmus'),
	                'icon' => 'et-happy',
	                'category' => 'Aurorax',
	                'params' => array( 
	                	'general' => array(               		
		                    array(
		                    	'name'			=> 'testimonials',
		                    	'type'			=> 'group',
		                    	'label'			=> esc_html__('Testimonials', 'litmus'), 
		                    	'options'		=> array('add_text' => esc_html__('Add new testimonial', 'litmus')), 
		                    	'value' => base64_encode( json_encode( array(
		                    		"1" => array(
		                    			"name" => "Joanna Doe", 
		                    			"company" => "ABC Corp",
		                    			"testimonial" => "Sed consectetur, elit eu sodales pellentesque, nulla magna pretium eros, ac porttitor ex lorem nec arcu. Suspendisse ipsum tellus, eleifend ac placerat ac, pulvinar vitae turpis. Curabitur ullamcorper rutrum orci nec porttitor."
		                    		), 
		                    		"2" => array(
		                    			"name" => "Adam Hope", 
		                    			"company" => "Co Company",
		                    			"testimonial" => "Sed consectetur, elit eu sodales pellentesque, nulla magna pretium eros, ac porttitor ex lorem nec arcu. Suspendisse ipsum tellus, eleifend ac placerat ac, pulvinar vitae turpis. Curabitur ullamcorper rutrum orci nec porttitor."
		                    		), 
		                    		"3" => array(
		                    			"name" => "Alexandra Love", 
		                    			"company" => "Fashion Magazine",
		                    			"testimonial" => "Sed consectetur, elit eu sodales pellentesque, nulla magna pretium eros, ac porttitor ex lorem nec arcu. Suspendisse ipsum tellus, eleifend ac placerat ac, pulvinar vitae turpis. Curabitur ullamcorper rutrum orci nec porttitor."
		                    		),  
		                    	))),   
		                    	'params' => array(  
		                    		array(
		                    			'name' => 'img',
		                    			'label' => esc_html__('Client Image', 'litmus'), 
		                    			'type' => 'attach_image',  
		                    		),
		                    		array(
		                    			'name' => 'name',
		                    			'type' => 'text',
		                    			'label' => esc_html__('Name', 'litmus'),  
		                    			'admin_label' => true,
		                    		),
		                    		array(
		                    			'name' => 'company',
		                    			'type' => 'text',
		                    			'label' => esc_html__('Company', 'litmus'),  
		                    		),  
		                    		array(
		                    			'name' => 'testimonial',
		                    			'type' => 'textarea',
		                    			'label' => esc_html__('Testimonial', 'litmus'),   
		                    		),
		                    	)
		                    ),  
	                	),
						'styling' => array(
							array(
								'name'		=> 'css_custom',
								'type'		=> 'css',
								'options'	=> array(
									array(
										"screens" => "any,1024,999,767,479",
										'Description'	=> array(
											array(
												'property' => 'color', 
												'selector' => '.testimonial-content'
											), 				
											array(
												'property' => 'font-size', 
												'selector' => '.testimonial-content'
											), 				
											array(
												'property' => 'font-weight', 
												'selector' => '.testimonial-content'
											), 			
											array(
												'property' => 'line-height', 
												'selector' => '.testimonial-content'
											), 				
											array(
												'property' => 'letter-spacing', 
												'selector' => '.testimonial-content'
											), 			
											array(
												'property' => 'text-align', 
												'selector' => '.testimonial-content'
											), 		
											array(
												'property' => 'text-transform', 
												'selector' => '.testimonial-content'
											), 
										),
										'Title' => array(
											array(
												'property' => 'color',
												'label' => esc_html__('Author Color','aurorax'), 
												'selector' => '.testimonial-author'
											),						
											array(
												'property' => 'color',
												'label' => esc_html__('Author Company','aurorax'), 
												'selector' => '.testimonial-author span'
											),						
											array(
												'property' => 'font-family',
												'selector' => '.testimonial-author'
											),  						
											array(
												'property' => 'font-size',
												'selector' => '.testimonial-author'
											),				
											array(
												'property' => 'font-weight',
												'selector' => '.testimonial-author'
											),			
											array(
												'property' => 'line-height',
												'selector' => '.testimonial-author'
											),				
											array(
												'property' => 'letter-spacing',
												'selector' => '.testimonial-author'
											),				
											array(
												'property' => 'text-transform',
												'selector' => '.testimonial-author'
											),		
											array(
												'property' => 'text-align',
												'selector' => '.testimonial-author'
											),			
											array(
												'property' => 'display',
												'selector' => '.testimonial-author'
											),		
											array(
												'property' => 'padding',
												'selector' => '.testimonial-author'
											),
											array(
												'property' => 'margin',
												'selector' => '.testimonial-author'
											),
										),
										'Nav Dot' => array(
											array(
												'property' => 'background',
												'label' => esc_html__('Carousel Dot Background','aurorax'),
												'selector' => '.owl-theme .owl-dots .owl-dot.active span, .owl-theme .owl-dots .owl-dot:hover span'
											),
										),	 	 
									),
								),
							),
						),
						'animate' => array(
							array(
								'name'    => 'animate',
								'type'    => 'animate'
							)
						),
	                )
	            ),  // End of elemnt kc_icon  
	        )
	    ); // End add map 
	} // End if
}
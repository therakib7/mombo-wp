<?php
add_shortcode( 'aurorax_button', function($atts, $content = null) {
	extract(shortcode_atts(array(  
		'btn_url' => '',  
		'style' => '',  
	), $atts));
	extract($atts);
	$master_class = apply_filters( 'kc-el-class', $atts );
	ob_start(); ?>
	<div class="<?php echo esc_attr( implode( ' ', $master_class ) ); ?>">
		<?php 
			$linkurl = aurorax_theme_kc_custom_link($btn_url);
			$button_attr = array();
			if(  $linkurl["url"] != "" ) {
				$button_attr[] = 'href="'. esc_attr($linkurl["url"]) .'"';
			} else {
				$button_attr[] = 'href="#"';
			}
			if( $linkurl["target"] != "" ){
				$button_attr[] = 'target="'. esc_attr($linkurl["target"]) .'"';
			}
			if(  $linkurl["title"] != "" ){
				$button_attr[] = 'title="'. esc_attr($linkurl["title"]) .'"';
			}
		?>
		<?php 
			if($style == 'two') {
				$btnClass = "btn-dark2";
			} else {
				$btnClass = "btn-dark";
			}
			if($linkurl) { ?>
				<a class="btn <?php echo esc_attr($btnClass); ?> aurorax-btn" <?php echo implode(' ', $button_attr); ?>><?php echo esc_html($linkurl["title"]); ?></a>
			<?php }
		?>
	</div>
	<?php return ob_get_clean();
});

// King Composer Custom Shortcode
add_action( 'init', 'aurorax_kc_button', 98 );
function aurorax_kc_button() {
	if (function_exists('kc_add_map')) { 
	    kc_add_map(
	        array( 
	            'aurorax_button' => array(
	                'name' => esc_html__('Aurorax Button', 'aurorax'),
	                'description' => esc_html__('This Button component for Aurorax Theme', 'aurorax'),
	                'icon' => 'kc-icon-button',
	                'category' => 'Aurorax',
	                'params' => array(
	                	'general' => array(        	
	                		array(
	                			'name' => 'btn_url',
	                			'type' => 'link',
	                			'label' => esc_html__('Button', 'aurorax'),    
	                			'admin_label' => true,
	                		),
	                		array(
	                			'name' => 'style',
	                			'label' => esc_html__('Style', 'litmus'),  
	                			'type' => 'select',  
	                			'options' => array(  
	                				'one' => esc_html__('One', 'litmus'), 
	                				'two' => esc_html__('Two', 'litmus'),    
	                			),
	                			'value' => 'one',
	                		),
	                	),
	                	'styling' => array(
	                		array(
	                			'name'		=> 'css_custom',
	                			'type'		=> 'css',
	                			'options'	=> array(
	                				array(
	                					"screens" => "any, 1024, 999, 767, 479",
	                					'Button Style' => array(
	                						array('property' => 'color', 'label' => 'Text Color', 'selector' => '.aurorax-btn'),
	                						array('property' => 'background-color', 'label' => 'Background Color', 'selector' => '.aurorax-btn'),
	                						array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.aurorax-btn'),
	                						array('property' => 'font-size', 'label' => 'Text Size', 'selector' => '.aurorax-btn'),
	                						array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.aurorax-btn'),
	                						array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.aurorax-btn'),
	                						array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.aurorax-btn'),
	                						array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.aurorax-btn'),
	                						array('property' => 'text-align', 'label' => 'Align'),
	                						array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.aurorax-btn'),
	                						array('property' => 'text-shadow', 'label' => 'Text Shadow', 'selector' => '.aurorax-btn'),
	                						array('property' => 'width', 'selector' => '.aurorax-btn'),
	                						array('property' => 'height', 'selector' => '.aurorax-btn'),
	                						array('property' => 'display', 'label' => 'Display'),
	                						array('property' => 'border', 'label' => 'Border', 'selector' => '.aurorax-btn'),
	                						array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.aurorax-btn'),
	                						array('property' => 'padding', 'label' => 'Padding', 'selector' => '.aurorax-btn'),
	                						array('property' => 'margin', 'label' => 'Margin', 'selector' => '.aurorax-btn'),
	                					),
	                					'Mouse Hover' => array(
	                						array('property' => 'font-size', 'label' => 'Text Size', 'selector' => '.aurorax-btn:hover'),
	                						array('property' => 'color', 'label' => 'Text Color', 'selector'=>'.aurorax-btn:hover'),
	                						array('property' => 'background-color', 'label' => 'Background Color', 'selector'=>'.aurorax-btn:hover'),
	                						array('property' => 'border', 'label' => 'Border', 'selector'=>'.aurorax-btn:hover'),
	                						array('property' => 'border-radius', 'label' => 'Border Radius Hover', 'selector'=>'.aurorax-btn:hover')
	                					) 
	                				),
	                			),
	                		),
	                	),
						'animate' => array(
							array(
								'name'    => 'animate',
								'type'    => 'animate'
							)
						),
	                ),
	            ),  // End of elemnt kc_icon 
	        )
	    ); // End add map
	
	} // End if
}
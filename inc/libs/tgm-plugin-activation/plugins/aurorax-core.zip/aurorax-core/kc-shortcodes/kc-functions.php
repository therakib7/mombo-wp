<?php 
/**
 *  Aurorax Active Kingcomposer By Default on portfolio content
 *
 * @package Aurorax
 * @since 1.0
 */
if ( ARURAX_PG_IS_ACTIVE_KC ) {   
    
    add_action('init', 'aurorax_support_kc_portolio', 99 );
     
    function aurorax_support_kc_portolio() {
        global $kc;
        $kc->add_content_type( 'portfolio' );
    }
}
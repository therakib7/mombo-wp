<?php 
/**
 *  Aurorax Page Builder Shortcode
 *
 * @package Aurorax
 * @since 1.0
 */
if ( ARURAX_PG_IS_ACTIVE_KC ) {  

    require_once plugin_dir_path( __FILE__ ) . 'kc-functions.php';

    //Require all PHP files in the /kc-shortcodes/addons directory
    foreach( glob( plugin_dir_path( __FILE__ ) . "addons/*.php") as $file ) {
        require $file; 
    }
}
